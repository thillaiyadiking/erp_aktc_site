<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-24 20:37:37 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `tbloptions` (`name`, `value`, `autoload`) VALUES ('auto_backup_every', '7', 1)
ERROR - 2023-07-24 20:40:16 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `tblmodules` (`module_name`, `installed_version`) VALUES ('exports', '1.0.0')
ERROR - 2023-07-24 20:40:36 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `tblmodules` (`module_name`, `installed_version`) VALUES ('goals', '2.3.0')
ERROR - 2023-07-24 20:40:46 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `tblmodules` (`module_name`, `installed_version`) VALUES ('menu_setup', '2.3.0')
ERROR - 2023-07-24 20:41:48 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `tblmodules` (`module_name`, `installed_version`) VALUES ('theme_style', '2.3.0')
ERROR - 2023-07-24 20:42:46 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `tbloptions` (`name`, `value`, `autoload`) VALUES ('auto_backup_every', '7', 1)
ERROR - 2023-07-24 21:00:22 --> Could not find the language line "features"
ERROR - 2023-07-24 19:10:54 --> 404 Page Not Found: /index
ERROR - 2023-07-24 19:10:54 --> 404 Page Not Found: /index
ERROR - 2023-07-24 22:20:29 --> Could not find the language line "features"
ERROR - 2023-07-24 22:21:22 --> Could not find the language line "features"
ERROR - 2023-07-24 22:56:44 --> Could not find the language line "features"
ERROR - 2023-07-24 23:22:26 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `tblknowledge_base_groups` (`name`, `group_slug`, `color`, `description`, `group_order`, `branch_id`, `active`) VALUES ('test2', 'test2', '', '', '2', '1', 1)
ERROR - 2023-07-24 23:22:31 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `tblknowledge_base_groups` (`name`, `group_slug`, `color`, `description`, `group_order`, `branch_id`, `active`) VALUES ('test2', 'test2', '', '', '2', '1', 1)
ERROR - 2023-07-24 23:22:51 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `tblknowledge_base_groups` (`name`, `group_slug`, `color`, `description`, `group_order`, `branch_id`, `active`) VALUES ('test2', 'test2', '', '', '2', '1', 1)
ERROR - 2023-07-24 23:26:39 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `tblknowledge_base_groups` (`name`, `group_slug`, `color`, `description`, `group_order`, `branch_id`, `active`) VALUES ('test23', 'test23', '', '', '2', '1', 1)
ERROR - 2023-07-24 23:26:42 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `tblknowledge_base_groups` (`name`, `group_slug`, `color`, `description`, `group_order`, `branch_id`, `active`) VALUES ('test23', 'test23', '', '', '2', '1', 1)
ERROR - 2023-07-24 23:26:59 --> Query error: Unknown column 'id' in 'field list' - Invalid query: INSERT INTO `tblknowledge_base_groups` (`id`, `name`, `group_slug`, `color`, `description`, `group_order`, `branch_id`, `active`) VALUES ('0', 'test', 'test-2', '#000000', '', '0', '1', 1)
ERROR - 2023-07-24 23:27:05 --> Query error: Unknown column 'id' in 'field list' - Invalid query: INSERT INTO `tblknowledge_base_groups` (`id`, `name`, `group_slug`, `color`, `description`, `group_order`, `branch_id`, `active`) VALUES ('0', 'test', 'test-2', '#000000', '', '0', '1', 1)
ERROR - 2023-07-24 22:06:48 --> Could not find the language line "branch"
ERROR - 2023-07-24 22:07:20 --> Could not find the language line "branch"
ERROR - 2023-07-24 22:07:59 --> Could not find the language line "features"
ERROR - 2023-07-24 22:08:58 --> Could not find the language line "features"
ERROR - 2023-07-24 22:09:07 --> Could not find the language line "features"
ERROR - 2023-07-24 22:09:38 --> Could not find the language line "features"
ERROR - 2023-07-24 22:09:58 --> Query error: Unknown column 'branch_id' in 'field list' - Invalid query: INSERT INTO `tblcustomers_groups` (`name`, `id`, `branch_id`) VALUES ('test_br1_group', '', '1')
ERROR - 2023-07-24 22:10:05 --> Query error: Unknown column 'branch_id' in 'field list' - Invalid query: INSERT INTO `tblcustomers_groups` (`name`, `id`, `branch_id`) VALUES ('test_br1_group', '', '1')
ERROR - 2023-07-24 22:49:25 --> Could not find the language line "features"
ERROR - 2023-07-24 22:49:39 --> Could not find the language line "features"
ERROR - 2023-07-24 23:04:31 --> Severity: Notice --> Undefined property: App_modules::$session C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 77
ERROR - 2023-07-24 23:04:31 --> Severity: error --> Exception: Call to a member function userdata() on null C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 77
ERROR - 2023-07-24 23:06:48 --> Severity: Notice --> Undefined variable: b_id C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 76
ERROR - 2023-07-24 23:06:48 --> Severity: Notice --> Undefined variable: b_id C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 79
ERROR - 2023-07-24 23:06:48 --> Query error: Column 'branch_id' cannot be null - Invalid query: INSERT INTO `tblmodules` (`branch_id`, `module_name`, `installed_version`) VALUES (NULL, 'backup', '2.3.0')
