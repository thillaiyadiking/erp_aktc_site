<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-02-02 07:06:57 --> Severity: Notice --> Undefined property: stdClass::$branch_id C:\xampp-new\htdocs\finishizer_erp3.0.5\application\models\Authentication_model.php 84
ERROR - 2024-02-02 07:06:58 --> Query error: Unknown column 'branch_id' in 'where clause' - Invalid query: SELECT *
FROM `tbltickets_status`
WHERE `branch_id` = '' OR `branch_id` = '0'
ORDER BY `statusorder` ASC
ERROR - 2024-02-02 07:49:44 --> Could not find the language line "Branches"
ERROR - 2024-02-02 07:49:44 --> Could not find the language line "Branches"
ERROR - 2024-02-02 07:49:44 --> Could not find the language line "Branches"
ERROR - 2024-02-02 07:49:53 --> Could not find the language line "Branches"
ERROR - 2024-02-02 07:49:55 --> Could not find the language line "Branches"
ERROR - 2024-02-02 07:49:55 --> Could not find the language line "Branches"
ERROR - 2024-02-02 07:49:56 --> Could not find the language line "Branches"
ERROR - 2024-02-02 07:50:01 --> Could not find the language line "Branches"
ERROR - 2024-02-02 07:50:01 --> Could not find the language line "Branches"
ERROR - 2024-02-02 07:50:01 --> Could not find the language line "Branches"
ERROR - 2024-02-02 07:50:04 --> Could not find the language line "Branches"
ERROR - 2024-02-02 07:50:04 --> Could not find the language line "Branches"
ERROR - 2024-02-02 07:50:05 --> Could not find the language line "Branches"
ERROR - 2024-02-02 07:50:19 --> Could not find the language line "Branches"
ERROR - 2024-02-02 07:50:19 --> Could not find the language line "Branches"
ERROR - 2024-02-02 07:50:20 --> Could not find the language line "Branches"
ERROR - 2024-02-02 07:50:26 --> Could not find the language line "Branches"
ERROR - 2024-02-02 07:50:41 --> Could not find the language line "Branches"
ERROR - 2024-02-02 07:50:41 --> Could not find the language line "Branches"
ERROR - 2024-02-02 07:50:41 --> Could not find the language line "Branches"
ERROR - 2024-02-02 07:53:39 --> Could not find the language line "Branches"
ERROR - 2024-02-02 07:53:39 --> Could not find the language line "Add new branch"
ERROR - 2024-02-02 07:53:39 --> Could not find the language line "Branches"
ERROR - 2024-02-02 07:53:39 --> Severity: Notice --> Undefined variable: currencies C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 24
ERROR - 2024-02-02 07:53:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 334
ERROR - 2024-02-02 07:53:50 --> Could not find the language line "Branches"
ERROR - 2024-02-02 07:53:50 --> Could not find the language line "branch"
ERROR - 2024-02-02 07:53:50 --> Could not find the language line "Branches"
ERROR - 2024-02-02 07:53:50 --> Could not find the language line "Branches"
ERROR - 2024-02-02 07:53:50 --> Could not find the language line "Branches"
ERROR - 2024-02-02 07:53:50 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-02 07:53:55 --> Could not find the language line "Branches"
ERROR - 2024-02-02 07:53:55 --> Query error: Unknown column 'branch_id' in 'where clause' - Invalid query: SELECT `userid`
FROM `tblclients`
WHERE `branch_id` = '1'
ERROR - 2024-02-02 07:54:19 --> Could not find the language line "Branches"
ERROR - 2024-02-02 07:54:19 --> 404 Page Not Found: 
ERROR - 2024-02-02 07:54:32 --> Could not find the language line "Branches"
ERROR - 2024-02-02 07:54:32 --> Query error: Unknown column 'branch_id' in 'where clause' - Invalid query: SELECT `userid`
FROM `tblclients`
WHERE `branch_id` = '1'
ERROR - 2024-02-02 08:07:22 --> Could not find the language line "Branches"
ERROR - 2024-02-02 08:07:22 --> Query error: Unknown column 'branch_id' in 'where clause' - Invalid query: SELECT `userid`
FROM `tblclients`
WHERE `branch_id` = '1'
ERROR - 2024-02-02 09:56:27 --> Could not find the language line "Branches"
ERROR - 2024-02-02 09:56:28 --> Could not find the language line "Branches"
ERROR - 2024-02-02 09:56:29 --> Could not find the language line "Branches"
ERROR - 2024-02-02 09:56:30 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-02 09:56:35 --> Could not find the language line "Branches"
ERROR - 2024-02-02 09:56:35 --> Query error: Unknown column 'branch_id' in 'where clause' - Invalid query: SELECT `userid`
FROM `tblclients`
WHERE `branch_id` = '1'
ERROR - 2024-02-02 09:58:21 --> Could not find the language line "Branches"
ERROR - 2024-02-02 09:58:21 --> Query error: Unknown column 'branch_id' in 'where clause' - Invalid query: SELECT `userid`
FROM `tblclients`
WHERE `branch_id` = '1'
ERROR - 2024-02-02 10:02:15 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:02:15 --> Query error: Unknown column 'branch_id' in 'where clause' - Invalid query: SELECT `userid`
FROM `tblclients`
WHERE `branch_id` = '1'
ERROR - 2024-02-02 10:04:00 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:04:00 --> Query error: Unknown column 'branch_id' in 'where clause' - Invalid query: SELECT `userid`
FROM `tblclients`
WHERE `branch_id` = '1'
ERROR - 2024-02-02 10:04:23 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:04:23 --> Query error: Unknown column 'branch_id' in 'where clause' - Invalid query: SELECT `userid`
FROM `tblclients`
WHERE `branch_id` = '1'
ERROR - 2024-02-02 10:17:15 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:17:15 --> Query error: Unknown column 'branch_id' in 'where clause' - Invalid query: SELECT `userid`
FROM `tblclients`
WHERE `branch_id` = '1'
ERROR - 2024-02-02 10:17:30 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:17:30 --> Query error: Unknown column 'branch_id' in 'where clause' - Invalid query: SELECT `userid`
FROM `tblclients`
WHERE `branch_id` = '1'
ERROR - 2024-02-02 10:25:30 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:25:30 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\models\Projects_model.php 2244
ERROR - 2024-02-02 10:25:31 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\invoices_helper.php 603
ERROR - 2024-02-02 10:25:31 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\invoices_helper.php 603
ERROR - 2024-02-02 10:25:31 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\invoices_helper.php 603
ERROR - 2024-02-02 10:25:31 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\invoices_helper.php 603
ERROR - 2024-02-02 10:25:31 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\invoices_helper.php 603
ERROR - 2024-02-02 10:25:31 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\invoices_helper.php 603
ERROR - 2024-02-02 10:25:31 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\models\Invoices_model.php 254
ERROR - 2024-02-02 10:25:31 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\models\Invoices_model.php 254
ERROR - 2024-02-02 10:25:31 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\models\Invoices_model.php 254
ERROR - 2024-02-02 10:26:20 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:26:20 --> Severity: Notice --> Undefined variable: clients C:\xampp-new\htdocs\finishizer_erp3.0.5\application\models\Projects_model.php 2244
ERROR - 2024-02-02 10:26:20 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\invoices_helper.php 603
ERROR - 2024-02-02 10:26:20 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\invoices_helper.php 603
ERROR - 2024-02-02 10:26:20 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\invoices_helper.php 603
ERROR - 2024-02-02 10:26:20 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\invoices_helper.php 603
ERROR - 2024-02-02 10:26:20 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\invoices_helper.php 603
ERROR - 2024-02-02 10:26:20 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\invoices_helper.php 603
ERROR - 2024-02-02 10:26:20 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\models\Invoices_model.php 254
ERROR - 2024-02-02 10:26:20 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\models\Invoices_model.php 254
ERROR - 2024-02-02 10:26:20 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\models\Invoices_model.php 254
ERROR - 2024-02-02 10:28:04 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:28:04 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\invoices_helper.php 603
ERROR - 2024-02-02 10:28:04 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\invoices_helper.php 603
ERROR - 2024-02-02 10:28:04 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\invoices_helper.php 603
ERROR - 2024-02-02 10:28:04 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\invoices_helper.php 603
ERROR - 2024-02-02 10:28:04 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\invoices_helper.php 603
ERROR - 2024-02-02 10:28:04 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\invoices_helper.php 603
ERROR - 2024-02-02 10:28:04 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\models\Invoices_model.php 254
ERROR - 2024-02-02 10:28:04 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\models\Invoices_model.php 254
ERROR - 2024-02-02 10:28:04 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\models\Invoices_model.php 254
ERROR - 2024-02-02 10:28:05 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:28:06 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:34:24 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:34:27 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:34:27 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:36:30 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:36:48 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:36:49 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:37:33 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:37:35 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:37:38 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:37:44 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:38:03 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:38:04 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:38:06 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:38:59 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:39:00 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:40:08 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:40:08 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:40:09 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:40:11 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:41:13 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:41:14 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:41:16 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:41:17 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:41:33 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:41:34 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:44:20 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:44:22 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:44:22 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:44:25 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:44:25 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:44:25 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:44:25 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-02 10:44:44 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:44:45 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:44:45 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:44:49 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:44:49 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:44:49 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:44:49 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-02 10:44:51 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:44:51 --> Could not find the language line "Add new branch"
ERROR - 2024-02-02 10:44:51 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:44:51 --> Severity: Notice --> Undefined variable: currencies C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 24
ERROR - 2024-02-02 10:44:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 334
ERROR - 2024-02-02 10:45:06 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:45:06 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `tblstaff_branch_assignment` (`staffid`, `branch_id`) VALUES ('1', 2)
ERROR - 2024-02-02 10:50:46 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:50:46 --> Could not find the language line "branch"
ERROR - 2024-02-02 10:50:46 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:50:46 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:50:46 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:50:46 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-02 10:50:46 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-02 10:50:53 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:50:54 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:50:54 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:51:01 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:51:01 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:51:01 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:51:01 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-02 10:51:01 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-02 10:51:03 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:51:05 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:51:05 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:51:05 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:51:09 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:51:09 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:51:09 --> Could not find the language line "Assign to"
ERROR - 2024-02-02 10:51:09 --> Could not find the language line "Select"
ERROR - 2024-02-02 10:51:09 --> Severity: Notice --> Undefined variable: assigned_branches C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 205
ERROR - 2024-02-02 10:51:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 205
ERROR - 2024-02-02 10:51:09 --> Severity: Notice --> Undefined variable: assigned_branches C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 205
ERROR - 2024-02-02 10:51:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 205
ERROR - 2024-02-02 10:51:09 --> Severity: Notice --> Undefined variable: assigned_branches C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 205
ERROR - 2024-02-02 10:51:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 205
ERROR - 2024-02-02 10:51:09 --> Query error: Unknown column 'branch_id' in 'where clause' - Invalid query: SELECT *
FROM `tblcustomfields`
WHERE `active` = 1
AND `fieldto` = 'staff'
AND `branch_id` =0
ORDER BY `field_order` ASC
ERROR - 2024-02-02 10:53:13 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:53:13 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:53:13 --> Could not find the language line "Assign to"
ERROR - 2024-02-02 10:53:13 --> Could not find the language line "Select"
ERROR - 2024-02-02 10:53:13 --> Severity: Notice --> Undefined variable: assigned_branches C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 205
ERROR - 2024-02-02 10:53:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 205
ERROR - 2024-02-02 10:53:13 --> Severity: Notice --> Undefined variable: assigned_branches C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 205
ERROR - 2024-02-02 10:53:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 205
ERROR - 2024-02-02 10:53:13 --> Severity: Notice --> Undefined variable: assigned_branches C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 205
ERROR - 2024-02-02 10:53:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 205
ERROR - 2024-02-02 10:53:13 --> Could not find the language line "features"
ERROR - 2024-02-02 10:53:13 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:53:41 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:59:50 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:59:50 --> Could not find the language line "Branches"
ERROR - 2024-02-02 10:59:50 --> Could not find the language line "Assign to"
ERROR - 2024-02-02 10:59:50 --> Could not find the language line "Select"
ERROR - 2024-02-02 10:59:50 --> Severity: Notice --> Undefined variable: assigned_branches C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 205
ERROR - 2024-02-02 10:59:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 205
ERROR - 2024-02-02 10:59:50 --> Severity: Notice --> Undefined variable: assigned_branches C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 205
ERROR - 2024-02-02 10:59:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 205
ERROR - 2024-02-02 10:59:50 --> Severity: Notice --> Undefined variable: assigned_branches C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 205
ERROR - 2024-02-02 10:59:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 205
ERROR - 2024-02-02 10:59:50 --> Could not find the language line "features"
ERROR - 2024-02-02 10:59:50 --> Could not find the language line "Branches"
ERROR - 2024-02-02 11:02:20 --> Could not find the language line "Branches"
ERROR - 2024-02-02 11:02:20 --> Could not find the language line "Branches"
ERROR - 2024-02-02 11:02:20 --> Could not find the language line "Assign to"
ERROR - 2024-02-02 11:02:20 --> Could not find the language line "Select"
ERROR - 2024-02-02 11:02:20 --> Could not find the language line "features"
ERROR - 2024-02-02 11:02:20 --> Could not find the language line "Branches"
ERROR - 2024-02-02 11:02:34 --> Could not find the language line "Branches"
ERROR - 2024-02-02 11:02:35 --> Could not find the language line "Branches"
ERROR - 2024-02-02 11:02:35 --> Could not find the language line "Branches"
ERROR - 2024-02-02 11:02:35 --> Could not find the language line "Branches"
ERROR - 2024-02-02 11:02:35 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-02 11:02:35 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-02 11:03:04 --> Could not find the language line "Branches"
ERROR - 2024-02-02 11:03:04 --> Could not find the language line "Branches"
ERROR - 2024-02-02 11:03:04 --> Could not find the language line "Branches"
ERROR - 2024-02-02 11:03:04 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-02 11:03:04 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-02 11:03:10 --> Could not find the language line "Branches"
ERROR - 2024-02-02 11:03:12 --> Could not find the language line "Branches"
ERROR - 2024-02-02 11:03:12 --> Could not find the language line "Branches"
ERROR - 2024-02-02 11:03:12 --> Could not find the language line "Branches"
ERROR - 2024-02-02 11:03:14 --> Could not find the language line "Branches"
ERROR - 2024-02-02 11:03:14 --> Could not find the language line "Branches"
ERROR - 2024-02-02 11:03:14 --> Could not find the language line "Assign to"
ERROR - 2024-02-02 11:03:14 --> Could not find the language line "Select"
ERROR - 2024-02-02 11:03:14 --> Could not find the language line "features"
ERROR - 2024-02-02 11:03:15 --> Could not find the language line "Branches"
ERROR - 2024-02-02 11:03:47 --> Could not find the language line "Branches"
ERROR - 2024-02-02 11:03:47 --> Could not find the language line "Branches"
ERROR - 2024-02-02 11:03:47 --> Could not find the language line "Branches"
ERROR - 2024-02-02 11:03:47 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-02 11:03:47 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-02 21:26:12 --> Severity: Notice --> Undefined property: stdClass::$branch_id C:\xampp-new\htdocs\finishizer_erp3.0.5\application\models\Authentication_model.php 84
ERROR - 2024-02-02 21:26:13 --> Could not find the language line "Branches"
ERROR - 2024-02-02 21:26:13 --> Could not find the language line "Branches"
ERROR - 2024-02-02 21:26:13 --> Could not find the language line "Branches"
ERROR - 2024-02-02 21:26:13 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-02 21:26:13 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-02 21:45:21 --> Could not find the language line "Branches"
ERROR - 2024-02-02 21:45:23 --> Could not find the language line "Branches"
ERROR - 2024-02-02 21:45:23 --> Could not find the language line "Branches"
ERROR - 2024-02-02 21:45:26 --> Could not find the language line "Branches"
ERROR - 2024-02-02 21:45:26 --> Could not find the language line "Branches"
ERROR - 2024-02-02 21:45:28 --> Could not find the language line "Branches"
ERROR - 2024-02-02 21:47:03 --> Could not find the language line "Branches"
ERROR - 2024-02-02 21:50:13 --> Could not find the language line "Branches"
ERROR - 2024-02-02 21:50:13 --> Could not find the language line "Branches"
ERROR - 2024-02-02 21:50:15 --> Could not find the language line "Branches"
ERROR - 2024-02-02 19:50:15 --> 404 Page Not Found: /index
ERROR - 2024-02-02 19:50:16 --> 404 Page Not Found: /index
ERROR - 2024-02-02 21:55:50 --> Could not find the language line "Branches"
ERROR - 2024-02-02 19:55:50 --> 404 Page Not Found: /index
ERROR - 2024-02-02 19:55:51 --> 404 Page Not Found: /index
ERROR - 2024-02-02 21:58:29 --> Could not find the language line "Branches"
ERROR - 2024-02-02 21:58:30 --> Could not find the language line "Branches"
ERROR - 2024-02-02 21:58:37 --> Could not find the language line "Branches"
ERROR - 2024-02-02 21:58:37 --> Could not find the language line "Branches"
ERROR - 2024-02-02 21:58:37 --> Could not find the language line "Branches"
ERROR - 2024-02-02 21:58:37 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-02 21:58:37 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-02 21:58:40 --> Could not find the language line "Branches"
ERROR - 2024-02-02 21:58:45 --> Could not find the language line "Branches"
ERROR - 2024-02-02 21:58:45 --> Could not find the language line "Branches"
ERROR - 2024-02-02 21:58:45 --> Could not find the language line "Branches"
ERROR - 2024-02-02 21:58:47 --> Could not find the language line "Branches"
