<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-17 20:02:41 --> 404 Page Not Found: Migration/index
ERROR - 2023-07-17 20:03:39 --> Not Found: Migration/index
ERROR - 2023-07-17 20:03:50 --> Not Found: Migration/index
ERROR - 2023-07-17 22:04:11 --> Severity: Notice --> Undefined variable: _SESSION C:\xampp\htdocs\finishizer_erp3.0.5\system\libraries\Session\Session.php 822
ERROR - 2023-07-17 23:15:16 --> Query error: Unknown column 'branch_id' in 'field list' - Invalid query: UPDATE `tblleads_email_integration` SET `active` = 1, `imap_server` = 'test', `email` = 'hthoppil70@gmail.com', `password` = 'f0f86cc9173d59e3ed11fa2712b0234cc4bbbb0f9b03c36bac826785abf48950742230845a30a14e87d284e021dedc2dcba44c05aabde0832c47161287163f1e2TDwUzIODQoub/GVmkMqNrYZ9EBztVZSgnY06AWitms=', `encryption` = 'tls', `folder` = 'INBOX', `check_every` = '10', `only_loop_on_unseen_emails` = 1, `create_task_if_customer` = 1, `lead_status` = '2', `lead_source` = '4', `responsible` = '8', `notify_lead_imported` = 1, `notify_lead_contact_more_times` = 1, `notify_type` = 'assigned', `branch_id` = '1', `delete_after_import` = 0, `mark_public` = 0, `notify_ids` = 'a:0:{}'
WHERE `id` = 1
ERROR - 2023-07-17 23:32:39 --> Severity: error --> Exception: syntax error, unexpected '<<' (T_SL) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 38
ERROR - 2023-07-17 23:42:08 --> Severity: error --> Exception: syntax error, unexpected '<<' (T_SL) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 38
ERROR - 2023-07-17 23:42:09 --> Severity: error --> Exception: syntax error, unexpected '<<' (T_SL) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 38
