<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-10 04:56:37 --> 404 Page Not Found: admin//index
ERROR - 2023-11-10 04:56:39 --> 404 Page Not Found: admin//index
ERROR - 2023-11-10 04:56:49 --> 404 Page Not Found: admin//index
ERROR - 2023-11-10 04:56:51 --> 404 Page Not Found: admin//index
ERROR - 2023-11-10 04:58:50 --> 404 Page Not Found: admin//index
ERROR - 2023-11-10 04:58:51 --> 404 Page Not Found: admin//index
ERROR - 2023-11-10 05:00:28 --> 404 Page Not Found: admin//index
ERROR - 2023-11-10 05:00:28 --> 404 Page Not Found: admin//index
ERROR - 2023-11-10 05:06:47 --> 404 Page Not Found: //index
ERROR - 2023-11-10 05:06:47 --> 404 Page Not Found: //index
