<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-14 19:47:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY firstname ASC
    LIMIT 0, 25' at line 7 - Invalid query: 
    SELECT SQL_CALC_FOUND_ROWS firstname, email, `tblroles`.`name` AS `tblroles.name`, last_login, active ,profile_image,lastname,staffid
    FROM tblstaff
    LEFT JOIN tblroles ON tblroles.roleid = tblstaff.role
    
    WHERE  tblstaff.branch_id=
    
    ORDER BY firstname ASC
    LIMIT 0, 25
    
ERROR - 2023-08-14 19:48:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY firstname ASC
    LIMIT 0, 25' at line 7 - Invalid query: 
    SELECT SQL_CALC_FOUND_ROWS firstname, email, `tblroles`.`name` AS `tblroles.name`, last_login, active ,profile_image,lastname,staffid
    FROM tblstaff
    LEFT JOIN tblroles ON tblroles.roleid = tblstaff.role
    
    WHERE  tblstaff.branch_id=
    
    ORDER BY firstname ASC
    LIMIT 0, 25
    
ERROR - 2023-08-14 19:49:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY firstname ASC
    LIMIT 0, 25' at line 7 - Invalid query: 
    SELECT SQL_CALC_FOUND_ROWS firstname, email, `tblroles`.`name` AS `tblroles.name`, last_login, active ,profile_image,lastname,staffid
    FROM tblstaff
    LEFT JOIN tblroles ON tblroles.roleid = tblstaff.role
    
    WHERE  tblstaff.branch_id=
    
    ORDER BY firstname ASC
    LIMIT 0, 25
    
ERROR - 2023-08-14 19:56:53 --> Severity: error --> Exception: syntax error, unexpected 'static' (T_STATIC) C:\xampp\htdocs\finishizer_erp3.0.5\application\services\proposals\ProposalsPipeline.php 29
ERROR - 2023-08-14 19:59:27 --> Severity: error --> Exception: syntax error, unexpected 'static' (T_STATIC) C:\xampp\htdocs\finishizer_erp3.0.5\application\services\leads\LeadsKanban.php 29
ERROR - 2023-08-14 19:59:42 --> Severity: error --> Exception: syntax error, unexpected 'static' (T_STATIC) C:\xampp\htdocs\finishizer_erp3.0.5\application\services\leads\LeadsKanban.php 29
ERROR - 2023-08-14 19:59:44 --> Severity: error --> Exception: syntax error, unexpected 'static' (T_STATIC) C:\xampp\htdocs\finishizer_erp3.0.5\application\services\leads\LeadsKanban.php 29
ERROR - 2023-08-14 19:59:44 --> Severity: error --> Exception: syntax error, unexpected 'static' (T_STATIC) C:\xampp\htdocs\finishizer_erp3.0.5\application\services\leads\LeadsKanban.php 29
ERROR - 2023-08-14 19:59:44 --> Severity: error --> Exception: syntax error, unexpected 'static' (T_STATIC) C:\xampp\htdocs\finishizer_erp3.0.5\application\services\leads\LeadsKanban.php 29
ERROR - 2023-08-14 19:59:45 --> Severity: error --> Exception: syntax error, unexpected 'static' (T_STATIC) C:\xampp\htdocs\finishizer_erp3.0.5\application\services\leads\LeadsKanban.php 29
ERROR - 2023-08-14 19:59:45 --> Severity: error --> Exception: syntax error, unexpected 'static' (T_STATIC) C:\xampp\htdocs\finishizer_erp3.0.5\application\services\leads\LeadsKanban.php 29
ERROR - 2023-08-14 19:59:49 --> Severity: error --> Exception: syntax error, unexpected 'static' (T_STATIC) C:\xampp\htdocs\finishizer_erp3.0.5\application\services\leads\LeadsKanban.php 29
ERROR - 2023-08-14 19:59:53 --> Severity: error --> Exception: syntax error, unexpected 'static' (T_STATIC) C:\xampp\htdocs\finishizer_erp3.0.5\application\services\leads\LeadsKanban.php 29
ERROR - 2023-08-14 19:59:55 --> Severity: error --> Exception: syntax error, unexpected 'static' (T_STATIC) C:\xampp\htdocs\finishizer_erp3.0.5\application\services\leads\LeadsKanban.php 29
ERROR - 2023-08-14 19:59:56 --> Severity: error --> Exception: syntax error, unexpected 'static' (T_STATIC) C:\xampp\htdocs\finishizer_erp3.0.5\application\services\leads\LeadsKanban.php 29
ERROR - 2023-08-14 20:00:04 --> Severity: error --> Exception: syntax error, unexpected 'static' (T_STATIC) C:\xampp\htdocs\finishizer_erp3.0.5\application\services\leads\LeadsKanban.php 29
ERROR - 2023-08-14 21:28:26 --> Severity: error --> Exception: syntax error, unexpected 'static' (T_STATIC) C:\xampp\htdocs\finishizer_erp3.0.5\application\services\leads\LeadsKanban.php 29
ERROR - 2023-08-14 21:47:43 --> Severity: error --> Exception: syntax error, unexpected 'static' (T_STATIC) C:\xampp\htdocs\finishizer_erp3.0.5\application\services\leads\LeadsKanban.php 29
