<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-20 20:30:16 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `tbloptions` (`name`, `value`, `autoload`) VALUES ('sms_clickatell_active', 0, 1)
ERROR - 2023-06-20 20:51:55 --> 404 Page Not Found: Authentication/clients
