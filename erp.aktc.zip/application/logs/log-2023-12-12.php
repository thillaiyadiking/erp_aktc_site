<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-12-12 03:51:33 --> Severity: Notice --> Array to string conversion C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 18
ERROR - 2023-12-12 03:51:33 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `status` NOT IN (5,6) AND `clientid` IN (Array)
ERROR - 2023-12-12 03:52:42 --> Severity: Notice --> Array to string conversion C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 20
ERROR - 2023-12-12 03:52:42 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `status` NOT IN (5,6) AND `clientid` IN (Array)
ERROR - 2023-12-12 03:56:34 --> Severity: Notice --> Array to string conversion C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 24
ERROR - 2023-12-12 03:56:34 --> Severity: Notice --> Array to string conversion C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 24
ERROR - 2023-12-12 03:56:34 --> Severity: Notice --> Array to string conversion C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 24
ERROR - 2023-12-12 03:56:34 --> Severity: Notice --> Array to string conversion C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 24
ERROR - 2023-12-12 03:57:57 --> Severity: Notice --> Array to string conversion C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 20
ERROR - 2023-12-12 03:57:57 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `status` NOT IN (5,6) AND `clientid` IN (Array)
ERROR - 2023-12-12 03:58:39 --> Severity: Notice --> Trying to get property '1' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 26
ERROR - 2023-12-12 03:58:39 --> Severity: Notice --> Array to string conversion C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 20
ERROR - 2023-12-12 03:58:39 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `status` NOT IN (5,6) AND `clientid` IN (Array)
ERROR - 2023-12-12 04:02:08 --> Severity: Notice --> Array to string conversion C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 20
ERROR - 2023-12-12 04:02:08 --> Severity: Notice --> Array to string conversion C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 20
ERROR - 2023-12-12 04:02:08 --> Severity: Notice --> Array to string conversion C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 20
ERROR - 2023-12-12 04:02:08 --> Severity: Notice --> Array to string conversion C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 20
ERROR - 2023-12-12 04:02:08 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `status` NOT IN (5,6) AND `clientid` IN (Array,Array,Array,Array)
ERROR - 2023-12-12 04:03:58 --> Severity: Notice --> Undefined variable: br_clients C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 20
ERROR - 2023-12-12 04:03:58 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 20
ERROR - 2023-12-12 04:03:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `status` NOT IN (5,6) AND `clientid` IN ()
ERROR - 2023-12-12 04:04:02 --> Severity: Notice --> Undefined variable: br_clients C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 20
ERROR - 2023-12-12 04:04:02 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 20
ERROR - 2023-12-12 04:04:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `status` NOT IN (5,6) AND `clientid` IN ()
ERROR - 2023-12-12 04:04:48 --> Severity: Notice --> Undefined variable: br_clients C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 20
ERROR - 2023-12-12 04:04:48 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 20
ERROR - 2023-12-12 04:04:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `status` NOT IN (5,6) AND `clientid` IN ()
ERROR - 2023-12-12 04:05:05 --> Severity: Notice --> Undefined variable: br_clients C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 20
ERROR - 2023-12-12 04:05:05 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 20
ERROR - 2023-12-12 04:05:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `status` NOT IN (5,6) AND `clientid` IN ()
ERROR - 2023-12-12 04:05:06 --> Severity: Notice --> Undefined variable: br_clients C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 20
ERROR - 2023-12-12 04:05:06 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 20
ERROR - 2023-12-12 04:05:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `status` NOT IN (5,6) AND `clientid` IN ()
ERROR - 2023-12-12 04:05:09 --> Severity: Notice --> Undefined variable: br_clients C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 20
ERROR - 2023-12-12 04:05:09 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 20
ERROR - 2023-12-12 04:05:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `status` NOT IN (5,6) AND `clientid` IN ()
ERROR - 2023-12-12 04:06:02 --> Severity: Notice --> Undefined variable: br_clients C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 25
ERROR - 2023-12-12 04:06:02 --> Severity: Notice --> Undefined variable: br_clients C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 20
ERROR - 2023-12-12 04:06:02 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 20
ERROR - 2023-12-12 04:06:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `status` NOT IN (5,6) AND `clientid` IN ()
ERROR - 2023-12-12 04:07:01 --> Severity: Notice --> Array to string conversion C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 102
ERROR - 2023-12-12 04:07:01 --> Severity: Notice --> Array to string conversion C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 102
ERROR - 2023-12-12 04:07:01 --> Severity: Notice --> Array to string conversion C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 102
ERROR - 2023-12-12 04:07:01 --> Severity: Notice --> Array to string conversion C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 102
ERROR - 2023-12-12 04:07:01 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblprojects`
WHERE `clientid` IN (Array,Array,Array,Array)
ERROR - 2023-12-12 04:10:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ') AND `status` NOT IN(5)' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `clientid` IN () AND `status` NOT IN(5)
ERROR - 2023-12-12 04:11:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ') AND `status` NOT IN(5)' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `clientid` IN () AND `status` NOT IN(5)
ERROR - 2023-12-12 04:20:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND `clientid` IN (2)' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE  AND `clientid` IN (2)
ERROR - 2023-12-12 04:23:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND `clientid` IN (2)' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE  AND `clientid` IN (2)
ERROR - 2023-12-12 08:05:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND `clientid` IN ( 2 )' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE  AND `clientid` IN ( 2 )
ERROR - 2023-12-12 08:07:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND `clientid` IN ( 2 )' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE  AND `clientid` IN ( 2 )
ERROR - 2023-12-12 08:08:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND `clientid` IN ( 2 )' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE  AND `clientid` IN ( 2 )
ERROR - 2023-12-12 08:08:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND `clientid` IN ( 2 )' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE  AND `clientid` IN ( 2 )
ERROR - 2023-12-12 08:09:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND `clientid` IN ( 2 )' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE  AND `clientid` IN ( 2 )
ERROR - 2023-12-12 08:09:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND `clientid` IN ( 2 )' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE  AND `clientid` IN ( 2 )
ERROR - 2023-12-12 08:09:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND `clientid` IN ( 2 )' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE  AND `clientid` IN ( 2 )
ERROR - 2023-12-12 08:09:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND `clientid` IN ( 2 )' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE  AND `clientid` IN ( 2 )
ERROR - 2023-12-12 08:09:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND `clientid` IN ( 2 )' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE  AND `clientid` IN ( 2 )
ERROR - 2023-12-12 08:09:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND `clientid` IN ( 2 )' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE  AND `clientid` IN ( 2 )
ERROR - 2023-12-12 08:13:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ') AND `status` NOT IN(5)' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `clientid` IN () AND `status` NOT IN(5)
ERROR - 2023-12-12 08:16:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ') AND `status` NOT IN(5)' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `clientid` IN () AND `status` NOT IN(5)
ERROR - 2023-12-12 08:18:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ') AND `status` NOT IN(5)' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `clientid` IN () AND `status` NOT IN(5)
ERROR - 2023-12-12 08:20:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ') AND `status` NOT IN(5)' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `clientid` IN () AND `status` NOT IN(5)
ERROR - 2023-12-12 08:21:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ') AND `status` NOT IN(5)' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `clientid` IN () AND `status` NOT IN(5)
ERROR - 2023-12-12 08:21:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ') AND `status` NOT IN(5)' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `clientid` IN () AND `status` NOT IN(5)
ERROR - 2023-12-12 08:22:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ') AND `status` NOT IN(5)' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `clientid` IN () AND `status` NOT IN(5)
ERROR - 2023-12-12 08:23:12 --> Severity: Notice --> Undefined variable: total_invoices C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 22
ERROR - 2023-12-12 08:23:12 --> Severity: Notice --> Undefined variable: total_invoices_awaiting_payment C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 37
ERROR - 2023-12-12 08:23:12 --> Severity: Notice --> Undefined variable: total_invoices C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 38
ERROR - 2023-12-12 08:23:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ') AND `status` NOT IN(5)' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `clientid` IN () AND `status` NOT IN(5)
ERROR - 2023-12-12 08:23:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ') AND `status` NOT IN(5)' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `clientid` IN () AND `status` NOT IN(5)
ERROR - 2023-12-12 08:25:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ') AND `status` NOT IN(5)' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `clientid` IN () AND `status` NOT IN(5)
ERROR - 2023-12-12 08:25:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`
FROM `tblprojects`
WHERE `clientid` IN()
ERROR - 2023-12-12 08:27:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`
FROM `tblprojects`
WHERE `clientid` IN()
ERROR - 2023-12-12 08:27:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`
FROM `tblprojects`
WHERE `clientid` IN()
ERROR - 2023-12-12 08:27:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`
FROM `tblprojects`
WHERE `clientid` IN()
ERROR - 2023-12-12 08:29:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`
FROM `tblprojects`
WHERE `clientid` IN()
ERROR - 2023-12-12 08:29:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`
FROM `tblprojects`
WHERE `clientid` IN()
ERROR - 2023-12-12 08:29:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`
FROM `tblprojects`
WHERE `clientid` IN()
ERROR - 2023-12-12 08:30:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`
FROM `tblprojects`
WHERE `clientid` IN()
ERROR - 2023-12-12 08:30:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`
FROM `tblprojects`
WHERE `clientid` IN()
ERROR - 2023-12-12 08:31:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`
FROM `tblprojects`
WHERE `clientid` IN()
ERROR - 2023-12-12 08:31:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`
FROM `tblprojects`
WHERE `clientid` IN()
ERROR - 2023-12-12 08:31:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`
FROM `tblprojects`
WHERE `clientid` IN()
ERROR - 2023-12-12 08:31:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`
FROM `tblprojects`
WHERE `clientid` IN()
ERROR - 2023-12-12 08:31:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`
FROM `tblprojects`
WHERE `clientid` IN()
ERROR - 2023-12-12 08:31:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`
FROM `tblprojects`
WHERE `clientid` IN()
ERROR - 2023-12-12 08:31:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`
FROM `tblprojects`
WHERE `clientid` IN()
ERROR - 2023-12-12 08:31:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`
FROM `tblprojects`
WHERE `clientid` IN()
ERROR - 2023-12-12 08:32:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`
FROM `tblprojects`
WHERE `clientid` IN()
ERROR - 2023-12-12 08:32:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`
FROM `tblprojects`
WHERE `clientid` IN()
ERROR - 2023-12-12 08:40:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`
FROM `tblprojects`
WHERE `clientid` IN()
ERROR - 2023-12-12 17:38:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND `clientid` IN ( 2 ) AND `status` NOT IN(5)' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE  AND `clientid` IN ( 2 ) AND `status` NOT IN(5)
ERROR - 2023-12-12 17:43:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND `status` NOT IN(5)' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE  AND `status` NOT IN(5)
ERROR - 2023-12-12 17:45:59 --> Severity: Warning --> array_splice() expects parameter 1 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 183
ERROR - 2023-12-12 17:45:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 184
ERROR - 2023-12-12 17:45:59 --> Severity: Notice --> Undefined variable: proposal_statuses C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 230
ERROR - 2023-12-12 17:45:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 230
ERROR - 2023-12-12 17:45:59 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\models\Invoices_model.php 232
ERROR - 2023-12-12 17:45:59 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-12 17:45:59 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-12 17:45:59 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-12 17:45:59 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-12 17:45:59 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-12 17:45:59 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-12 17:45:59 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-12 17:45:59 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-12 17:45:59 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-12 17:45:59 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-12 17:45:59 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-12 17:45:59 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-12 17:45:59 --> Severity: Notice --> Undefined variable: total_undismissed_announcements C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\user_data.php 54
ERROR - 2023-12-12 17:45:59 --> Severity: Notice --> Undefined variable: activity_log C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\user_data.php 148
ERROR - 2023-12-12 17:45:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\user_data.php 148
ERROR - 2023-12-12 17:45:59 --> Severity: Notice --> Undefined variable: upcoming_events C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 2
ERROR - 2023-12-12 17:45:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 2
ERROR - 2023-12-12 17:45:59 --> Severity: Notice --> Undefined variable: upcoming_events C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 5
ERROR - 2023-12-12 17:45:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 5
ERROR - 2023-12-12 17:45:59 --> Severity: Notice --> Undefined variable: todos C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 30
ERROR - 2023-12-12 17:45:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 30
ERROR - 2023-12-12 17:45:59 --> Severity: Notice --> Undefined variable: todos C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 36
ERROR - 2023-12-12 17:45:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 36
ERROR - 2023-12-12 17:45:59 --> Severity: Notice --> Undefined variable: todos_finished C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 72
ERROR - 2023-12-12 17:45:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 72
ERROR - 2023-12-12 17:45:59 --> Severity: Notice --> Undefined variable: todos_finished C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 78
ERROR - 2023-12-12 17:45:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 78
ERROR - 2023-12-12 17:45:59 --> Severity: Notice --> Undefined variable: tickets_reply_by_status_no_json C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-12 17:45:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-12 17:45:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-12 17:45:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-12 17:45:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-12 17:45:59 --> Severity: Notice --> Undefined variable: tickets_awaiting_reply_by_department_no_json C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-12 17:45:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-12 17:45:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-12 17:45:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-12 17:45:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-12 17:45:59 --> Severity: Notice --> Undefined variable: projects_activity C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 2
ERROR - 2023-12-12 17:45:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 2
ERROR - 2023-12-12 17:45:59 --> Severity: Notice --> Undefined variable: projects_activity C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 26
ERROR - 2023-12-12 17:45:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 26
ERROR - 2023-12-12 17:45:59 --> Severity: Notice --> Undefined variable: tickets_report C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_report_table.php 17
ERROR - 2023-12-12 17:45:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_report_table.php 17
ERROR - 2023-12-12 17:47:24 --> Severity: Warning --> array_splice() expects parameter 1 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 183
ERROR - 2023-12-12 17:47:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 184
ERROR - 2023-12-12 17:47:24 --> Severity: Notice --> Undefined variable: proposal_statuses C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 230
ERROR - 2023-12-12 17:47:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 230
ERROR - 2023-12-12 17:47:24 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\models\Invoices_model.php 232
ERROR - 2023-12-12 17:47:24 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-12 17:47:24 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-12 17:47:24 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-12 17:47:24 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-12 17:47:24 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-12 17:47:24 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-12 17:47:24 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-12 17:47:24 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-12 17:47:24 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-12 17:47:24 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-12 17:47:24 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-12 17:47:24 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-12 17:47:24 --> Severity: Notice --> Undefined variable: total_undismissed_announcements C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\user_data.php 54
ERROR - 2023-12-12 17:47:24 --> Severity: Notice --> Undefined variable: activity_log C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\user_data.php 148
ERROR - 2023-12-12 17:47:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\user_data.php 148
ERROR - 2023-12-12 17:47:24 --> Severity: Notice --> Undefined variable: upcoming_events C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 2
ERROR - 2023-12-12 17:47:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 2
ERROR - 2023-12-12 17:47:24 --> Severity: Notice --> Undefined variable: upcoming_events C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 5
ERROR - 2023-12-12 17:47:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 5
ERROR - 2023-12-12 17:47:24 --> Severity: Notice --> Undefined variable: todos C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 30
ERROR - 2023-12-12 17:47:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 30
ERROR - 2023-12-12 17:47:24 --> Severity: Notice --> Undefined variable: todos C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 36
ERROR - 2023-12-12 17:47:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 36
ERROR - 2023-12-12 17:47:24 --> Severity: Notice --> Undefined variable: todos_finished C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 72
ERROR - 2023-12-12 17:47:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 72
ERROR - 2023-12-12 17:47:24 --> Severity: Notice --> Undefined variable: todos_finished C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 78
ERROR - 2023-12-12 17:47:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 78
ERROR - 2023-12-12 17:47:24 --> Severity: Notice --> Undefined variable: tickets_reply_by_status_no_json C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-12 17:47:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-12 17:47:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-12 17:47:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-12 17:47:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-12 17:47:24 --> Severity: Notice --> Undefined variable: tickets_awaiting_reply_by_department_no_json C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-12 17:47:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-12 17:47:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-12 17:47:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-12 17:47:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-12 17:47:24 --> Severity: Notice --> Undefined variable: projects_activity C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 2
ERROR - 2023-12-12 17:47:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 2
ERROR - 2023-12-12 17:47:24 --> Severity: Notice --> Undefined variable: projects_activity C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 26
ERROR - 2023-12-12 17:47:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 26
ERROR - 2023-12-12 17:47:24 --> Severity: Notice --> Undefined variable: tickets_report C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_report_table.php 17
ERROR - 2023-12-12 17:47:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_report_table.php 17
ERROR - 2023-12-12 17:47:32 --> Query error: Column 'id' in field list is ambiguous - Invalid query: SELECT tbltasks.name as title, id, (CASE rel_type
        WHEN "contract" THEN (SELECT subject FROM tblcontracts WHERE tblcontracts.id = tbltasks.rel_id)
        WHEN "estimate" THEN (SELECT id FROM tblestimates WHERE tblestimates.id = tbltasks.rel_id)
        WHEN "proposal" THEN (SELECT id FROM tblproposals WHERE tblproposals.id = tbltasks.rel_id)
        WHEN "invoice" THEN (SELECT id FROM tblinvoices WHERE tblinvoices.id = tbltasks.rel_id)
        WHEN "ticket" THEN (SELECT CONCAT(CONCAT("#", tbltickets.ticketid), " - ", tbltickets.subject) FROM tbltickets WHERE tbltickets.ticketid=tbltasks.rel_id)
        WHEN "lead" THEN (SELECT CASE tblleads.email WHEN "" THEN tblleads.name ELSE CONCAT(tblleads.name, " - ", tblleads.email) END FROM tblleads WHERE tblleads.id=tbltasks.rel_id)
        WHEN "customer" THEN (SELECT CASE company WHEN "" THEN (SELECT CONCAT(firstname, " ", lastname) FROM tblcontacts WHERE userid = tblclients.userid and is_primary = 1) ELSE company END FROM tblclients WHERE tblclients.userid=tbltasks.rel_id)
        WHEN "project" THEN (SELECT CONCAT(CONCAT(CONCAT("#", tblprojects.id), " - ", tblprojects.name), " - ", (SELECT CASE company WHEN "" THEN (SELECT CONCAT(firstname, " ", lastname) FROM tblcontacts WHERE userid = tblclients.userid and is_primary = 1) ELSE company END FROM tblclients WHERE userid=tblprojects.clientid)) FROM tblprojects WHERE tblprojects.id=tbltasks.rel_id)
        WHEN "expense" THEN (SELECT CASE expense_name WHEN "" THEN tblexpenses_categories.name ELSE
         CONCAT(tblexpenses_categories.name, ' (', tblexpenses.expense_name, ')') END FROM tblexpenses JOIN tblexpenses_categories ON tblexpenses_categories.id = tblexpenses.category WHERE tblexpenses.id=tbltasks.rel_id)
        ELSE NULL
        END) as rel_name, rel_id, status, milestone, CASE WHEN duedate IS NULL THEN startdate ELSE duedate END as date, `id`
FROM `tbltasks`, `tbloptions`
WHERE `status` != 5
AND CASE WHEN duedate IS NULL THEN (startdate BETWEEN '2023-11-26' AND '2024-01-07') ELSE (duedate BETWEEN '2023-11-26' AND '2024-01-07') END
AND `name` = 'calendar_only_assigned_tasks'
ERROR - 2023-12-12 17:47:47 --> Severity: Warning --> array_splice() expects parameter 1 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 183
ERROR - 2023-12-12 17:47:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 184
ERROR - 2023-12-12 17:47:47 --> Severity: Notice --> Undefined variable: proposal_statuses C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 230
ERROR - 2023-12-12 17:47:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 230
ERROR - 2023-12-12 17:47:47 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\models\Invoices_model.php 232
ERROR - 2023-12-12 17:47:47 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-12 17:47:47 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-12 17:47:47 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-12 17:47:47 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-12 17:47:47 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-12 17:47:47 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-12 17:47:47 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-12 17:47:47 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-12 17:47:47 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-12 17:47:47 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-12 17:47:47 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-12 17:47:47 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-12 17:47:47 --> Severity: Notice --> Undefined variable: total_undismissed_announcements C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\user_data.php 54
ERROR - 2023-12-12 17:47:47 --> Severity: Notice --> Undefined variable: activity_log C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\user_data.php 148
ERROR - 2023-12-12 17:47:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\user_data.php 148
ERROR - 2023-12-12 17:47:47 --> Severity: Notice --> Undefined variable: upcoming_events C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 2
ERROR - 2023-12-12 17:47:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 2
ERROR - 2023-12-12 17:47:47 --> Severity: Notice --> Undefined variable: upcoming_events C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 5
ERROR - 2023-12-12 17:47:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 5
ERROR - 2023-12-12 17:47:47 --> Severity: Notice --> Undefined variable: todos C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 30
ERROR - 2023-12-12 17:47:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 30
ERROR - 2023-12-12 17:47:47 --> Severity: Notice --> Undefined variable: todos C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 36
ERROR - 2023-12-12 17:47:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 36
ERROR - 2023-12-12 17:47:47 --> Severity: Notice --> Undefined variable: todos_finished C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 72
ERROR - 2023-12-12 17:47:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 72
ERROR - 2023-12-12 17:47:47 --> Severity: Notice --> Undefined variable: todos_finished C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 78
ERROR - 2023-12-12 17:47:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 78
ERROR - 2023-12-12 17:47:47 --> Severity: Notice --> Undefined variable: tickets_reply_by_status_no_json C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-12 17:47:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-12 17:47:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-12 17:47:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-12 17:47:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-12 17:47:47 --> Severity: Notice --> Undefined variable: tickets_awaiting_reply_by_department_no_json C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-12 17:47:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-12 17:47:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-12 17:47:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-12 17:47:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-12 17:47:47 --> Severity: Notice --> Undefined variable: projects_activity C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 2
ERROR - 2023-12-12 17:47:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 2
ERROR - 2023-12-12 17:47:47 --> Severity: Notice --> Undefined variable: projects_activity C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 26
ERROR - 2023-12-12 17:47:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 26
ERROR - 2023-12-12 17:47:47 --> Severity: Notice --> Undefined variable: tickets_report C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_report_table.php 17
ERROR - 2023-12-12 17:47:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_report_table.php 17
ERROR - 2023-12-12 18:50:07 --> Severity: Warning --> array_splice() expects parameter 1 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 183
ERROR - 2023-12-12 18:50:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 184
ERROR - 2023-12-12 18:50:07 --> Severity: Notice --> Undefined variable: proposal_statuses C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 230
ERROR - 2023-12-12 18:50:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 230
ERROR - 2023-12-12 18:50:07 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\models\Invoices_model.php 232
ERROR - 2023-12-12 18:50:07 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-12 18:50:07 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-12 18:50:07 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-12 18:50:07 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-12 18:50:07 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-12 18:50:07 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-12 18:50:07 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-12 18:50:07 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-12 18:50:07 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-12 18:50:07 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-12 18:50:07 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-12 18:50:07 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-12 18:50:07 --> Severity: Notice --> Undefined variable: total_undismissed_announcements C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\user_data.php 54
ERROR - 2023-12-12 18:50:07 --> Severity: Notice --> Undefined variable: activity_log C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\user_data.php 148
ERROR - 2023-12-12 18:50:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\user_data.php 148
ERROR - 2023-12-12 18:50:07 --> Severity: Notice --> Undefined variable: upcoming_events C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 2
ERROR - 2023-12-12 18:50:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 2
ERROR - 2023-12-12 18:50:07 --> Severity: Notice --> Undefined variable: upcoming_events C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 5
ERROR - 2023-12-12 18:50:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 5
ERROR - 2023-12-12 18:50:07 --> Severity: Notice --> Undefined variable: todos C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 30
ERROR - 2023-12-12 18:50:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 30
ERROR - 2023-12-12 18:50:07 --> Severity: Notice --> Undefined variable: todos C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 36
ERROR - 2023-12-12 18:50:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 36
ERROR - 2023-12-12 18:50:07 --> Severity: Notice --> Undefined variable: todos_finished C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 72
ERROR - 2023-12-12 18:50:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 72
ERROR - 2023-12-12 18:50:07 --> Severity: Notice --> Undefined variable: todos_finished C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 78
ERROR - 2023-12-12 18:50:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 78
ERROR - 2023-12-12 18:50:07 --> Severity: Notice --> Undefined variable: tickets_reply_by_status_no_json C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-12 18:50:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-12 18:50:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-12 18:50:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-12 18:50:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-12 18:50:07 --> Severity: Notice --> Undefined variable: tickets_awaiting_reply_by_department_no_json C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-12 18:50:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-12 18:50:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-12 18:50:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-12 18:50:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-12 18:50:07 --> Severity: Notice --> Undefined variable: projects_activity C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 2
ERROR - 2023-12-12 18:50:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 2
ERROR - 2023-12-12 18:50:07 --> Severity: Notice --> Undefined variable: projects_activity C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 26
ERROR - 2023-12-12 18:50:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 26
ERROR - 2023-12-12 18:50:07 --> Severity: Notice --> Undefined variable: tickets_report C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_report_table.php 17
ERROR - 2023-12-12 18:50:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_report_table.php 17
ERROR - 2023-12-12 18:51:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblprojects`
WHERE `clientid` IN ()
ERROR - 2023-12-12 18:55:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`
FROM `tblprojects`
WHERE `clientid` IN()
ERROR - 2023-12-12 19:02:11 --> Query error: Column 'id' in field list is ambiguous - Invalid query: SELECT tbltasks.name as title, id, (CASE rel_type
        WHEN "contract" THEN (SELECT subject FROM tblcontracts WHERE tblcontracts.id = tbltasks.rel_id)
        WHEN "estimate" THEN (SELECT id FROM tblestimates WHERE tblestimates.id = tbltasks.rel_id)
        WHEN "proposal" THEN (SELECT id FROM tblproposals WHERE tblproposals.id = tbltasks.rel_id)
        WHEN "invoice" THEN (SELECT id FROM tblinvoices WHERE tblinvoices.id = tbltasks.rel_id)
        WHEN "ticket" THEN (SELECT CONCAT(CONCAT("#", tbltickets.ticketid), " - ", tbltickets.subject) FROM tbltickets WHERE tbltickets.ticketid=tbltasks.rel_id)
        WHEN "lead" THEN (SELECT CASE tblleads.email WHEN "" THEN tblleads.name ELSE CONCAT(tblleads.name, " - ", tblleads.email) END FROM tblleads WHERE tblleads.id=tbltasks.rel_id)
        WHEN "customer" THEN (SELECT CASE company WHEN "" THEN (SELECT CONCAT(firstname, " ", lastname) FROM tblcontacts WHERE userid = tblclients.userid and is_primary = 1) ELSE company END FROM tblclients WHERE tblclients.userid=tbltasks.rel_id)
        WHEN "project" THEN (SELECT CONCAT(CONCAT(CONCAT("#", tblprojects.id), " - ", tblprojects.name), " - ", (SELECT CASE company WHEN "" THEN (SELECT CONCAT(firstname, " ", lastname) FROM tblcontacts WHERE userid = tblclients.userid and is_primary = 1) ELSE company END FROM tblclients WHERE userid=tblprojects.clientid)) FROM tblprojects WHERE tblprojects.id=tbltasks.rel_id)
        WHEN "expense" THEN (SELECT CASE expense_name WHEN "" THEN tblexpenses_categories.name ELSE
         CONCAT(tblexpenses_categories.name, ' (', tblexpenses.expense_name, ')') END FROM tblexpenses JOIN tblexpenses_categories ON tblexpenses_categories.id = tblexpenses.category WHERE tblexpenses.id=tbltasks.rel_id)
        ELSE NULL
        END) as rel_name, rel_id, status, milestone, CASE WHEN duedate IS NULL THEN startdate ELSE duedate END as date, `id`
FROM `tbltasks`, `tbloptions`
WHERE `status` != 5
AND CASE WHEN duedate IS NULL THEN (startdate BETWEEN '2023-11-26' AND '2024-01-07') ELSE (duedate BETWEEN '2023-11-26' AND '2024-01-07') END
AND `name` = 'calendar_only_assigned_tasks'
ERROR - 2023-12-12 19:02:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`
FROM `tblprojects`
WHERE `clientid` IN()
ERROR - 2023-12-12 19:07:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`
FROM `tblprojects`
WHERE `clientid` IN()
ERROR - 2023-12-12 19:08:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`
FROM `tblprojects`
WHERE `clientid` IN()
ERROR - 2023-12-12 19:13:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`
FROM `tblprojects`
WHERE `clientid` IN()
ERROR - 2023-12-12 19:13:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`
FROM `tblprojects`
WHERE `clientid` IN()
