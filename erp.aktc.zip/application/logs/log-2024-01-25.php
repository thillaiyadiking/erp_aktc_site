<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-01-25 06:36:23 --> Could not find the language line "Branches"
ERROR - 2024-01-25 06:36:23 --> Could not find the language line "Branches"
ERROR - 2024-01-25 06:36:24 --> Could not find the language line "Branches"
ERROR - 2024-01-25 06:36:24 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-25 06:36:24 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-25 06:36:24 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-25 06:36:24 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-25 06:36:40 --> Could not find the language line "Branches"
ERROR - 2024-01-25 06:36:42 --> Could not find the language line "Branches"
ERROR - 2024-01-25 06:36:42 --> Could not find the language line "Branches"
ERROR - 2024-01-25 06:53:09 --> Could not find the language line "Branches"
ERROR - 2024-01-25 06:53:10 --> Could not find the language line "Branches"
ERROR - 2024-01-25 06:53:10 --> Could not find the language line "Branches"
ERROR - 2024-01-25 06:53:34 --> Could not find the language line "Branches"
ERROR - 2024-01-25 06:53:35 --> Could not find the language line "Branches"
ERROR - 2024-01-25 06:53:36 --> Could not find the language line "Branches"
ERROR - 2024-01-25 06:53:59 --> Could not find the language line "Branches"
ERROR - 2024-01-25 06:54:00 --> Could not find the language line "Branches"
ERROR - 2024-01-25 06:54:00 --> Could not find the language line "Branches"
ERROR - 2024-01-25 06:54:00 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-25 06:54:00 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-25 06:54:00 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-25 06:54:00 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-25 06:54:01 --> Could not find the language line "Branches"
ERROR - 2024-01-25 06:54:02 --> Could not find the language line "Branches"
ERROR - 2024-01-25 06:54:02 --> Could not find the language line "Branches"
ERROR - 2024-01-25 06:54:04 --> Could not find the language line "Branches"
ERROR - 2024-01-25 06:54:05 --> Could not find the language line "Branches"
ERROR - 2024-01-25 06:54:05 --> Could not find the language line "Assign to"
ERROR - 2024-01-25 06:54:05 --> Could not find the language line "Select"
ERROR - 2024-01-25 06:54:05 --> Could not find the language line "features"
ERROR - 2024-01-25 06:54:05 --> Could not find the language line "Branches"
ERROR - 2024-01-25 06:54:10 --> Could not find the language line "Branches"
ERROR - 2024-01-25 06:54:10 --> Could not find the language line "Branches"
ERROR - 2024-01-25 06:54:10 --> Could not find the language line "Branches"
ERROR - 2024-01-25 06:54:12 --> Could not find the language line "Branches"
ERROR - 2024-01-25 06:54:12 --> Could not find the language line "Branches"
ERROR - 2024-01-25 06:54:12 --> Could not find the language line "Assign to"
ERROR - 2024-01-25 06:54:12 --> Could not find the language line "Select"
ERROR - 2024-01-25 06:54:12 --> Could not find the language line "features"
ERROR - 2024-01-25 06:54:13 --> Could not find the language line "Branches"
ERROR - 2024-01-25 06:54:17 --> Could not find the language line "Branches"
ERROR - 2024-01-25 06:54:17 --> Could not find the language line "Branches"
ERROR - 2024-01-25 06:54:18 --> Could not find the language line "Branches"
ERROR - 2024-01-25 06:54:21 --> Could not find the language line "Branches"
ERROR - 2024-01-25 06:54:21 --> Could not find the language line "Branches"
ERROR - 2024-01-25 06:54:21 --> Could not find the language line "Assign to"
ERROR - 2024-01-25 06:54:21 --> Could not find the language line "Select"
ERROR - 2024-01-25 06:54:21 --> Could not find the language line "features"
ERROR - 2024-01-25 06:54:22 --> Could not find the language line "Branches"
ERROR - 2024-01-25 06:55:06 --> Could not find the language line "Branches"
ERROR - 2024-01-25 06:55:07 --> Could not find the language line "Branches"
ERROR - 2024-01-25 06:55:08 --> Could not find the language line "Branches"
ERROR - 2024-01-25 06:55:08 --> Could not find the language line "Branches"
ERROR - 2024-01-25 06:55:08 --> Could not find the language line "Assign to"
ERROR - 2024-01-25 06:55:08 --> Could not find the language line "Select"
ERROR - 2024-01-25 06:55:08 --> Could not find the language line "features"
ERROR - 2024-01-25 06:55:09 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:15:17 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:15:17 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:15:17 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:15:17 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-25 07:15:17 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-25 07:15:17 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-25 07:15:17 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-25 07:16:02 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:16:03 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:16:04 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:16:09 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:16:09 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:17:36 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:17:37 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:17:57 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:17:58 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:18:00 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:18:01 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:18:22 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:18:23 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:18:25 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:18:26 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:18:37 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:18:37 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:18:40 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:18:41 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:18:42 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:18:43 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:18:52 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:18:52 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:20:36 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:20:36 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:20:36 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:20:36 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-25 07:20:36 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-25 07:20:36 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-25 07:20:36 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-25 07:31:02 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:31:02 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:31:02 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:31:02 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-25 07:31:02 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-25 07:31:02 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-25 07:31:02 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-25 07:31:09 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:31:15 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:31:34 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:31:36 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:31:36 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:31:39 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:31:39 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:31:39 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:31:39 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-25 07:31:40 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-25 07:31:40 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-25 07:31:40 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-25 07:31:59 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:31:59 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:31:59 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:31:59 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-25 07:31:59 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-25 07:31:59 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-25 07:31:59 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-25 07:47:32 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:47:40 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:47:46 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:48:01 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:48:01 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:48:01 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:48:02 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-25 07:48:02 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-25 07:48:02 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-25 07:48:02 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-25 07:48:07 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:48:26 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:48:56 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:49:08 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:49:08 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:49:08 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:49:17 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:50:48 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:50:49 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:50:49 --> Could not find the language line "Assign to"
ERROR - 2024-01-25 07:50:49 --> Could not find the language line "Select"
ERROR - 2024-01-25 07:50:49 --> Could not find the language line "features"
ERROR - 2024-01-25 07:50:49 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:51:29 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:51:29 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:51:29 --> Could not find the language line "Assign to"
ERROR - 2024-01-25 07:51:29 --> Could not find the language line "Select"
ERROR - 2024-01-25 07:51:29 --> Could not find the language line "features"
ERROR - 2024-01-25 07:51:30 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:52:13 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:52:13 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:52:13 --> Could not find the language line "Assign to"
ERROR - 2024-01-25 07:52:13 --> Could not find the language line "Select"
ERROR - 2024-01-25 07:52:13 --> Could not find the language line "features"
ERROR - 2024-01-25 07:52:14 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:52:35 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:52:35 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:52:36 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:52:38 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:52:38 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:52:38 --> Could not find the language line "Assign to"
ERROR - 2024-01-25 07:52:38 --> Could not find the language line "Select"
ERROR - 2024-01-25 07:52:38 --> Severity: Notice --> Undefined variable: assigned_branches C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 205
ERROR - 2024-01-25 07:52:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 205
ERROR - 2024-01-25 07:52:38 --> Severity: Notice --> Undefined variable: assigned_branches C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 205
ERROR - 2024-01-25 07:52:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 205
ERROR - 2024-01-25 07:52:38 --> Severity: Notice --> Undefined variable: assigned_branches C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 205
ERROR - 2024-01-25 07:52:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 205
ERROR - 2024-01-25 07:52:38 --> Severity: Notice --> Undefined variable: assigned_branches C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 205
ERROR - 2024-01-25 07:52:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 205
ERROR - 2024-01-25 07:52:38 --> Could not find the language line "features"
ERROR - 2024-01-25 07:52:54 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:52:57 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:52:58 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:53:00 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:53:31 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:53:31 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:53:32 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:54:53 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:54:55 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:54:55 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:54:56 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:54:58 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:55:00 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:55:03 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:55:04 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:55:59 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:55:59 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:55:59 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:56:02 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:56:02 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:56:03 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:56:07 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:56:07 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:56:07 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:56:48 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:56:50 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:56:50 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:57:14 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:57:17 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:57:17 --> Could not find the language line "Branches"
ERROR - 2024-01-25 07:57:17 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:00:21 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:00:21 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:02:29 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:02:29 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:02:30 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:02:30 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:02:31 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:02:35 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:02:36 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:02:38 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:02:44 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:03:18 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:03:18 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:03:20 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:03:25 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:03:48 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:03:49 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:04:18 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:04:20 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:04:20 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:04:20 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:05:16 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:05:16 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:05:17 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:05:19 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:05:26 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:05:27 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:05:27 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:05:27 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:06:58 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:06:58 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:08:09 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:08:09 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:08:11 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:08:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '"AND type ="sender" AND rel_type="tickets"
    
    ORDER BY value ASC
   ...' at line 5 - Invalid query: 
    SELECT SQL_CALC_FOUND_ROWS value ,id
    FROM tblspam_filters
    
    
    "AND type ="sender" AND rel_type="tickets"
    
    ORDER BY value ASC
    LIMIT 0, 25
    
ERROR - 2024-01-25 08:08:11 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:08:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '"AND type ="subject" AND rel_type="tickets"
    
    ORDER BY value ASC
  ...' at line 5 - Invalid query: 
    SELECT SQL_CALC_FOUND_ROWS value ,id
    FROM tblspam_filters
    
    
    "AND type ="subject" AND rel_type="tickets"
    
    ORDER BY value ASC
    LIMIT 0, 25
    
ERROR - 2024-01-25 08:08:11 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:08:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '"AND type ="phrase" AND rel_type="tickets"
    
    ORDER BY value ASC
   ...' at line 5 - Invalid query: 
    SELECT SQL_CALC_FOUND_ROWS value ,id
    FROM tblspam_filters
    
    
    "AND type ="phrase" AND rel_type="tickets"
    
    ORDER BY value ASC
    LIMIT 0, 25
    
ERROR - 2024-01-25 08:09:13 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:09:13 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:09:15 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:09:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '"AND type ="sender" AND rel_type="tickets"
    
    ORDER BY value ASC
   ...' at line 5 - Invalid query: 
    SELECT SQL_CALC_FOUND_ROWS value ,id
    FROM tblspam_filters
    
    
    "AND type ="sender" AND rel_type="tickets"
    
    ORDER BY value ASC
    LIMIT 0, 25
    
ERROR - 2024-01-25 08:09:15 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:09:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '"AND type ="subject" AND rel_type="tickets"
    
    ORDER BY value ASC
  ...' at line 5 - Invalid query: 
    SELECT SQL_CALC_FOUND_ROWS value ,id
    FROM tblspam_filters
    
    
    "AND type ="subject" AND rel_type="tickets"
    
    ORDER BY value ASC
    LIMIT 0, 25
    
ERROR - 2024-01-25 08:09:15 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:09:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '"AND type ="phrase" AND rel_type="tickets"
    
    ORDER BY value ASC
   ...' at line 5 - Invalid query: 
    SELECT SQL_CALC_FOUND_ROWS value ,id
    FROM tblspam_filters
    
    
    "AND type ="phrase" AND rel_type="tickets"
    
    ORDER BY value ASC
    LIMIT 0, 25
    
ERROR - 2024-01-25 08:10:35 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:10:35 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:10:36 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:10:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '"AND type ="sender" AND rel_type="tickets"
    
    ORDER BY value ASC
   ...' at line 5 - Invalid query: 
    SELECT SQL_CALC_FOUND_ROWS value ,id
    FROM tblspam_filters
    
    
    "AND type ="sender" AND rel_type="tickets"
    
    ORDER BY value ASC
    LIMIT 0, 25
    
ERROR - 2024-01-25 08:10:37 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:10:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '"AND type ="subject" AND rel_type="tickets"
    
    ORDER BY value ASC
  ...' at line 5 - Invalid query: 
    SELECT SQL_CALC_FOUND_ROWS value ,id
    FROM tblspam_filters
    
    
    "AND type ="subject" AND rel_type="tickets"
    
    ORDER BY value ASC
    LIMIT 0, 25
    
ERROR - 2024-01-25 08:10:37 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:10:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '"AND type ="phrase" AND rel_type="tickets"
    
    ORDER BY value ASC
   ...' at line 5 - Invalid query: 
    SELECT SQL_CALC_FOUND_ROWS value ,id
    FROM tblspam_filters
    
    
    "AND type ="phrase" AND rel_type="tickets"
    
    ORDER BY value ASC
    LIMIT 0, 25
    
ERROR - 2024-01-25 08:10:49 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:10:49 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:10:50 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:10:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '"type ="sender" AND rel_type="tickets"
    
    ORDER BY value ASC
    LIM...' at line 5 - Invalid query: 
    SELECT SQL_CALC_FOUND_ROWS value ,id
    FROM tblspam_filters
    
    
    "type ="sender" AND rel_type="tickets"
    
    ORDER BY value ASC
    LIMIT 0, 25
    
ERROR - 2024-01-25 08:10:51 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:10:51 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '"type ="subject" AND rel_type="tickets"
    
    ORDER BY value ASC
    LI...' at line 5 - Invalid query: 
    SELECT SQL_CALC_FOUND_ROWS value ,id
    FROM tblspam_filters
    
    
    "type ="subject" AND rel_type="tickets"
    
    ORDER BY value ASC
    LIMIT 0, 25
    
ERROR - 2024-01-25 08:10:51 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:10:51 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '"type ="phrase" AND rel_type="tickets"
    
    ORDER BY value ASC
    LIM...' at line 5 - Invalid query: 
    SELECT SQL_CALC_FOUND_ROWS value ,id
    FROM tblspam_filters
    
    
    "type ="phrase" AND rel_type="tickets"
    
    ORDER BY value ASC
    LIMIT 0, 25
    
ERROR - 2024-01-25 08:11:11 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:11:11 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:11:12 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:11:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '="sender" AND rel_type="tickets"
    
    ORDER BY value ASC
    LIMIT 0, 25' at line 5 - Invalid query: 
    SELECT SQL_CALC_FOUND_ROWS value ,id
    FROM tblspam_filters
    
    
    type ="sender" AND rel_type="tickets"
    
    ORDER BY value ASC
    LIMIT 0, 25
    
ERROR - 2024-01-25 08:11:12 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:11:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '="subject" AND rel_type="tickets"
    
    ORDER BY value ASC
    LIMIT 0, 25' at line 5 - Invalid query: 
    SELECT SQL_CALC_FOUND_ROWS value ,id
    FROM tblspam_filters
    
    
    type ="subject" AND rel_type="tickets"
    
    ORDER BY value ASC
    LIMIT 0, 25
    
ERROR - 2024-01-25 08:11:12 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:11:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '="phrase" AND rel_type="tickets"
    
    ORDER BY value ASC
    LIMIT 0, 25' at line 5 - Invalid query: 
    SELECT SQL_CALC_FOUND_ROWS value ,id
    FROM tblspam_filters
    
    
    type ="phrase" AND rel_type="tickets"
    
    ORDER BY value ASC
    LIMIT 0, 25
    
ERROR - 2024-01-25 08:12:30 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:12:30 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:12:32 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:12:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '"AND type ="sender" AND rel_type="tickets"
    
    ORDER BY value ASC
   ...' at line 5 - Invalid query: 
    SELECT SQL_CALC_FOUND_ROWS value ,id
    FROM tblspam_filters
    
    
    "AND type ="sender" AND rel_type="tickets"
    
    ORDER BY value ASC
    LIMIT 0, 25
    
ERROR - 2024-01-25 08:12:32 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:12:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '"AND type ="subject" AND rel_type="tickets"
    
    ORDER BY value ASC
  ...' at line 5 - Invalid query: 
    SELECT SQL_CALC_FOUND_ROWS value ,id
    FROM tblspam_filters
    
    
    "AND type ="subject" AND rel_type="tickets"
    
    ORDER BY value ASC
    LIMIT 0, 25
    
ERROR - 2024-01-25 08:12:32 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:12:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '"AND type ="phrase" AND rel_type="tickets"
    
    ORDER BY value ASC
   ...' at line 5 - Invalid query: 
    SELECT SQL_CALC_FOUND_ROWS value ,id
    FROM tblspam_filters
    
    
    "AND type ="phrase" AND rel_type="tickets"
    
    ORDER BY value ASC
    LIMIT 0, 25
    
ERROR - 2024-01-25 08:12:52 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:12:52 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:12:53 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:12:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '"type ="sender" AND rel_type="tickets"
    
    ORDER BY value ASC
    LIM...' at line 5 - Invalid query: 
    SELECT SQL_CALC_FOUND_ROWS value ,id
    FROM tblspam_filters
    
    
    "type ="sender" AND rel_type="tickets"
    
    ORDER BY value ASC
    LIMIT 0, 25
    
ERROR - 2024-01-25 08:12:53 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:12:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '"type ="subject" AND rel_type="tickets"
    
    ORDER BY value ASC
    LI...' at line 5 - Invalid query: 
    SELECT SQL_CALC_FOUND_ROWS value ,id
    FROM tblspam_filters
    
    
    "type ="subject" AND rel_type="tickets"
    
    ORDER BY value ASC
    LIMIT 0, 25
    
ERROR - 2024-01-25 08:12:54 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:12:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '"type ="phrase" AND rel_type="tickets"
    
    ORDER BY value ASC
    LIM...' at line 5 - Invalid query: 
    SELECT SQL_CALC_FOUND_ROWS value ,id
    FROM tblspam_filters
    
    
    "type ="phrase" AND rel_type="tickets"
    
    ORDER BY value ASC
    LIMIT 0, 25
    
ERROR - 2024-01-25 08:13:25 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:13:25 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:13:26 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:13:27 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:13:27 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:15:45 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:15:45 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:15:46 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:15:46 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:15:46 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:15:51 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:15:51 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:16:46 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:16:46 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:16:47 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:16:47 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:16:47 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:25:10 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:25:10 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:25:13 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:25:13 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:25:13 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:26:27 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:26:27 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:26:28 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:26:28 --> Could not find the language line "Branches"
ERROR - 2024-01-25 08:26:28 --> Could not find the language line "Branches"
