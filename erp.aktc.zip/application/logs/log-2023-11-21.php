<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-21 04:00:20 --> Query error: Unknown column 'value' in 'field list' - Invalid query: SELECT `name`, `value`
FROM `tbloptions`
ERROR - 2023-11-21 04:03:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query: SELECT name,tblbranch_options.value FROM tblbranch_options LEFT JOIN tbloptions ON tblbranch_options.option_id = tbloptions.id WHERE tblbranch_options.branch_id=
ERROR - 2023-11-21 04:05:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query: SELECT name,tblbranch_options.value FROM tblbranch_options LEFT JOIN tbloptions ON tblbranch_options.option_id = tbloptions.id WHERE tblbranch_options.branch_id=
ERROR - 2023-11-21 04:05:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query: SELECT name,tblbranch_options.value FROM tblbranch_options LEFT JOIN tbloptions ON tblbranch_options.option_id = tbloptions.id WHERE tblbranch_options.branch_id=
ERROR - 2023-11-21 06:22:31 --> Severity: Notice --> Undefined variable: staff_members C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 59
ERROR - 2023-11-21 06:22:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 334
ERROR - 2023-11-21 06:23:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\libraries\App.php 277
ERROR - 2023-11-21 06:31:45 --> Severity: Notice --> Undefined variable: staff_members C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 59
ERROR - 2023-11-21 06:31:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 334
ERROR - 2023-11-21 06:32:11 --> Severity: Notice --> Undefined variable: staff_members C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 59
ERROR - 2023-11-21 06:32:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 334
ERROR - 2023-11-21 06:32:54 --> Severity: Notice --> Undefined variable: staff_members C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 59
ERROR - 2023-11-21 06:32:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 334
ERROR - 2023-11-21 06:32:57 --> Severity: Notice --> Undefined variable: staff_members C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 59
ERROR - 2023-11-21 06:32:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 334
ERROR - 2023-11-21 06:33:04 --> Severity: Notice --> Undefined variable: staff_members C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 59
ERROR - 2023-11-21 06:33:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 334
ERROR - 2023-11-21 06:33:09 --> Severity: Notice --> Undefined variable: staff_members C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 59
ERROR - 2023-11-21 06:33:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 334
ERROR - 2023-11-21 06:35:29 --> Severity: Notice --> Undefined variable: staff_members C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 59
ERROR - 2023-11-21 06:35:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 334
ERROR - 2023-11-21 06:35:33 --> Severity: Notice --> Undefined variable: staff_members C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 59
ERROR - 2023-11-21 06:35:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 334
ERROR - 2023-11-21 06:36:03 --> Severity: Notice --> Undefined variable: staff_members C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 59
ERROR - 2023-11-21 06:36:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 334
ERROR - 2023-11-21 06:36:07 --> Severity: Notice --> Undefined variable: staff_members C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 59
ERROR - 2023-11-21 06:36:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 334
ERROR - 2023-11-21 06:36:23 --> Severity: Notice --> Undefined variable: staff_members C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 59
ERROR - 2023-11-21 06:36:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 334
ERROR - 2023-11-21 06:37:42 --> Severity: Notice --> Undefined variable: staff_members C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 59
ERROR - 2023-11-21 06:37:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 334
ERROR - 2023-11-21 06:37:45 --> Severity: Notice --> Undefined variable: staff_members C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 59
ERROR - 2023-11-21 06:37:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 334
ERROR - 2023-11-21 06:38:33 --> Severity: Notice --> Undefined variable: staff_members C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 59
ERROR - 2023-11-21 06:38:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 334
ERROR - 2023-11-21 06:39:10 --> Severity: Notice --> Undefined variable: staff_members C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 59
ERROR - 2023-11-21 06:39:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 334
