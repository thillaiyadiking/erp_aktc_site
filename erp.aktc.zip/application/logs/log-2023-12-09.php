<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-12-09 05:57:04 --> Severity: Notice --> Array to string conversion C:\xampp-new\htdocs\finishizer_erp3.0.5\system\database\DB_query_builder.php 838
ERROR - 2023-12-09 05:57:04 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `tblproject_activity`
WHERE `project_id` IN(Array)
ORDER BY `dateadded` DESC
 LIMIT 20
ERROR - 2023-12-09 05:57:33 --> Severity: Notice --> Array to string conversion C:\xampp-new\htdocs\finishizer_erp3.0.5\system\database\DB_query_builder.php 838
ERROR - 2023-12-09 05:57:33 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `tblproject_activity`
WHERE `project_id` IN(Array)
ORDER BY `dateadded` DESC
 LIMIT 20
ERROR - 2023-12-09 05:58:28 --> Severity: Notice --> Array to string conversion C:\xampp-new\htdocs\finishizer_erp3.0.5\application\models\Projects_model.php 2263
ERROR - 2023-12-09 06:01:19 --> Severity: Warning --> explode() expects parameter 2 to be string, array given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\models\Projects_model.php 2264
ERROR - 2023-12-09 06:03:38 --> Severity: Notice --> Array to string conversion C:\xampp-new\htdocs\finishizer_erp3.0.5\system\database\DB_query_builder.php 838
ERROR - 2023-12-09 06:03:38 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `tblproject_activity`
WHERE `project_id` IN(Array)
ORDER BY `dateadded` DESC
 LIMIT 20
ERROR - 2023-12-09 06:05:58 --> Severity: Notice --> Array to string conversion C:\xampp-new\htdocs\finishizer_erp3.0.5\system\database\DB_query_builder.php 838
ERROR - 2023-12-09 06:05:58 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `tblproject_activity`
WHERE `project_id` IN(Array)
ORDER BY `dateadded` DESC
 LIMIT 20
ERROR - 2023-12-09 06:08:42 --> Severity: Notice --> Array to string conversion C:\xampp-new\htdocs\finishizer_erp3.0.5\system\database\DB_query_builder.php 838
ERROR - 2023-12-09 06:08:42 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `tblproject_activity`
WHERE `project_id` IN(Array)
ORDER BY `dateadded` DESC
 LIMIT 20
ERROR - 2023-12-09 07:43:05 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\libraries\App.php 283
ERROR - 2023-12-09 09:22:53 --> Severity: Notice --> Undefined variable: branch_clients C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 19
ERROR - 2023-12-09 09:22:53 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 19
ERROR - 2023-12-09 09:22:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `status` NOT IN (5,6) AND `clientid` IN ()
ERROR - 2023-12-09 09:23:35 --> Severity: Notice --> Undefined variable: branch_clients C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 19
ERROR - 2023-12-09 09:23:35 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 19
ERROR - 2023-12-09 09:23:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `status` NOT IN (5,6) AND `clientid` IN ()
ERROR - 2023-12-09 09:35:51 --> Severity: Notice --> Undefined property: stdClass::$currency_id C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 23
ERROR - 2023-12-09 09:35:51 --> Severity: Notice --> Undefined variable: currencies C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 24
ERROR - 2023-12-09 09:35:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 334
ERROR - 2023-12-09 09:35:57 --> Severity: Notice --> Undefined variable: currencies C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 24
ERROR - 2023-12-09 09:35:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 334
ERROR - 2023-12-09 09:37:21 --> Severity: Notice --> Undefined variable: branch_clients C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 19
ERROR - 2023-12-09 09:37:21 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 19
ERROR - 2023-12-09 09:37:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `status` NOT IN (5,6) AND `clientid` IN ()
ERROR - 2023-12-09 09:38:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `status` NOT IN (5,6) AND `clientid` IN ()
