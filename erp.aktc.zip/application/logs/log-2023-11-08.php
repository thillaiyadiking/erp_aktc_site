<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-08 04:38:39 --> Severity: error --> Exception: Too few arguments to function Dashboard::branch_dashboard(), 0 passed in C:\xampp-new\htdocs\finishizer_erp3.0.5\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Dashboard.php 95
ERROR - 2023-11-08 05:10:18 --> 404 Page Not Found: 
ERROR - 2023-11-08 05:22:52 --> Severity: error --> Exception: Too few arguments to function Dashboard::branch_dashboard(), 0 passed in C:\xampp-new\htdocs\finishizer_erp3.0.5\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Dashboard.php 97
ERROR - 2023-11-08 05:27:49 --> Severity: error --> Exception: Too few arguments to function Dashboard::branch_dashboard(), 0 passed in C:\xampp-new\htdocs\finishizer_erp3.0.5\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Dashboard.php 97
