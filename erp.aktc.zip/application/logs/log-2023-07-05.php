<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-05 00:09:44 --> Could not find the language line "branches"
ERROR - 2023-07-05 00:09:50 --> Could not find the language line "branches"
ERROR - 2023-07-05 00:09:50 --> Could not find the language line "branches"
ERROR - 2023-07-05 00:09:56 --> Could not find the language line "branches"
ERROR - 2023-07-05 00:09:56 --> Could not find the language line "features"
ERROR - 2023-07-05 00:09:57 --> Could not find the language line "branches"
ERROR - 2023-07-05 00:10:23 --> Could not find the language line "branches"
ERROR - 2023-07-05 00:10:30 --> Could not find the language line "branches"
ERROR - 2023-07-05 00:10:31 --> Could not find the language line "branches"
ERROR - 2023-07-05 00:10:31 --> Could not find the language line "features"
ERROR - 2023-07-05 00:10:32 --> Could not find the language line "branches"
ERROR - 2023-07-05 00:55:35 --> Could not find the language line "branches"
ERROR - 2023-07-05 00:55:36 --> Could not find the language line "branches"
ERROR - 2023-07-05 00:55:36 --> Could not find the language line "branches"
ERROR - 2023-07-05 00:56:35 --> Could not find the language line "branches"
ERROR - 2023-07-05 00:56:41 --> Could not find the language line "branches"
ERROR - 2023-07-05 00:56:41 --> Could not find the language line "branches"
ERROR - 2023-07-05 00:56:44 --> Could not find the language line "branches"
ERROR - 2023-07-05 00:56:44 --> Could not find the language line "features"
ERROR - 2023-07-05 00:56:47 --> Could not find the language line "branches"
ERROR - 2023-07-05 01:16:08 --> Could not find the language line "branches"
ERROR - 2023-07-05 01:16:09 --> Could not find the language line "branches"
ERROR - 2023-07-05 01:16:09 --> Could not find the language line "branches"
ERROR - 2023-07-05 01:22:52 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\finishizer_erp3.0.5\application\controllers\admin\Authentication.php 79
ERROR - 2023-07-05 01:23:38 --> Could not find the language line "branches"
ERROR - 2023-07-05 01:23:39 --> Could not find the language line "branches"
ERROR - 2023-07-05 01:23:39 --> Could not find the language line "branches"
ERROR - 2023-07-05 01:23:40 --> Could not find the language line "branches"
ERROR - 2023-07-05 01:23:41 --> Could not find the language line "branches"
ERROR - 2023-07-05 01:23:41 --> Could not find the language line "branches"
ERROR - 2023-07-05 01:23:58 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\finishizer_erp3.0.5\application\controllers\admin\Authentication.php 92
ERROR - 2023-07-05 01:29:05 --> Could not find the language line "branches"
ERROR - 2023-07-05 01:29:06 --> Could not find the language line "branches"
ERROR - 2023-07-05 01:29:06 --> Could not find the language line "branches"
ERROR - 2023-07-05 01:29:31 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\finishizer_erp3.0.5\application\controllers\admin\Authentication.php 80
ERROR - 2023-07-05 01:30:44 --> Could not find the language line "branches"
ERROR - 2023-07-05 01:30:46 --> Could not find the language line "branches"
ERROR - 2023-07-05 01:30:46 --> Could not find the language line "branches"
ERROR - 2023-07-05 01:31:00 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\finishizer_erp3.0.5\application\controllers\admin\Authentication.php 94
ERROR - 2023-07-05 01:33:10 --> Could not find the language line "branches"
ERROR - 2023-07-05 01:33:11 --> Could not find the language line "branches"
ERROR - 2023-07-05 01:33:13 --> Could not find the language line "branches"
ERROR - 2023-07-05 01:33:29 --> Could not find the language line "branches"
ERROR - 2023-07-05 01:33:29 --> Could not find the language line "branches"
ERROR - 2023-07-05 01:33:30 --> Could not find the language line "branches"
ERROR - 2023-07-05 01:34:54 --> Could not find the language line "branches"
ERROR - 2023-07-05 01:34:55 --> Could not find the language line "branches"
ERROR - 2023-07-05 01:34:55 --> Could not find the language line "branches"
ERROR - 2023-07-05 01:35:00 --> Could not find the language line "branches"
ERROR - 2023-07-05 01:35:05 --> Could not find the language line "branches"
ERROR - 2023-07-05 01:35:06 --> Could not find the language line "branches"
ERROR - 2023-07-05 01:35:12 --> Could not find the language line "branches"
ERROR - 2023-07-05 01:35:12 --> Could not find the language line "features"
ERROR - 2023-07-05 01:35:13 --> Could not find the language line "branches"
ERROR - 2023-07-05 01:35:32 --> Could not find the language line "branches"
ERROR - 2023-07-05 01:35:33 --> Could not find the language line "branches"
ERROR - 2023-07-05 01:35:33 --> Could not find the language line "branches"
ERROR - 2023-07-05 01:35:33 --> Could not find the language line "features"
ERROR - 2023-07-05 01:35:34 --> Could not find the language line "branches"
ERROR - 2023-07-05 01:35:35 --> Could not find the language line "branches"
ERROR - 2023-07-05 01:35:35 --> Could not find the language line "branches"
ERROR - 2023-07-05 01:35:35 --> Could not find the language line "branches"
ERROR - 2023-07-05 01:35:35 --> Could not find the language line "features"
ERROR - 2023-07-05 01:35:36 --> Could not find the language line "branches"
ERROR - 2023-07-05 01:36:08 --> Could not find the language line "branches"
ERROR - 2023-07-05 01:36:08 --> Could not find the language line "branches"
ERROR - 2023-07-05 01:36:17 --> Could not find the language line "branches"
ERROR - 2023-07-05 01:36:17 --> Could not find the language line "features"
ERROR - 2023-07-05 01:36:17 --> Could not find the language line "branches"
ERROR - 2023-07-05 01:38:04 --> Severity: Warning --> Illegal string offset 'title' C:\xampp\htdocs\finishizer_erp3.0.5\application\controllers\admin\Authentication.php 94
ERROR - 2023-07-05 22:18:58 --> Severity: Notice --> Undefined index: admin C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\assets\App_css.php 46
ERROR - 2023-07-05 22:18:58 --> Severity: Warning --> array_keys() expects parameter 1 to be array, null given C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\assets\App_css.php 46
ERROR - 2023-07-05 22:18:58 --> Severity: Notice --> Undefined variable: current_user C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\head.php 18
ERROR - 2023-07-05 22:18:58 --> Severity: Notice --> Trying to get property 'total_unread_notifications' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\head.php 18
ERROR - 2023-07-05 22:18:58 --> Severity: Notice --> Undefined variable: current_user C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\header.php 169
ERROR - 2023-07-05 22:18:58 --> Severity: Notice --> Trying to get property 'total_unfinished_todos' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\header.php 169
ERROR - 2023-07-05 22:18:58 --> Severity: Notice --> Undefined variable: current_user C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\header.php 170
ERROR - 2023-07-05 22:18:58 --> Severity: Notice --> Trying to get property 'total_unfinished_todos' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\header.php 170
ERROR - 2023-07-05 22:18:58 --> Severity: Notice --> Undefined variable: current_user C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\header.php 179
ERROR - 2023-07-05 22:18:58 --> Severity: Notice --> Trying to get property 'staffid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\header.php 179
ERROR - 2023-07-05 22:18:58 --> Severity: Notice --> Undefined variable: current_user C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\header.php 194
ERROR - 2023-07-05 22:18:58 --> Severity: Notice --> Trying to get property 'default_language' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\header.php 194
ERROR - 2023-07-05 22:18:58 --> Severity: Notice --> Undefined variable: current_user C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\header.php 201
ERROR - 2023-07-05 22:18:58 --> Severity: Notice --> Trying to get property 'default_language' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\header.php 201
ERROR - 2023-07-05 22:18:58 --> Severity: Notice --> Undefined variable: current_user C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\notifications.php 10
ERROR - 2023-07-05 22:18:58 --> Severity: Notice --> Trying to get property 'total_unread_notifications' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\notifications.php 10
ERROR - 2023-07-05 22:18:58 --> Severity: Notice --> Undefined variable: current_user C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\notifications.php 18
ERROR - 2023-07-05 22:18:58 --> Severity: Notice --> Trying to get property 'total_unread_notifications' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\notifications.php 18
ERROR - 2023-07-05 22:18:58 --> Severity: Notice --> Undefined variable: setup_menu C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\setup_menu.php 13
ERROR - 2023-07-05 22:18:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\setup_menu.php 13
ERROR - 2023-07-05 22:18:58 --> Severity: Notice --> Undefined variable: sidebar_menu C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\aside.php 12
ERROR - 2023-07-05 22:18:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\aside.php 12
ERROR - 2023-07-05 22:18:59 --> Severity: Warning --> Illegal string offset 'title' C:\xampp\htdocs\finishizer_erp3.0.5\application\controllers\admin\Authentication.php 94
ERROR - 2023-07-05 22:23:47 --> Severity: Warning --> Illegal string offset 'title' C:\xampp\htdocs\finishizer_erp3.0.5\application\controllers\admin\Authentication.php 81
ERROR - 2023-07-05 22:23:47 --> Severity: Notice --> Undefined index: admin C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\assets\App_css.php 46
ERROR - 2023-07-05 22:23:47 --> Severity: Warning --> array_keys() expects parameter 1 to be array, null given C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\assets\App_css.php 46
ERROR - 2023-07-05 22:23:47 --> Severity: Notice --> Undefined variable: current_user C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\head.php 18
ERROR - 2023-07-05 22:23:47 --> Severity: Notice --> Trying to get property 'total_unread_notifications' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\head.php 18
ERROR - 2023-07-05 22:23:47 --> Severity: Notice --> Undefined variable: current_user C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\header.php 169
ERROR - 2023-07-05 22:23:47 --> Severity: Notice --> Trying to get property 'total_unfinished_todos' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\header.php 169
ERROR - 2023-07-05 22:23:47 --> Severity: Notice --> Undefined variable: current_user C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\header.php 170
ERROR - 2023-07-05 22:23:47 --> Severity: Notice --> Trying to get property 'total_unfinished_todos' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\header.php 170
ERROR - 2023-07-05 22:23:47 --> Severity: Notice --> Undefined variable: current_user C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\header.php 179
ERROR - 2023-07-05 22:23:47 --> Severity: Notice --> Trying to get property 'staffid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\header.php 179
ERROR - 2023-07-05 22:23:47 --> Severity: Notice --> Undefined variable: current_user C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\header.php 194
ERROR - 2023-07-05 22:23:47 --> Severity: Notice --> Trying to get property 'default_language' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\header.php 194
ERROR - 2023-07-05 22:23:47 --> Severity: Notice --> Undefined variable: current_user C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\header.php 201
ERROR - 2023-07-05 22:23:47 --> Severity: Notice --> Trying to get property 'default_language' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\header.php 201
ERROR - 2023-07-05 22:23:47 --> Severity: Notice --> Undefined variable: current_user C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\notifications.php 10
ERROR - 2023-07-05 22:23:47 --> Severity: Notice --> Trying to get property 'total_unread_notifications' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\notifications.php 10
ERROR - 2023-07-05 22:23:47 --> Severity: Notice --> Undefined variable: current_user C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\notifications.php 18
ERROR - 2023-07-05 22:23:47 --> Severity: Notice --> Trying to get property 'total_unread_notifications' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\notifications.php 18
ERROR - 2023-07-05 22:23:47 --> Severity: Notice --> Undefined variable: setup_menu C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\setup_menu.php 13
ERROR - 2023-07-05 22:23:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\setup_menu.php 13
ERROR - 2023-07-05 22:23:47 --> Severity: Notice --> Undefined variable: sidebar_menu C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\aside.php 12
ERROR - 2023-07-05 22:23:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\aside.php 12
ERROR - 2023-07-05 22:23:47 --> Severity: Warning --> Illegal string offset 'title' C:\xampp\htdocs\finishizer_erp3.0.5\application\controllers\admin\Authentication.php 95
ERROR - 2023-07-05 22:28:32 --> Severity: Notice --> Undefined index: admin C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\assets\App_css.php 46
ERROR - 2023-07-05 22:28:32 --> Severity: Warning --> array_keys() expects parameter 1 to be array, null given C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\assets\App_css.php 46
ERROR - 2023-07-05 22:28:32 --> Severity: Notice --> Undefined variable: current_user C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\head.php 18
ERROR - 2023-07-05 22:28:32 --> Severity: Notice --> Trying to get property 'total_unread_notifications' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\head.php 18
ERROR - 2023-07-05 22:28:32 --> Severity: Notice --> Undefined variable: current_user C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\header.php 169
ERROR - 2023-07-05 22:28:32 --> Severity: Notice --> Trying to get property 'total_unfinished_todos' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\header.php 169
ERROR - 2023-07-05 22:28:32 --> Severity: Notice --> Undefined variable: current_user C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\header.php 170
ERROR - 2023-07-05 22:28:32 --> Severity: Notice --> Trying to get property 'total_unfinished_todos' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\header.php 170
ERROR - 2023-07-05 22:28:32 --> Severity: Notice --> Undefined variable: current_user C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\header.php 179
ERROR - 2023-07-05 22:28:32 --> Severity: Notice --> Trying to get property 'staffid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\header.php 179
ERROR - 2023-07-05 22:28:32 --> Severity: Notice --> Undefined variable: current_user C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\header.php 194
ERROR - 2023-07-05 22:28:32 --> Severity: Notice --> Trying to get property 'default_language' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\header.php 194
ERROR - 2023-07-05 22:28:32 --> Severity: Notice --> Undefined variable: current_user C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\header.php 201
ERROR - 2023-07-05 22:28:32 --> Severity: Notice --> Trying to get property 'default_language' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\header.php 201
ERROR - 2023-07-05 22:28:32 --> Severity: Notice --> Undefined variable: current_user C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\notifications.php 10
ERROR - 2023-07-05 22:28:32 --> Severity: Notice --> Trying to get property 'total_unread_notifications' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\notifications.php 10
ERROR - 2023-07-05 22:28:32 --> Severity: Notice --> Undefined variable: current_user C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\notifications.php 18
ERROR - 2023-07-05 22:28:32 --> Severity: Notice --> Trying to get property 'total_unread_notifications' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\notifications.php 18
ERROR - 2023-07-05 22:28:32 --> Severity: Notice --> Undefined variable: setup_menu C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\setup_menu.php 13
ERROR - 2023-07-05 22:28:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\setup_menu.php 13
ERROR - 2023-07-05 22:28:32 --> Severity: Notice --> Undefined variable: sidebar_menu C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\aside.php 12
ERROR - 2023-07-05 22:28:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\aside.php 12
ERROR - 2023-07-05 22:28:32 --> Severity: Warning --> Illegal string offset 'title' C:\xampp\htdocs\finishizer_erp3.0.5\application\controllers\admin\Authentication.php 93
ERROR - 2023-07-05 22:49:46 --> Could not find the language line "branches"
ERROR - 2023-07-05 22:49:48 --> Could not find the language line "branches"
ERROR - 2023-07-05 22:49:49 --> Could not find the language line "branches"
ERROR - 2023-07-05 22:49:53 --> Could not find the language line "branches"
ERROR - 2023-07-05 22:49:54 --> Could not find the language line "branches"
ERROR - 2023-07-05 22:49:54 --> Could not find the language line "branches"
ERROR - 2023-07-05 22:50:06 --> Severity: error --> Exception: Call to undefined function is_superadmin() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 249
ERROR - 2023-07-05 23:04:54 --> Could not find the language line "branches"
ERROR - 2023-07-05 23:04:55 --> Could not find the language line "branches"
ERROR - 2023-07-05 23:04:55 --> Could not find the language line "branches"
ERROR - 2023-07-05 23:05:11 --> Could not find the language line "branches"
ERROR - 2023-07-05 23:06:17 --> Could not find the language line "branches"
ERROR - 2023-07-05 23:06:20 --> Could not find the language line "branches"
ERROR - 2023-07-05 23:07:28 --> Could not find the language line "branches"
ERROR - 2023-07-05 23:07:33 --> Could not find the language line "branches"
ERROR - 2023-07-05 23:07:33 --> Could not find the language line "branches"
ERROR - 2023-07-05 23:08:10 --> Could not find the language line "features"
ERROR - 2023-07-05 23:08:50 --> Could not find the language line "features"
ERROR - 2023-07-05 23:11:30 --> Could not find the language line "features"
ERROR - 2023-07-05 23:20:43 --> Could not find the language line "branches"
ERROR - 2023-07-05 23:20:45 --> Could not find the language line "branches"
ERROR - 2023-07-05 23:20:45 --> Could not find the language line "branches"
ERROR - 2023-07-05 23:22:37 --> Could not find the language line "branches"
ERROR - 2023-07-05 23:22:39 --> Could not find the language line "branches"
ERROR - 2023-07-05 23:22:39 --> Could not find the language line "branches"
ERROR - 2023-07-05 23:25:18 --> Could not find the language line "branches"
ERROR - 2023-07-05 23:25:23 --> Could not find the language line "branches"
ERROR - 2023-07-05 23:25:24 --> Could not find the language line "branches"
ERROR - 2023-07-05 23:25:30 --> Could not find the language line "branches"
ERROR - 2023-07-05 23:25:30 --> Could not find the language line "features"
ERROR - 2023-07-05 23:25:31 --> Could not find the language line "branches"
ERROR - 2023-07-05 23:25:43 --> Could not find the language line "branches"
ERROR - 2023-07-05 23:25:43 --> Could not find the language line "branches"
ERROR - 2023-07-05 23:25:44 --> Could not find the language line "branches"
ERROR - 2023-07-05 23:25:44 --> Could not find the language line "features"
ERROR - 2023-07-05 23:25:46 --> Could not find the language line "branches"
ERROR - 2023-07-05 23:26:21 --> Could not find the language line "branches"
ERROR - 2023-07-05 23:26:22 --> Could not find the language line "branches"
ERROR - 2023-07-05 23:26:22 --> Could not find the language line "branches"
ERROR - 2023-07-05 23:26:36 --> Could not find the language line "branches"
ERROR - 2023-07-05 23:26:42 --> Could not find the language line "branches"
ERROR - 2023-07-05 23:26:43 --> Could not find the language line "branches"
ERROR - 2023-07-05 23:26:46 --> Could not find the language line "branches"
ERROR - 2023-07-05 23:26:47 --> Could not find the language line "features"
ERROR - 2023-07-05 23:26:48 --> Could not find the language line "branches"
ERROR - 2023-07-05 23:26:57 --> Could not find the language line "branches"
ERROR - 2023-07-05 23:26:58 --> Could not find the language line "branches"
ERROR - 2023-07-05 23:26:59 --> Could not find the language line "branches"
ERROR - 2023-07-05 23:26:59 --> Could not find the language line "features"
ERROR - 2023-07-05 23:27:00 --> Could not find the language line "branches"
ERROR - 2023-07-05 23:28:25 --> Could not find the language line "branches"
ERROR - 2023-07-05 23:28:26 --> Could not find the language line "branches"
ERROR - 2023-07-05 23:28:27 --> Could not find the language line "branches"
ERROR - 2023-07-05 23:28:29 --> Could not find the language line "branches"
ERROR - 2023-07-05 23:28:29 --> Could not find the language line "new branch"
ERROR - 2023-07-05 23:28:40 --> Could not find the language line "branches"
ERROR - 2023-07-05 23:28:40 --> Could not find the language line "branch name"
ERROR - 2023-07-05 23:28:40 --> Could not find the language line "branchlocation"
