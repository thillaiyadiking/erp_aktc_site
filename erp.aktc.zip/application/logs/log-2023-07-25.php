<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-25 16:09:34 --> Could not find the language line "features"
ERROR - 2023-07-25 16:14:34 --> Could not find the language line "features"
ERROR - 2023-07-25 16:15:51 --> Could not find the language line "features"
ERROR - 2023-07-25 16:42:23 --> Could not find the language line "features"
ERROR - 2023-07-25 16:45:09 --> Could not find the language line "features"
ERROR - 2023-07-25 16:53:37 --> Could not find the language line "features"
ERROR - 2023-07-25 16:54:06 --> Could not find the language line "features"
ERROR - 2023-07-25 18:43:52 --> Could not find the language line "features"
ERROR - 2023-07-25 20:44:39 --> Severity: Notice --> Trying to get property 'active' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\core\AdminController.php 64
ERROR - 2023-07-25 20:45:07 --> Severity: Notice --> Trying to get property 'active' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\core\AdminController.php 64
ERROR - 2023-07-25 21:21:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'branch_id 1
    
    ORDER BY firstname ASC
    LIMIT 0, 25' at line 5 - Invalid query: 
    SELECT SQL_CALC_FOUND_ROWS firstname, email, `tblroles`.`name` AS `tblroles.name`, last_login, active ,profile_image,lastname,staffid
    FROM tblstaff
    LEFT JOIN tblroles ON tblroles.roleid = tblstaff.role
    
    branch_id 1
    
    ORDER BY firstname ASC
    LIMIT 0, 25
    
ERROR - 2023-07-25 21:22:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'branch_id 1
    
    ORDER BY firstname ASC
    LIMIT 0, 25' at line 5 - Invalid query: 
    SELECT SQL_CALC_FOUND_ROWS firstname, email, `tblroles`.`name` AS `tblroles.name`, last_login, active ,profile_image,lastname,staffid
    FROM tblstaff
    LEFT JOIN tblroles ON tblroles.roleid = tblstaff.role
    
    branch_id 1
    
    ORDER BY firstname ASC
    LIMIT 0, 25
    
ERROR - 2023-07-25 21:32:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
    
    ORDER BY firstname ASC
    LIMIT 0, 25' at line 5 - Invalid query: 
    SELECT SQL_CALC_FOUND_ROWS firstname, email, `tblroles`.`name` AS `tblroles.name`, last_login, active ,profile_image,lastname,staffid
    FROM tblstaff
    LEFT JOIN tblroles ON tblroles.roleid = tblstaff.role
    
    1
    
    ORDER BY firstname ASC
    LIMIT 0, 25
    
ERROR - 2023-07-25 21:32:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
    
    ORDER BY firstname ASC
    LIMIT 0, 25' at line 5 - Invalid query: 
    SELECT SQL_CALC_FOUND_ROWS firstname, email, `tblroles`.`name` AS `tblroles.name`, last_login, active ,profile_image,lastname,staffid
    FROM tblstaff
    LEFT JOIN tblroles ON tblroles.roleid = tblstaff.role
    
    1
    
    ORDER BY firstname ASC
    LIMIT 0, 25
    
ERROR - 2023-07-25 21:33:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'branch_id 1
    
    ORDER BY firstname ASC
    LIMIT 0, 25' at line 5 - Invalid query: 
    SELECT SQL_CALC_FOUND_ROWS firstname, email, `tblroles`.`name` AS `tblroles.name`, last_login, active ,profile_image,lastname,staffid
    FROM tblstaff
    LEFT JOIN tblroles ON tblroles.roleid = tblstaff.role
    
    branch_id 1
    
    ORDER BY firstname ASC
    LIMIT 0, 25
    
ERROR - 2023-07-25 21:36:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'branch_id 1
    
    ORDER BY firstname ASC
    LIMIT 0, 25' at line 5 - Invalid query: 
    SELECT SQL_CALC_FOUND_ROWS firstname, email, `tblroles`.`name` AS `tblroles.name`, last_login, active ,profile_image,lastname,staffid
    FROM tblstaff
    LEFT JOIN tblroles ON tblroles.roleid = tblstaff.role
    
    branch_id 1
    
    ORDER BY firstname ASC
    LIMIT 0, 25
    
ERROR - 2023-07-25 21:36:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'branch_id 1
    
    ORDER BY firstname ASC
    LIMIT 0, 25' at line 5 - Invalid query: 
    SELECT SQL_CALC_FOUND_ROWS firstname, email, `tblroles`.`name` AS `tblroles.name`, last_login, active ,profile_image,lastname,staffid
    FROM tblstaff
    LEFT JOIN tblroles ON tblroles.roleid = tblstaff.role
    
    branch_id 1
    
    ORDER BY firstname ASC
    LIMIT 0, 25
    
