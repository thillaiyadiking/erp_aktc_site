<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-27 18:34:05 --> Severity: Notice --> Undefined variable: bid C:\xampp\htdocs\finishizer_erp3.0.5\application\controllers\admin\Spam_filters.php 27
ERROR - 2023-07-27 18:34:05 --> Severity: Notice --> Undefined variable: bid C:\xampp\htdocs\finishizer_erp3.0.5\application\controllers\admin\Spam_filters.php 27
ERROR - 2023-07-27 18:34:05 --> Severity: Notice --> Undefined variable: bid C:\xampp\htdocs\finishizer_erp3.0.5\application\controllers\admin\Spam_filters.php 27
ERROR - 2023-07-27 18:35:27 --> Severity: Notice --> Undefined variable: bid C:\xampp\htdocs\finishizer_erp3.0.5\application\controllers\admin\Spam_filters.php 27
ERROR - 2023-07-27 18:35:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '"AND branch_id=""AND type ="sender" AND rel_type="tickets"
    
    ORDER B...' at line 5 - Invalid query: 
    SELECT SQL_CALC_FOUND_ROWS value ,id
    FROM tblspam_filters
    
    
    "AND branch_id=""AND type ="sender" AND rel_type="tickets"
    
    ORDER BY value ASC
    LIMIT 0, 25
    
ERROR - 2023-07-27 18:35:27 --> Severity: Notice --> Undefined variable: bid C:\xampp\htdocs\finishizer_erp3.0.5\application\controllers\admin\Spam_filters.php 27
ERROR - 2023-07-27 18:35:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '"AND branch_id=""AND type ="subject" AND rel_type="tickets"
    
    ORDER ...' at line 5 - Invalid query: 
    SELECT SQL_CALC_FOUND_ROWS value ,id
    FROM tblspam_filters
    
    
    "AND branch_id=""AND type ="subject" AND rel_type="tickets"
    
    ORDER BY value ASC
    LIMIT 0, 25
    
ERROR - 2023-07-27 18:35:28 --> Severity: Notice --> Undefined variable: bid C:\xampp\htdocs\finishizer_erp3.0.5\application\controllers\admin\Spam_filters.php 27
ERROR - 2023-07-27 18:35:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '"AND branch_id=""AND type ="phrase" AND rel_type="tickets"
    
    ORDER B...' at line 5 - Invalid query: 
    SELECT SQL_CALC_FOUND_ROWS value ,id
    FROM tblspam_filters
    
    
    "AND branch_id=""AND type ="phrase" AND rel_type="tickets"
    
    ORDER BY value ASC
    LIMIT 0, 25
    
ERROR - 2023-07-27 18:36:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '"AND type ="sender" AND rel_type="tickets"
    
    ORDER BY value ASC
   ...' at line 5 - Invalid query: 
    SELECT SQL_CALC_FOUND_ROWS value ,id
    FROM tblspam_filters
    
    
    "AND type ="sender" AND rel_type="tickets"
    
    ORDER BY value ASC
    LIMIT 0, 25
    
ERROR - 2023-07-27 18:36:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '"AND type ="subject" AND rel_type="tickets"
    
    ORDER BY value ASC
  ...' at line 5 - Invalid query: 
    SELECT SQL_CALC_FOUND_ROWS value ,id
    FROM tblspam_filters
    
    
    "AND type ="subject" AND rel_type="tickets"
    
    ORDER BY value ASC
    LIMIT 0, 25
    
ERROR - 2023-07-27 18:36:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '"AND type ="phrase" AND rel_type="tickets"
    
    ORDER BY value ASC
   ...' at line 5 - Invalid query: 
    SELECT SQL_CALC_FOUND_ROWS value ,id
    FROM tblspam_filters
    
    
    "AND type ="phrase" AND rel_type="tickets"
    
    ORDER BY value ASC
    LIMIT 0, 25
    
