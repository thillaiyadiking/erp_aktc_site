<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-03 20:35:37 --> Severity: Notice --> Undefined variable: bid C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 440
ERROR - 2023-08-03 20:35:37 --> Severity: Notice --> Undefined variable: bid C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 440
ERROR - 2023-08-03 20:35:37 --> Severity: Notice --> Undefined variable: bid C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 440
ERROR - 2023-08-03 20:35:37 --> Severity: Notice --> Undefined variable: bid C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 440
ERROR - 2023-08-03 20:35:37 --> Severity: Notice --> Undefined variable: bid C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 440
ERROR - 2023-08-03 20:35:41 --> Severity: Notice --> Undefined variable: bid C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 440
ERROR - 2023-08-03 20:35:41 --> Severity: Notice --> Undefined variable: bid C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 440
ERROR - 2023-08-03 20:35:41 --> Severity: Notice --> Undefined variable: bid C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 440
ERROR - 2023-08-03 20:35:41 --> Severity: Notice --> Undefined variable: bid C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 440
ERROR - 2023-08-03 20:35:41 --> Severity: Notice --> Undefined variable: bid C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 440
ERROR - 2023-08-03 20:35:45 --> Severity: Notice --> Undefined variable: bid C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 440
ERROR - 2023-08-03 20:35:45 --> Severity: Notice --> Undefined variable: bid C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 440
ERROR - 2023-08-03 20:35:45 --> Severity: Notice --> Undefined variable: bid C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 440
ERROR - 2023-08-03 20:35:45 --> Severity: Notice --> Undefined variable: bid C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 440
ERROR - 2023-08-03 20:35:45 --> Severity: Notice --> Undefined variable: bid C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 440
ERROR - 2023-08-03 20:35:48 --> Severity: Notice --> Undefined variable: bid C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 440
ERROR - 2023-08-03 20:35:48 --> Severity: Notice --> Undefined variable: bid C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 440
ERROR - 2023-08-03 20:35:48 --> Severity: Notice --> Undefined variable: bid C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 440
ERROR - 2023-08-03 20:35:48 --> Severity: Notice --> Undefined variable: bid C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 440
ERROR - 2023-08-03 20:35:48 --> Severity: Notice --> Undefined variable: bid C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 440
ERROR - 2023-08-03 20:35:52 --> Severity: Notice --> Undefined variable: bid C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 440
ERROR - 2023-08-03 20:35:52 --> Severity: Notice --> Undefined variable: bid C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 440
ERROR - 2023-08-03 20:35:52 --> Severity: Notice --> Undefined variable: bid C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 440
ERROR - 2023-08-03 20:35:52 --> Severity: Notice --> Undefined variable: bid C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 440
ERROR - 2023-08-03 20:35:52 --> Severity: Notice --> Undefined variable: bid C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 440
ERROR - 2023-08-03 20:35:52 --> Severity: Notice --> Undefined variable: bid C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 440
ERROR - 2023-08-03 20:35:52 --> Severity: Notice --> Undefined variable: b_id C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 79
ERROR - 2023-08-03 20:35:52 --> Query error: Column 'branch_id' cannot be null - Invalid query: INSERT INTO `tblmodules` (`branch_id`, `module_name`, `installed_version`) VALUES (NULL, 'exports', '1.0.0')
ERROR - 2023-08-03 20:35:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\finishizer_erp3.0.5\system\core\Exceptions.php:271) C:\xampp\htdocs\finishizer_erp3.0.5\system\core\Common.php 574
ERROR - 2023-08-03 20:39:03 --> Severity: Notice --> Undefined variable: bid C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 440
ERROR - 2023-08-03 20:39:03 --> Severity: Notice --> Undefined property: App_modules::$ C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 440
ERROR - 2023-08-03 20:39:03 --> Severity: Notice --> Undefined variable: bid C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 440
ERROR - 2023-08-03 20:39:03 --> Severity: Notice --> Undefined property: App_modules::$ C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 440
ERROR - 2023-08-03 20:39:03 --> Severity: Notice --> Undefined variable: bid C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 440
ERROR - 2023-08-03 20:39:03 --> Severity: Notice --> Undefined property: App_modules::$ C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 440
ERROR - 2023-08-03 20:39:03 --> Severity: Notice --> Undefined variable: bid C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 440
ERROR - 2023-08-03 20:39:03 --> Severity: Notice --> Undefined property: App_modules::$ C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 440
ERROR - 2023-08-03 20:39:03 --> Severity: Notice --> Undefined variable: bid C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 440
ERROR - 2023-08-03 20:39:03 --> Severity: Notice --> Undefined property: App_modules::$ C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 440
ERROR - 2023-08-03 20:39:03 --> Severity: Notice --> Undefined variable: bid C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 440
ERROR - 2023-08-03 20:39:03 --> Severity: Notice --> Undefined property: App_modules::$ C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 440
ERROR - 2023-08-03 20:39:03 --> Severity: Notice --> Undefined variable: b_id C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 79
ERROR - 2023-08-03 20:39:03 --> Severity: Notice --> Undefined property: App_modules::$ C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 79
ERROR - 2023-08-03 20:39:03 --> Query error: Column 'branch_id' cannot be null - Invalid query: INSERT INTO `tblmodules` (`branch_id`, `module_name`, `installed_version`) VALUES (NULL, 'exports', '1.0.0')
ERROR - 2023-08-03 20:39:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\finishizer_erp3.0.5\system\core\Exceptions.php:271) C:\xampp\htdocs\finishizer_erp3.0.5\system\core\Common.php 574
ERROR - 2023-08-03 20:41:51 --> Severity: Notice --> Undefined variable: b_id C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 80
ERROR - 2023-08-03 20:41:51 --> Query error: Column 'branch_id' cannot be null - Invalid query: INSERT INTO `tblmodules` (`branch_id`, `module_name`, `installed_version`) VALUES (NULL, 'exports', '1.0.0')
ERROR - 2023-08-03 21:20:18 --> 404 Page Not Found: /index
ERROR - 2023-08-03 21:21:51 --> Could not find the language line "main_menu"
ERROR - 2023-08-03 21:21:51 --> Could not find the language line "utilities_menu_icon"
ERROR - 2023-08-03 21:21:51 --> Severity: error --> Exception: Call to undefined function app_get_menu_setup_icon() C:\xampp\htdocs\finishizer_erp3.0.5\modules\menu_setup\views\main_menu.php 38
ERROR - 2023-08-03 21:22:23 --> Could not find the language line "main_menu"
ERROR - 2023-08-03 21:22:23 --> Could not find the language line "utilities_menu_icon"
ERROR - 2023-08-03 21:22:23 --> Severity: error --> Exception: Call to undefined function app_get_menu_setup_icon() C:\xampp\htdocs\finishizer_erp3.0.5\modules\menu_setup\views\main_menu.php 38
ERROR - 2023-08-03 22:08:34 --> Could not find the language line ""
ERROR - 2023-08-03 22:13:18 --> 404 Page Not Found: /index
ERROR - 2023-08-03 22:13:18 --> 404 Page Not Found: /index
ERROR - 2023-08-03 22:16:25 --> 404 Page Not Found: /index
ERROR - 2023-08-03 22:16:25 --> 404 Page Not Found: /index
ERROR - 2023-08-03 22:17:06 --> 404 Page Not Found: /index
ERROR - 2023-08-03 22:17:06 --> 404 Page Not Found: /index
ERROR - 2023-08-03 22:17:54 --> 404 Page Not Found: /index
ERROR - 2023-08-03 22:17:54 --> 404 Page Not Found: /index
ERROR - 2023-08-03 22:20:57 --> 404 Page Not Found: /index
