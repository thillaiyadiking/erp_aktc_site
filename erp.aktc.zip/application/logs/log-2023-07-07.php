<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-07 00:00:26 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:00:27 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:00:27 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:00:47 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:00:47 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:00:48 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:15:28 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:15:28 --> Severity: Notice --> Undefined variable: branches C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\header.php 88
ERROR - 2023-07-07 00:15:30 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:15:31 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:17:26 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:17:26 --> Severity: Notice --> Undefined variable: branches C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\header.php 88
ERROR - 2023-07-07 00:17:28 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:17:28 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:17:30 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:17:30 --> Severity: Notice --> Undefined variable: branches C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\header.php 88
ERROR - 2023-07-07 00:17:31 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:17:31 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:18:17 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:18:17 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\header.php 88
ERROR - 2023-07-07 00:18:18 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:18:18 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:19:15 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:19:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\header.php 88
ERROR - 2023-07-07 00:19:16 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:19:16 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:19:36 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:19:37 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:19:37 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:20:14 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:20:14 --> Severity: Notice --> Undefined variable: first C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\includes\header.php 89
ERROR - 2023-07-07 00:20:15 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:20:15 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:20:29 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:20:30 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:20:30 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:21:03 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:21:04 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:21:05 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:21:42 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:21:43 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:21:43 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:22:48 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:22:49 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:22:49 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:23:03 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:23:05 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:23:05 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:23:21 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:23:22 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:23:22 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:23:24 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:23:25 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:23:26 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:23:48 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:23:49 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:23:49 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:25:11 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:25:12 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:25:13 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:25:25 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:25:27 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:25:27 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:26:09 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:26:09 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:26:10 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:27:22 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:27:23 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:27:23 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:27:45 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:27:46 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:27:46 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:28:12 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:28:13 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:28:13 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:41:28 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:41:30 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:41:30 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:41:52 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:41:53 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:41:53 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:43:23 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:43:24 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:43:24 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:44:54 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:45:05 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:45:05 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:45:09 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:45:09 --> Could not find the language line "features"
ERROR - 2023-07-07 00:45:10 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:49:03 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:49:04 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:50:13 --> Could not find the language line "branches"
ERROR - 2023-07-07 00:50:13 --> Could not find the language line "features"
ERROR - 2023-07-07 00:50:14 --> Could not find the language line "branches"
ERROR - 2023-07-07 20:13:14 --> Could not find the language line "branches"
ERROR - 2023-07-07 20:13:17 --> Could not find the language line "branches"
ERROR - 2023-07-07 20:13:18 --> Could not find the language line "branches"
ERROR - 2023-07-07 20:13:40 --> Could not find the language line "branches"
ERROR - 2023-07-07 20:13:48 --> Could not find the language line "branches"
ERROR - 2023-07-07 20:13:48 --> Could not find the language line "branches"
ERROR - 2023-07-07 20:14:05 --> Could not find the language line "branches"
ERROR - 2023-07-07 20:14:05 --> Could not find the language line "features"
ERROR - 2023-07-07 20:14:05 --> Could not find the language line "branches"
ERROR - 2023-07-07 20:28:20 --> Could not find the language line "branches"
ERROR - 2023-07-07 20:28:21 --> Could not find the language line "branches"
ERROR - 2023-07-07 20:28:23 --> Could not find the language line "branches"
ERROR - 2023-07-07 20:28:23 --> Could not find the language line "features"
ERROR - 2023-07-07 20:28:24 --> Could not find the language line "branches"
ERROR - 2023-07-07 20:35:06 --> Could not find the language line "branches"
ERROR - 2023-07-07 20:35:06 --> Could not find the language line "features"
ERROR - 2023-07-07 20:35:06 --> Could not find the language line "branches"
ERROR - 2023-07-07 20:39:56 --> Could not find the language line "branches"
ERROR - 2023-07-07 20:40:12 --> Could not find the language line "branches"
ERROR - 2023-07-07 20:40:19 --> Could not find the language line "branches"
ERROR - 2023-07-07 20:40:21 --> Could not find the language line "branches"
ERROR - 2023-07-07 20:40:23 --> Could not find the language line "branches"
ERROR - 2023-07-07 20:40:23 --> Could not find the language line "features"
ERROR - 2023-07-07 20:40:24 --> Could not find the language line "branches"
ERROR - 2023-07-07 20:40:27 --> Could not find the language line "branches"
ERROR - 2023-07-07 20:40:27 --> Could not find the language line "branches"
ERROR - 2023-07-07 21:18:36 --> Could not find the language line "branches"
ERROR - 2023-07-07 21:18:37 --> Could not find the language line "branches"
ERROR - 2023-07-07 21:18:38 --> Could not find the language line "branches"
ERROR - 2023-07-07 21:19:09 --> Could not find the language line "branches"
ERROR - 2023-07-07 21:19:13 --> Could not find the language line "branches"
ERROR - 2023-07-07 21:19:14 --> Could not find the language line "branches"
ERROR - 2023-07-07 21:19:16 --> Could not find the language line "branches"
ERROR - 2023-07-07 21:19:16 --> Could not find the language line "features"
ERROR - 2023-07-07 21:19:17 --> Could not find the language line "branches"
ERROR - 2023-07-07 21:23:50 --> Could not find the language line "branches"
ERROR - 2023-07-07 21:23:50 --> Could not find the language line "features"
ERROR - 2023-07-07 21:23:50 --> Could not find the language line "branches"
ERROR - 2023-07-07 21:28:54 --> Could not find the language line "branches"
ERROR - 2023-07-07 21:28:56 --> Could not find the language line "branches"
ERROR - 2023-07-07 21:33:00 --> Could not find the language line "branches"
ERROR - 2023-07-07 21:33:00 --> Could not find the language line "features"
ERROR - 2023-07-07 21:33:01 --> Could not find the language line "branches"
ERROR - 2023-07-07 21:33:53 --> Could not find the language line "branches"
ERROR - 2023-07-07 21:34:10 --> Could not find the language line "branches"
ERROR - 2023-07-07 21:34:26 --> Could not find the language line "branches"
ERROR - 2023-07-07 21:34:26 --> Could not find the language line "branches"
ERROR - 2023-07-07 21:34:26 --> Could not find the language line "features"
ERROR - 2023-07-07 21:34:27 --> Could not find the language line "branches"
ERROR - 2023-07-07 21:35:04 --> Could not find the language line "branches"
ERROR - 2023-07-07 21:35:05 --> Could not find the language line "branches"
ERROR - 2023-07-07 21:35:36 --> Could not find the language line "branches"
ERROR - 2023-07-07 21:35:36 --> Could not find the language line "features"
ERROR - 2023-07-07 21:35:36 --> Could not find the language line "branches"
ERROR - 2023-07-07 21:36:08 --> Could not find the language line "branches"
ERROR - 2023-07-07 21:37:39 --> Could not find the language line "branches"
ERROR - 2023-07-07 21:37:40 --> Could not find the language line "branches"
ERROR - 2023-07-07 21:37:40 --> Could not find the language line "branches"
ERROR - 2023-07-07 21:37:50 --> Could not find the language line "branches"
ERROR - 2023-07-07 21:37:50 --> Could not find the language line "features"
ERROR - 2023-07-07 21:37:51 --> Could not find the language line "branches"
ERROR - 2023-07-07 21:38:10 --> Could not find the language line "branches"
ERROR - 2023-07-07 21:38:10 --> Could not find the language line "branches"
ERROR - 2023-07-07 21:38:11 --> Could not find the language line "branches"
ERROR - 2023-07-07 21:38:11 --> Could not find the language line "features"
ERROR - 2023-07-07 21:38:11 --> Could not find the language line "branches"
ERROR - 2023-07-07 23:07:25 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 38
ERROR - 2023-07-07 23:07:25 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 38
ERROR - 2023-07-07 23:08:20 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 38
ERROR - 2023-07-07 23:08:20 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 51
ERROR - 2023-07-07 23:08:20 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 38
ERROR - 2023-07-07 23:08:20 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 51
ERROR - 2023-07-07 23:08:40 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 38
ERROR - 2023-07-07 23:08:40 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 51
ERROR - 2023-07-07 23:08:40 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 64
ERROR - 2023-07-07 23:08:41 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 38
ERROR - 2023-07-07 23:08:41 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 51
ERROR - 2023-07-07 23:08:41 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 64
ERROR - 2023-07-07 23:09:57 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 38
ERROR - 2023-07-07 23:09:57 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 51
ERROR - 2023-07-07 23:09:57 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 64
ERROR - 2023-07-07 23:09:57 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 77
ERROR - 2023-07-07 23:09:57 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 91
ERROR - 2023-07-07 23:09:57 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 102
ERROR - 2023-07-07 23:09:57 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 113
ERROR - 2023-07-07 23:09:58 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 38
ERROR - 2023-07-07 23:09:58 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 51
ERROR - 2023-07-07 23:09:58 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 64
ERROR - 2023-07-07 23:09:58 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 77
ERROR - 2023-07-07 23:09:58 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 91
ERROR - 2023-07-07 23:09:58 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 102
ERROR - 2023-07-07 23:09:58 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 113
ERROR - 2023-07-07 23:10:34 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 38
ERROR - 2023-07-07 23:10:34 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 51
ERROR - 2023-07-07 23:10:34 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 64
ERROR - 2023-07-07 23:10:34 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 77
ERROR - 2023-07-07 23:10:34 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 91
ERROR - 2023-07-07 23:10:34 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 102
ERROR - 2023-07-07 23:10:34 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 113
ERROR - 2023-07-07 23:10:35 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 38
ERROR - 2023-07-07 23:10:35 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 51
ERROR - 2023-07-07 23:10:35 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 64
ERROR - 2023-07-07 23:10:35 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 77
ERROR - 2023-07-07 23:10:35 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 91
ERROR - 2023-07-07 23:10:35 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 102
ERROR - 2023-07-07 23:10:35 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 113
ERROR - 2023-07-07 23:10:35 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 38
ERROR - 2023-07-07 23:10:35 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 51
ERROR - 2023-07-07 23:10:35 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 64
ERROR - 2023-07-07 23:10:35 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 77
ERROR - 2023-07-07 23:10:35 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 91
ERROR - 2023-07-07 23:10:35 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 102
ERROR - 2023-07-07 23:10:35 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 113
ERROR - 2023-07-07 23:14:24 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 38
ERROR - 2023-07-07 23:14:24 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 51
ERROR - 2023-07-07 23:14:24 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 64
ERROR - 2023-07-07 23:14:24 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 77
ERROR - 2023-07-07 23:14:24 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 91
ERROR - 2023-07-07 23:14:24 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 102
ERROR - 2023-07-07 23:14:24 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 113
ERROR - 2023-07-07 23:14:24 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 124
ERROR - 2023-07-07 23:14:24 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 135
ERROR - 2023-07-07 23:14:24 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 162
ERROR - 2023-07-07 23:14:24 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 203
ERROR - 2023-07-07 23:14:24 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 214
ERROR - 2023-07-07 23:14:24 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 242
ERROR - 2023-07-07 23:14:24 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 297
ERROR - 2023-07-07 23:14:24 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 308
ERROR - 2023-07-07 23:14:24 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 366
ERROR - 2023-07-07 23:14:25 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 38
ERROR - 2023-07-07 23:14:25 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 51
ERROR - 2023-07-07 23:14:25 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 64
ERROR - 2023-07-07 23:14:25 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 77
ERROR - 2023-07-07 23:14:25 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 91
ERROR - 2023-07-07 23:14:25 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 102
ERROR - 2023-07-07 23:14:25 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 113
ERROR - 2023-07-07 23:14:25 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 124
ERROR - 2023-07-07 23:14:25 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 135
ERROR - 2023-07-07 23:14:25 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 162
ERROR - 2023-07-07 23:14:25 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 203
ERROR - 2023-07-07 23:14:25 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 214
ERROR - 2023-07-07 23:14:25 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 242
ERROR - 2023-07-07 23:14:25 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 297
ERROR - 2023-07-07 23:14:25 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 308
ERROR - 2023-07-07 23:14:25 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 366
ERROR - 2023-07-07 23:14:25 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 38
ERROR - 2023-07-07 23:14:25 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 51
ERROR - 2023-07-07 23:14:25 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 64
ERROR - 2023-07-07 23:14:25 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 77
ERROR - 2023-07-07 23:14:25 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 91
ERROR - 2023-07-07 23:14:25 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 102
ERROR - 2023-07-07 23:14:25 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 113
ERROR - 2023-07-07 23:14:25 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 124
ERROR - 2023-07-07 23:14:25 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 135
ERROR - 2023-07-07 23:14:25 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 162
ERROR - 2023-07-07 23:14:25 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 203
ERROR - 2023-07-07 23:14:25 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 214
ERROR - 2023-07-07 23:14:25 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 242
ERROR - 2023-07-07 23:14:25 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 297
ERROR - 2023-07-07 23:14:25 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 308
ERROR - 2023-07-07 23:14:25 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 366
ERROR - 2023-07-07 23:14:30 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 38
ERROR - 2023-07-07 23:14:30 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 51
ERROR - 2023-07-07 23:14:30 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 64
ERROR - 2023-07-07 23:14:30 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 77
ERROR - 2023-07-07 23:14:30 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 91
ERROR - 2023-07-07 23:14:30 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 102
ERROR - 2023-07-07 23:14:30 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 113
ERROR - 2023-07-07 23:14:30 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 124
ERROR - 2023-07-07 23:14:30 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 135
ERROR - 2023-07-07 23:14:30 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 162
ERROR - 2023-07-07 23:14:30 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 203
ERROR - 2023-07-07 23:14:30 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 214
ERROR - 2023-07-07 23:14:30 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 242
ERROR - 2023-07-07 23:14:30 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 297
ERROR - 2023-07-07 23:14:30 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 308
ERROR - 2023-07-07 23:14:30 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 366
ERROR - 2023-07-07 23:14:30 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 38
ERROR - 2023-07-07 23:14:30 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 51
ERROR - 2023-07-07 23:14:30 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 64
ERROR - 2023-07-07 23:14:30 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 77
ERROR - 2023-07-07 23:14:30 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 91
ERROR - 2023-07-07 23:14:30 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 102
ERROR - 2023-07-07 23:14:30 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 113
ERROR - 2023-07-07 23:14:30 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 124
ERROR - 2023-07-07 23:14:30 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 135
ERROR - 2023-07-07 23:14:30 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 162
ERROR - 2023-07-07 23:14:30 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 203
ERROR - 2023-07-07 23:14:30 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 214
ERROR - 2023-07-07 23:14:30 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 242
ERROR - 2023-07-07 23:14:30 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 297
ERROR - 2023-07-07 23:14:30 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 308
ERROR - 2023-07-07 23:14:30 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 366
ERROR - 2023-07-07 23:14:31 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 38
ERROR - 2023-07-07 23:14:31 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 51
ERROR - 2023-07-07 23:14:31 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 64
ERROR - 2023-07-07 23:14:31 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 77
ERROR - 2023-07-07 23:14:31 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 91
ERROR - 2023-07-07 23:14:31 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 102
ERROR - 2023-07-07 23:14:31 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 113
ERROR - 2023-07-07 23:14:31 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 124
ERROR - 2023-07-07 23:14:31 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 135
ERROR - 2023-07-07 23:14:31 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 162
ERROR - 2023-07-07 23:14:31 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 203
ERROR - 2023-07-07 23:14:31 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 214
ERROR - 2023-07-07 23:14:31 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 242
ERROR - 2023-07-07 23:14:31 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 297
ERROR - 2023-07-07 23:14:31 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 308
ERROR - 2023-07-07 23:14:31 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 366
ERROR - 2023-07-07 23:38:03 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 38
ERROR - 2023-07-07 23:38:03 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 51
ERROR - 2023-07-07 23:38:03 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 64
ERROR - 2023-07-07 23:38:03 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 77
ERROR - 2023-07-07 23:38:03 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 91
ERROR - 2023-07-07 23:38:03 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 102
ERROR - 2023-07-07 23:38:03 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 113
ERROR - 2023-07-07 23:38:03 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 135
ERROR - 2023-07-07 23:38:03 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 38
ERROR - 2023-07-07 23:38:03 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 51
ERROR - 2023-07-07 23:38:03 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 64
ERROR - 2023-07-07 23:38:03 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 77
ERROR - 2023-07-07 23:38:03 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 91
ERROR - 2023-07-07 23:38:03 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 102
ERROR - 2023-07-07 23:38:03 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 113
ERROR - 2023-07-07 23:38:03 --> Severity: Warning --> Use of undefined constant is_branchadmin - assumed 'is_branchadmin' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 135
ERROR - 2023-07-07 23:39:28 --> Severity: error --> Exception: syntax error, unexpected 'static' (T_STATIC) C:\xampp\htdocs\finishizer_erp3.0.5\application\services\proposals\ProposalsPipeline.php 29
ERROR - 2023-07-07 23:51:24 --> Could not find the language line "branches"
ERROR - 2023-07-07 23:51:24 --> Could not find the language line "branches"
ERROR - 2023-07-07 23:51:25 --> Could not find the language line "branches"
ERROR - 2023-07-07 23:51:27 --> Could not find the language line "branches"
ERROR - 2023-07-07 23:51:27 --> Could not find the language line "branches"
ERROR - 2023-07-07 23:51:44 --> Could not find the language line "branches"
ERROR - 2023-07-07 23:51:49 --> Could not find the language line "branches"
ERROR - 2023-07-07 23:51:50 --> Could not find the language line "branches"
ERROR - 2023-07-07 23:52:02 --> Could not find the language line "branches"
ERROR - 2023-07-07 23:52:02 --> Could not find the language line "features"
ERROR - 2023-07-07 23:52:03 --> Could not find the language line "branches"
