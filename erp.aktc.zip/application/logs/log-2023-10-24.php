<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-24 05:02:04 --> Could not find the language line "branch"
ERROR - 2023-10-24 05:06:59 --> Could not find the language line "branch"
ERROR - 2023-10-24 05:07:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
AND `currency` = '1'' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `clientid` IN()
AND `currency` = '1'
ERROR - 2023-10-24 05:14:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
AND `currency` = '1'' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `clientid` IN()
AND `currency` = '1'
ERROR - 2023-10-24 05:14:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
AND `currency` = '1'' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `clientid` IN()
AND `currency` = '1'
ERROR - 2023-10-24 05:16:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
AND `currency` = '1'' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `clientid` IN()
AND `currency` = '1'
ERROR - 2023-10-24 05:17:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
AND `currency` = '1'' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `clientid` IN()
AND `currency` = '1'
ERROR - 2023-10-24 05:19:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
AND `currency` = '1'' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `clientid` IN()
AND `currency` = '1'
ERROR - 2023-10-24 05:19:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
AND `currency` = '1'' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `clientid` IN()
AND `currency` = '1'
ERROR - 2023-10-24 05:22:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
AND `currency` = '1'' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `clientid` IN()
AND `currency` = '1'
ERROR - 2023-10-24 06:51:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
AND `currency` = '1'' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `clientid` IN()
AND `currency` = '1'
ERROR - 2023-10-24 06:53:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
AND `currency` = '1'' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `clientid` IN()
AND `currency` = '1'
ERROR - 2023-10-24 06:54:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
AND `currency` = '1'' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `clientid` IN()
AND `currency` = '1'
ERROR - 2023-10-24 06:55:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
AND `currency` = '1'' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `clientid` IN()
AND `currency` = '1'
ERROR - 2023-10-24 06:56:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
AND `currency` = '1'' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `clientid` IN()
AND `currency` = '1'
ERROR - 2023-10-24 06:56:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
AND `currency` = '1'' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `clientid` IN()
AND `currency` = '1'
ERROR - 2023-10-24 07:00:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
AND `currency` = '1'' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `clientid` IN()
AND `currency` = '1'
ERROR - 2023-10-24 07:00:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
AND `currency` = '1'' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `clientid` IN()
AND `currency` = '1'
ERROR - 2023-10-24 07:08:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
AND `currency` = '1'' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `clientid` IN()
AND `currency` = '1'
ERROR - 2023-10-24 07:13:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
AND `currency` = '1'' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `clientid` IN()
AND `currency` = '1'
ERROR - 2023-10-24 07:19:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
AND `currency` = '1'
AND `status` != 5
AND `status` != 6
AND `status` != 2
...' at line 3 - Invalid query: SELECT `id`, `total`, (SELECT total - (SELECT COALESCE(SUM(amount), 0) FROM tblinvoicepaymentrecords WHERE invoiceid = tblinvoices.id) - (SELECT COALESCE(SUM(amount), 0) FROM tblcredits WHERE tblcredits.invoice_id=tblinvoices.id)) as outstanding
FROM `tblinvoices`
WHERE `clientid` IN()
AND `currency` = '1'
AND `status` != 5
AND `status` != 6
AND `status` != 2
AND YEAR(date) = '2023'
ERROR - 2023-10-24 07:21:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
AND `currency` = '1'
AND `status` != 5
AND `status` != 6
AND `status` != 2
...' at line 3 - Invalid query: SELECT `id`, `total`, (SELECT total - (SELECT COALESCE(SUM(amount), 0) FROM tblinvoicepaymentrecords WHERE invoiceid = tblinvoices.id) - (SELECT COALESCE(SUM(amount), 0) FROM tblcredits WHERE tblcredits.invoice_id=tblinvoices.id)) as outstanding
FROM `tblinvoices`
WHERE `clientid` IN()
AND `currency` = '1'
AND `status` != 5
AND `status` != 6
AND `status` != 2
AND YEAR(date) = '2023'
ERROR - 2023-10-24 07:21:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
AND `currency` = '1'
AND `status` != 5
AND `status` != 6
AND `status` != 2
...' at line 3 - Invalid query: SELECT `id`, `total`, (SELECT total - (SELECT COALESCE(SUM(amount), 0) FROM tblinvoicepaymentrecords WHERE invoiceid = tblinvoices.id) - (SELECT COALESCE(SUM(amount), 0) FROM tblcredits WHERE tblcredits.invoice_id=tblinvoices.id)) as outstanding
FROM `tblinvoices`
WHERE `clientid` IN()
AND `currency` = '1'
AND `status` != 5
AND `status` != 6
AND `status` != 2
AND YEAR(date) = '2023'
ERROR - 2023-10-24 07:22:22 --> Could not find the language line "branch"
ERROR - 2023-10-24 07:22:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
AND `currency` = '1'
AND `status` != 5
AND `status` != 6
AND `status` != 2
...' at line 3 - Invalid query: SELECT `id`, `total`, (SELECT total - (SELECT COALESCE(SUM(amount), 0) FROM tblinvoicepaymentrecords WHERE invoiceid = tblinvoices.id) - (SELECT COALESCE(SUM(amount), 0) FROM tblcredits WHERE tblcredits.invoice_id=tblinvoices.id)) as outstanding
FROM `tblinvoices`
WHERE `clientid` IN()
AND `currency` = '1'
AND `status` != 5
AND `status` != 6
AND `status` != 2
AND YEAR(date) = '2023'
ERROR - 2023-10-24 07:23:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
AND `currency` = '1'
AND `status` != 5
AND `status` != 6
AND `status` != 2
...' at line 3 - Invalid query: SELECT `id`, `total`, (SELECT total - (SELECT COALESCE(SUM(amount), 0) FROM tblinvoicepaymentrecords WHERE invoiceid = tblinvoices.id) - (SELECT COALESCE(SUM(amount), 0) FROM tblcredits WHERE tblcredits.invoice_id=tblinvoices.id)) as outstanding
FROM `tblinvoices`
WHERE `clientid` IN()
AND `currency` = '1'
AND `status` != 5
AND `status` != 6
AND `status` != 2
AND YEAR(date) = '2023'
ERROR - 2023-10-24 07:23:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
AND `currency` = '1'
AND `status` != 5
AND `status` != 6
AND `status` != 2
...' at line 3 - Invalid query: SELECT `id`, `total`, (SELECT total - (SELECT COALESCE(SUM(amount), 0) FROM tblinvoicepaymentrecords WHERE invoiceid = tblinvoices.id) - (SELECT COALESCE(SUM(amount), 0) FROM tblcredits WHERE tblcredits.invoice_id=tblinvoices.id)) as outstanding
FROM `tblinvoices`
WHERE `clientid` IN()
AND `currency` = '1'
AND `status` != 5
AND `status` != 6
AND `status` != 2
AND YEAR(date) = '2023'
ERROR - 2023-10-24 07:24:08 --> Severity: Notice --> Undefined offset: 0 C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 30
ERROR - 2023-10-24 07:24:08 --> Severity: Notice --> Undefined offset: 0 C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 30
ERROR - 2023-10-24 07:24:09 --> Severity: Notice --> Undefined offset: 0 C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 30
ERROR - 2023-10-24 07:24:09 --> Severity: Notice --> Undefined offset: 0 C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 30
ERROR - 2023-10-24 07:24:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
AND `currency` = '1'
AND `status` != 5
AND `status` != 6
AND `status` != 2
...' at line 3 - Invalid query: SELECT `id`, `total`, (SELECT total - (SELECT COALESCE(SUM(amount), 0) FROM tblinvoicepaymentrecords WHERE invoiceid = tblinvoices.id) - (SELECT COALESCE(SUM(amount), 0) FROM tblcredits WHERE tblcredits.invoice_id=tblinvoices.id)) as outstanding
FROM `tblinvoices`
WHERE `clientid` IN()
AND `currency` = '1'
AND `status` != 5
AND `status` != 6
AND `status` != 2
AND YEAR(date) = '2023'
ERROR - 2023-10-24 07:25:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
AND `currency` = '1'' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `clientid` IN()
AND `currency` = '1'
ERROR - 2023-10-24 07:27:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
AND `currency` = '1'
AND `status` != 5
AND `status` != 6
AND `status` != 2
...' at line 3 - Invalid query: SELECT `id`, `total`, (SELECT total - (SELECT COALESCE(SUM(amount), 0) FROM tblinvoicepaymentrecords WHERE invoiceid = tblinvoices.id) - (SELECT COALESCE(SUM(amount), 0) FROM tblcredits WHERE tblcredits.invoice_id=tblinvoices.id)) as outstanding
FROM `tblinvoices`
WHERE `clientid` IN()
AND `currency` = '1'
AND `status` != 5
AND `status` != 6
AND `status` != 2
AND YEAR(date) = '2023'
ERROR - 2023-10-24 07:28:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')
AND `currency` = '1'
AND `status` != 5
AND `status` != 6
AND `status` != 2
...' at line 3 - Invalid query: SELECT `id`, `total`, (SELECT total - (SELECT COALESCE(SUM(amount), 0) FROM tblinvoicepaymentrecords WHERE invoiceid = tblinvoices.id) - (SELECT COALESCE(SUM(amount), 0) FROM tblcredits WHERE tblcredits.invoice_id=tblinvoices.id)) as outstanding
FROM `tblinvoices`
WHERE `clientid` IN()
AND `currency` = '1'
AND `status` != 5
AND `status` != 6
AND `status` != 2
AND YEAR(date) = '2023'
