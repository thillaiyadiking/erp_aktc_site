<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-13 05:41:59 --> 404 Page Not Found: /index
ERROR - 2023-11-13 08:54:01 --> Severity: error --> Exception: syntax error, unexpected ')' C:\xampp-new\htdocs\finishizer_erp3.0.5\application\models\Settings_model.php 232
