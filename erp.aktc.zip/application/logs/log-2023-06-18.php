<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-18 22:56:53 --> Query error: Table 'finishizer_erp.tblsessions' doesn't exist - Invalid query: SELECT 1
FROM `tblsessions`
WHERE `id` = 'h0lp2cb63e6orrcge0bliqerunvuap02'
ERROR - 2023-06-18 23:05:02 --> Not Found: /index
ERROR - 2023-06-18 23:06:11 --> Not Found: Migration/index
ERROR - 2023-06-18 23:17:32 --> 404 Page Not Found: Migration/index
ERROR - 2023-06-18 23:33:58 --> Query error: Table 'finishizer_erp.tbloptions' doesn't exist - Invalid query: SHOW COLUMNS FROM `tbloptions`
ERROR - 2023-06-18 23:34:21 --> Query error: Table 'finishizer_erp.tbloptions' doesn't exist - Invalid query: SHOW COLUMNS FROM `tbloptions`
