<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-01-23 05:15:55 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:15:55 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:15:56 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:19:15 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:19:15 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:19:15 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:19:15 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 05:19:15 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 05:19:15 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 05:30:58 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:30:58 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:30:58 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:31:01 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:31:01 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:31:01 --> Could not find the language line "Assign to"
ERROR - 2024-01-23 05:31:01 --> Could not find the language line "Select"
ERROR - 2024-01-23 05:31:01 --> Could not find the language line "features"
ERROR - 2024-01-23 05:31:02 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:31:16 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:31:16 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:31:20 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:31:20 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:31:20 --> Could not find the language line "Assign to"
ERROR - 2024-01-23 05:31:20 --> Could not find the language line "Select"
ERROR - 2024-01-23 05:31:20 --> Could not find the language line "features"
ERROR - 2024-01-23 05:31:21 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:31:30 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:31:31 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:31:36 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:31:36 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:31:36 --> Could not find the language line "Assign to"
ERROR - 2024-01-23 05:31:36 --> Could not find the language line "Select"
ERROR - 2024-01-23 05:31:36 --> Could not find the language line "features"
ERROR - 2024-01-23 05:31:36 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:33:57 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:33:57 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:33:57 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:33:57 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 05:33:57 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 05:33:57 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 05:34:02 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:34:02 --> Could not find the language line "Add new branch"
ERROR - 2024-01-23 05:34:02 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:34:02 --> Severity: Notice --> Undefined variable: currencies C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 24
ERROR - 2024-01-23 05:34:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 334
ERROR - 2024-01-23 05:34:18 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:34:19 --> Severity: error --> Exception: Call to undefined method Staff_model::stf_br_assgn() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 52
ERROR - 2024-01-23 05:34:54 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:35:18 --> Could not find the language line "branch"
ERROR - 2024-01-23 05:35:19 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:35:19 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:35:19 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:35:19 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 05:35:19 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 05:35:19 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 05:35:19 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 05:35:19 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 05:38:15 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:38:15 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:38:15 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:38:15 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 05:38:15 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 05:38:15 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 05:38:15 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 05:38:40 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:38:40 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:38:40 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:38:40 --> Severity: error --> Exception: Call to undefined function get_staffif() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 19
ERROR - 2024-01-23 05:38:51 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:38:51 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:38:51 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:38:51 --> Severity: error --> Exception: Call to undefined function get_staffid() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 19
ERROR - 2024-01-23 05:38:55 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:38:55 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:38:55 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:38:55 --> Severity: error --> Exception: Call to undefined function get_staffid() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 19
ERROR - 2024-01-23 05:39:09 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:39:09 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:39:09 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:39:09 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 05:39:09 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 05:39:09 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 05:39:09 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 05:41:08 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:41:08 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:41:08 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:41:08 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 05:41:08 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 05:41:08 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 05:41:08 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 05:43:39 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:43:39 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:43:39 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:43:43 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:43:43 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:43:43 --> Could not find the language line "Assign to"
ERROR - 2024-01-23 05:43:43 --> Could not find the language line "Select"
ERROR - 2024-01-23 05:43:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 210
ERROR - 2024-01-23 05:43:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 210
ERROR - 2024-01-23 05:43:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 210
ERROR - 2024-01-23 05:43:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 210
ERROR - 2024-01-23 05:43:43 --> Could not find the language line "features"
ERROR - 2024-01-23 05:43:43 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:47:18 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:47:18 --> Could not find the language line "Branches"
ERROR - 2024-01-23 05:47:18 --> Could not find the language line "Assign to"
ERROR - 2024-01-23 05:47:18 --> Could not find the language line "Select"
ERROR - 2024-01-23 05:47:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 210
ERROR - 2024-01-23 05:47:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 210
ERROR - 2024-01-23 05:47:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 210
ERROR - 2024-01-23 05:47:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 210
ERROR - 2024-01-23 05:47:18 --> Could not find the language line "features"
ERROR - 2024-01-23 05:47:18 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:09:24 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:09:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Staff.php 102
ERROR - 2024-01-23 07:09:24 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:09:24 --> Could not find the language line "Assign to"
ERROR - 2024-01-23 07:09:24 --> Could not find the language line "Select"
ERROR - 2024-01-23 07:09:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 210
ERROR - 2024-01-23 07:09:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 210
ERROR - 2024-01-23 07:09:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 210
ERROR - 2024-01-23 07:09:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 210
ERROR - 2024-01-23 07:09:24 --> Could not find the language line "features"
ERROR - 2024-01-23 07:09:26 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:10:01 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:10:01 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:10:01 --> Could not find the language line "Assign to"
ERROR - 2024-01-23 07:10:01 --> Could not find the language line "Select"
ERROR - 2024-01-23 07:10:01 --> Could not find the language line "features"
ERROR - 2024-01-23 07:10:01 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:10:12 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:10:12 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:10:18 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:10:18 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:10:18 --> Could not find the language line "Assign to"
ERROR - 2024-01-23 07:10:18 --> Could not find the language line "Select"
ERROR - 2024-01-23 07:10:18 --> Could not find the language line "features"
ERROR - 2024-01-23 07:10:19 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:11:29 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:11:29 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:11:29 --> Could not find the language line "Assign to"
ERROR - 2024-01-23 07:11:29 --> Could not find the language line "Select"
ERROR - 2024-01-23 07:11:29 --> Could not find the language line "features"
ERROR - 2024-01-23 07:11:30 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:11:55 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:11:55 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:11:55 --> Could not find the language line "Assign to"
ERROR - 2024-01-23 07:11:55 --> Could not find the language line "Select"
ERROR - 2024-01-23 07:11:55 --> Could not find the language line "features"
ERROR - 2024-01-23 07:11:55 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:12:02 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:12:02 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:12:02 --> Could not find the language line "Assign to"
ERROR - 2024-01-23 07:12:02 --> Could not find the language line "Select"
ERROR - 2024-01-23 07:12:02 --> Could not find the language line "features"
ERROR - 2024-01-23 07:12:03 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:13:05 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:13:05 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:13:05 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:13:05 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 07:13:05 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 07:13:05 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 07:13:05 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 07:13:40 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:13:40 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:13:40 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:13:40 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 07:13:40 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 07:13:40 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 07:13:40 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 07:17:17 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:17:17 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:17:17 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:17:17 --> Severity: Notice --> Trying to get property 'branch_name' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 16
ERROR - 2024-01-23 07:17:17 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 19
ERROR - 2024-01-23 07:17:17 --> Severity: Notice --> Undefined index:  C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 19
ERROR - 2024-01-23 07:17:17 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 20
ERROR - 2024-01-23 07:17:17 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 22
ERROR - 2024-01-23 07:17:17 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 110
ERROR - 2024-01-23 07:17:17 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 115
ERROR - 2024-01-23 07:17:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND `status` != 5' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tbltasks`
WHERE `branch_id` =  AND `status` != 5
ERROR - 2024-01-23 07:19:14 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:19:14 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:19:14 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:19:14 --> Severity: Notice --> Trying to get property 'branch_name' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 16
ERROR - 2024-01-23 07:19:14 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 19
ERROR - 2024-01-23 07:19:14 --> Severity: Notice --> Undefined index:  C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 19
ERROR - 2024-01-23 07:19:14 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 20
ERROR - 2024-01-23 07:19:14 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 22
ERROR - 2024-01-23 07:19:14 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 110
ERROR - 2024-01-23 07:19:14 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 115
ERROR - 2024-01-23 07:19:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND `status` != 5' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tbltasks`
WHERE `branch_id` =  AND `status` != 5
ERROR - 2024-01-23 07:20:04 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:20:04 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:20:04 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:20:04 --> Severity: Notice --> Trying to get property 'branch_name' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 16
ERROR - 2024-01-23 07:20:04 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 19
ERROR - 2024-01-23 07:20:04 --> Severity: Notice --> Undefined index:  C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 19
ERROR - 2024-01-23 07:20:04 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 20
ERROR - 2024-01-23 07:20:04 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 22
ERROR - 2024-01-23 07:20:04 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 110
ERROR - 2024-01-23 07:20:04 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 115
ERROR - 2024-01-23 07:20:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND `status` != 5' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tbltasks`
WHERE `branch_id` =  AND `status` != 5
ERROR - 2024-01-23 07:21:22 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:21:22 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:21:22 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:21:22 --> Severity: Notice --> Trying to get property 'branch_name' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 16
ERROR - 2024-01-23 07:21:22 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 19
ERROR - 2024-01-23 07:21:22 --> Severity: Notice --> Undefined index:  C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 19
ERROR - 2024-01-23 07:21:22 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 20
ERROR - 2024-01-23 07:21:22 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 22
ERROR - 2024-01-23 07:21:22 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 110
ERROR - 2024-01-23 07:21:22 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 115
ERROR - 2024-01-23 07:21:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND `status` != 5' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tbltasks`
WHERE `branch_id` =  AND `status` != 5
ERROR - 2024-01-23 07:22:54 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:22:54 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:22:54 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:22:54 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 07:22:54 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 07:22:54 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 07:22:54 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 07:24:29 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:24:29 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:24:29 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:24:29 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 07:24:29 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 07:24:29 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 07:24:29 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 07:26:41 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:26:41 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:26:41 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:26:41 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 07:26:41 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 07:26:41 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 07:26:41 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 07:28:05 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:28:05 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:28:05 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:28:05 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 07:28:05 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 07:28:05 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 07:28:05 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 07:29:25 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:29:25 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:29:25 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:29:25 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 07:29:25 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 07:29:25 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 07:29:25 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 07:29:50 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:29:51 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:29:52 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:30:02 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:30:02 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:30:03 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:30:03 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:31:13 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:31:13 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:31:13 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:31:13 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 07:31:13 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 07:31:13 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 07:31:13 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 07:31:23 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:31:23 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:31:23 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:31:25 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:31:25 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:31:25 --> Could not find the language line "Assign to"
ERROR - 2024-01-23 07:31:25 --> Could not find the language line "Select"
ERROR - 2024-01-23 07:31:25 --> Could not find the language line "features"
ERROR - 2024-01-23 07:31:26 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:31:40 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:31:41 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:31:47 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:31:47 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:31:47 --> Could not find the language line "Assign to"
ERROR - 2024-01-23 07:31:47 --> Could not find the language line "Select"
ERROR - 2024-01-23 07:31:47 --> Could not find the language line "features"
ERROR - 2024-01-23 07:31:48 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:32:03 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:32:04 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:32:04 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:32:09 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:32:09 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:32:09 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:32:09 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 07:32:09 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 07:37:51 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:37:51 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:37:51 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:37:51 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 07:37:51 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 07:37:51 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 07:37:51 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 07:37:53 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:37:53 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:37:54 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:38:04 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:38:05 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:38:05 --> Could not find the language line "Assign to"
ERROR - 2024-01-23 07:38:05 --> Could not find the language line "Select"
ERROR - 2024-01-23 07:38:05 --> Could not find the language line "features"
ERROR - 2024-01-23 07:38:05 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:41:23 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:41:23 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:41:24 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:41:25 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:41:25 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:41:25 --> Could not find the language line "Assign to"
ERROR - 2024-01-23 07:41:25 --> Could not find the language line "Select"
ERROR - 2024-01-23 07:41:25 --> Severity: Notice --> Undefined variable: assigned_branches C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 210
ERROR - 2024-01-23 07:41:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 210
ERROR - 2024-01-23 07:41:25 --> Severity: Notice --> Undefined variable: assigned_branches C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 210
ERROR - 2024-01-23 07:41:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 210
ERROR - 2024-01-23 07:41:25 --> Severity: Notice --> Undefined variable: assigned_branches C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 210
ERROR - 2024-01-23 07:41:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 210
ERROR - 2024-01-23 07:41:25 --> Severity: Notice --> Undefined variable: assigned_branches C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 210
ERROR - 2024-01-23 07:41:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 210
ERROR - 2024-01-23 07:41:25 --> Could not find the language line "features"
ERROR - 2024-01-23 07:58:58 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:58:58 --> Could not find the language line "Branches"
ERROR - 2024-01-23 07:58:58 --> Could not find the language line "Assign to"
ERROR - 2024-01-23 07:58:58 --> Could not find the language line "Select"
ERROR - 2024-01-23 07:58:58 --> Severity: Notice --> Undefined variable: assigned_branches C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 210
ERROR - 2024-01-23 07:58:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 210
ERROR - 2024-01-23 07:58:58 --> Severity: Notice --> Undefined variable: assigned_branches C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 210
ERROR - 2024-01-23 07:58:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 210
ERROR - 2024-01-23 07:58:58 --> Severity: Notice --> Undefined variable: assigned_branches C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 210
ERROR - 2024-01-23 07:58:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 210
ERROR - 2024-01-23 07:58:58 --> Severity: Notice --> Undefined variable: assigned_branches C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 210
ERROR - 2024-01-23 07:58:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 210
ERROR - 2024-01-23 07:58:58 --> Could not find the language line "features"
ERROR - 2024-01-23 08:01:10 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:01:10 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:01:10 --> Could not find the language line "Assign to"
ERROR - 2024-01-23 08:01:10 --> Could not find the language line "Select"
ERROR - 2024-01-23 08:01:10 --> Severity: Notice --> Undefined variable: assigned_branches C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 210
ERROR - 2024-01-23 08:01:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 210
ERROR - 2024-01-23 08:01:10 --> Severity: Notice --> Undefined variable: assigned_branches C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 210
ERROR - 2024-01-23 08:01:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 210
ERROR - 2024-01-23 08:01:10 --> Severity: Notice --> Undefined variable: assigned_branches C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 210
ERROR - 2024-01-23 08:01:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 210
ERROR - 2024-01-23 08:01:10 --> Severity: Notice --> Undefined variable: assigned_branches C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 210
ERROR - 2024-01-23 08:01:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 210
ERROR - 2024-01-23 08:01:10 --> Could not find the language line "features"
ERROR - 2024-01-23 08:02:19 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:02:19 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:02:19 --> Could not find the language line "Assign to"
ERROR - 2024-01-23 08:02:19 --> Could not find the language line "Select"
ERROR - 2024-01-23 08:02:19 --> Severity: Notice --> Undefined variable: assigned_branches C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 210
ERROR - 2024-01-23 08:02:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 210
ERROR - 2024-01-23 08:02:19 --> Severity: Notice --> Undefined variable: assigned_branches C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 210
ERROR - 2024-01-23 08:02:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 210
ERROR - 2024-01-23 08:02:19 --> Severity: Notice --> Undefined variable: assigned_branches C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 210
ERROR - 2024-01-23 08:02:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 210
ERROR - 2024-01-23 08:02:19 --> Severity: Notice --> Undefined variable: assigned_branches C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 210
ERROR - 2024-01-23 08:02:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 210
ERROR - 2024-01-23 08:02:19 --> Could not find the language line "features"
ERROR - 2024-01-23 08:02:34 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:02:34 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:02:34 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:02:52 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:03:22 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:03:22 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:03:22 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:03:22 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 08:03:22 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 08:03:22 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 08:03:22 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 08:03:34 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:03:34 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:03:35 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:03:41 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:03:41 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:03:41 --> Could not find the language line "Assign to"
ERROR - 2024-01-23 08:03:41 --> Could not find the language line "Select"
ERROR - 2024-01-23 08:03:42 --> Could not find the language line "features"
ERROR - 2024-01-23 08:03:42 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:03:58 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:03:58 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:03:59 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:03:59 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:03:59 --> Could not find the language line "Assign to"
ERROR - 2024-01-23 08:03:59 --> Could not find the language line "Select"
ERROR - 2024-01-23 08:03:59 --> Could not find the language line "features"
ERROR - 2024-01-23 08:04:00 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:04:24 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:04:26 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:04:26 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:04:29 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:04:29 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:04:29 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:04:29 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 08:04:29 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 08:04:29 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 08:09:03 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:09:03 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:09:03 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:09:03 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 08:09:03 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 08:09:03 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 08:09:08 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:09:10 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:09:10 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:09:36 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:09:36 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:09:36 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:09:36 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 08:09:36 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 08:09:36 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 08:09:43 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:09:44 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:09:44 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:09:46 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:09:47 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:10:02 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:10:16 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:10:16 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:10:16 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:10:16 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 08:10:16 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 08:10:16 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 08:12:59 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:12:59 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:12:59 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:12:59 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 08:12:59 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 08:12:59 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 08:12:59 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 08:13:48 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:13:48 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:13:49 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:13:51 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:13:51 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:13:51 --> Could not find the language line "Assign to"
ERROR - 2024-01-23 08:13:51 --> Could not find the language line "Select"
ERROR - 2024-01-23 08:13:51 --> Could not find the language line "features"
ERROR - 2024-01-23 08:13:52 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:19:36 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:19:36 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:19:36 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:19:36 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 08:19:36 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 08:19:36 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 08:19:36 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-23 08:19:44 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:19:44 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:19:45 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:19:47 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:19:47 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:19:47 --> Could not find the language line "Assign to"
ERROR - 2024-01-23 08:19:47 --> Could not find the language line "Select"
ERROR - 2024-01-23 08:19:47 --> Severity: Notice --> Undefined variable: assigned_branches C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 210
ERROR - 2024-01-23 08:19:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 210
ERROR - 2024-01-23 08:19:47 --> Severity: Notice --> Undefined variable: assigned_branches C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 210
ERROR - 2024-01-23 08:19:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 210
ERROR - 2024-01-23 08:19:47 --> Severity: Notice --> Undefined variable: assigned_branches C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 210
ERROR - 2024-01-23 08:19:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 210
ERROR - 2024-01-23 08:19:47 --> Severity: Notice --> Undefined variable: assigned_branches C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 210
ERROR - 2024-01-23 08:19:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\staff\member.php 210
ERROR - 2024-01-23 08:19:47 --> Could not find the language line "features"
ERROR - 2024-01-23 08:20:35 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:20:54 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:20:54 --> Severity: Notice --> Undefined index: branch_assignment C:\xampp-new\htdocs\finishizer_erp3.0.5\application\models\Staff_model.php 452
ERROR - 2024-01-23 08:20:55 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:20:55 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:20:55 --> Could not find the language line "Assign to"
ERROR - 2024-01-23 08:20:55 --> Could not find the language line "Select"
ERROR - 2024-01-23 08:20:55 --> Could not find the language line "features"
ERROR - 2024-01-23 08:20:56 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:21:05 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:21:19 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:21:20 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:21:21 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:21:38 --> Could not find the language line "Branches"
ERROR - 2024-01-23 08:21:39 --> Could not find the language line "Branches"
