<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-18 15:38:48 --> Severity: error --> Exception: syntax error, unexpected '<<' (T_SL) C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 38
ERROR - 2023-07-18 17:40:04 --> Severity: error --> Exception: syntax error, unexpected '<<' (T_SL) C:\xampp\htdocs\finishizer_erp3.0.5\application\models\Staff_model.php 522
ERROR - 2023-07-18 15:45:35 --> Severity: error --> Exception: syntax error, unexpected '<<' (T_SL) C:\xampp\htdocs\finishizer_erp3.0.5\application\controllers\admin\Leads.php 98
