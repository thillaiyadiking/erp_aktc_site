<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-02 18:15:10 --> Could not find the language line "branch"
ERROR - 2023-08-02 18:23:51 --> Could not find the language line "branch"
ERROR - 2023-08-02 18:23:51 --> Severity: Notice --> Undefined property: Branches::$modules_helper C:\xampp\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 31
ERROR - 2023-08-02 18:23:51 --> Severity: error --> Exception: Call to a member function custom_copy() on null C:\xampp\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 31
ERROR - 2023-08-02 18:37:40 --> Could not find the language line "branch"
ERROR - 2023-08-02 18:45:07 --> Could not find the language line "branch"
ERROR - 2023-08-02 21:34:04 --> Severity: error --> Exception: Too few arguments to function App_modules::get_valid_modules(), 0 passed in C:\xampp\htdocs\finishizer_erp3.0.5\application\hooks\InitModules.php on line 16 and exactly 1 expected C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 596
ERROR - 2023-08-02 21:42:30 --> Severity: Notice --> Trying to get property 'latest_version' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\controllers\admin\Settings.php 121
ERROR - 2023-08-02 21:43:02 --> Severity: Notice --> Trying to get property 'latest_version' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\controllers\admin\Settings.php 121
