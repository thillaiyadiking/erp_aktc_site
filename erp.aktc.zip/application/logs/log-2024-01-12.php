<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-01-12 14:05:14 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp-new\htdocs\finishizer_erp3.0.5\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2024-01-12 14:05:14 --> Unable to connect to the database
ERROR - 2024-01-12 14:05:58 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp-new\htdocs\finishizer_erp3.0.5\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2024-01-12 14:06:03 --> Unable to connect to the database
ERROR - 2024-01-12 14:20:09 --> Could not find the language line "Branches"
ERROR - 2024-01-12 14:20:10 --> Could not find the language line "Branches"
ERROR - 2024-01-12 14:20:10 --> Could not find the language line "Branches"
ERROR - 2024-01-12 14:20:10 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-12 14:20:10 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-12 14:20:10 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-12 14:37:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND `tbltasks`.`id` IN (SELECT taskid FROM tbltask_assigned WHERE staffid = 3)' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tbltasks`
WHERE AND `tbltasks`.`id` IN (SELECT taskid FROM tbltask_assigned WHERE staffid = 3)
ERROR - 2024-01-12 14:38:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND `tbltasks`.`id` IN (SELECT taskid FROM tbltask_assigned WHERE staffid = 3)' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tbltasks`
WHERE AND `tbltasks`.`id` IN (SELECT taskid FROM tbltask_assigned WHERE staffid = 3)
ERROR - 2024-01-12 14:44:29 --> Could not find the language line "Branches"
ERROR - 2024-01-12 14:44:29 --> Could not find the language line "Branches"
ERROR - 2024-01-12 14:44:29 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-12 14:44:29 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-12 14:44:29 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-12 14:44:47 --> Could not find the language line "Branches"
ERROR - 2024-01-12 14:44:47 --> Could not find the language line "Branches"
ERROR - 2024-01-12 14:44:47 --> Could not find the language line "Branches"
ERROR - 2024-01-12 14:44:47 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-12 14:44:47 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-12 14:44:47 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-12 14:47:55 --> Could not find the language line "Branches"
ERROR - 2024-01-12 14:47:55 --> Could not find the language line "Branches"
ERROR - 2024-01-12 14:47:55 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-12 14:47:55 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-12 14:47:55 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-12 14:53:43 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\libraries\App.php 284
ERROR - 2024-01-12 14:54:18 --> Could not find the language line "Branches"
ERROR - 2024-01-12 14:54:18 --> Could not find the language line "Branches"
ERROR - 2024-01-12 14:54:18 --> Could not find the language line "Branches"
ERROR - 2024-01-12 14:54:18 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-12 14:54:18 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-12 14:54:18 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-12 14:54:24 --> Could not find the language line "Branches"
ERROR - 2024-01-12 14:54:26 --> Could not find the language line "Branches"
ERROR - 2024-01-12 14:54:27 --> Could not find the language line "Branches"
ERROR - 2024-01-12 14:54:29 --> Could not find the language line "Branches"
ERROR - 2024-01-12 14:54:32 --> Could not find the language line "Branches"
ERROR - 2024-01-12 14:54:33 --> Could not find the language line "Branches"
ERROR - 2024-01-12 14:54:42 --> Could not find the language line "Branches"
ERROR - 2024-01-12 14:54:42 --> Could not find the language line "Assign to"
ERROR - 2024-01-12 14:54:42 --> Could not find the language line "Select"
ERROR - 2024-01-12 14:54:42 --> Could not find the language line "features"
ERROR - 2024-01-12 14:54:43 --> Could not find the language line "Branches"
ERROR - 2024-01-12 14:55:33 --> Could not find the language line "Branches"
ERROR - 2024-01-12 14:55:35 --> Could not find the language line "Branches"
ERROR - 2024-01-12 14:55:36 --> Could not find the language line "Branches"
ERROR - 2024-01-12 14:56:08 --> Query error: Unknown column '3clientid' in 'IN/ALL/ANY subquery' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblestimates`
WHERE sale_agent=3clientid IN (SELECT userid FROM tblclients WHERE branch_id = 1)
ERROR - 2024-01-12 14:56:30 --> 404 Page Not Found: admin/Proposals/proposals
ERROR - 2024-01-12 14:58:53 --> Could not find the language line "Branches"
ERROR - 2024-01-12 14:58:53 --> Could not find the language line "Branches"
ERROR - 2024-01-12 14:58:53 --> Could not find the language line "Branches"
ERROR - 2024-01-12 14:58:53 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-12 14:58:53 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-12 14:58:53 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-12 14:59:05 --> Could not find the language line "Branches"
ERROR - 2024-01-12 14:59:06 --> Could not find the language line "Branches"
ERROR - 2024-01-12 14:59:07 --> Could not find the language line "Branches"
ERROR - 2024-01-12 14:59:12 --> Could not find the language line "Branches"
ERROR - 2024-01-12 14:59:12 --> Could not find the language line "Branches"
ERROR - 2024-01-12 14:59:12 --> Could not find the language line "Branches"
ERROR - 2024-01-12 14:59:13 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-12 14:59:13 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-12 14:59:13 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-12 14:59:23 --> Could not find the language line "Branches"
ERROR - 2024-01-12 14:59:26 --> Could not find the language line "Branches"
ERROR - 2024-01-12 14:59:26 --> Query error: Column 'id' in field list is ambiguous - Invalid query: SELECT tbltasks.name as title, id, (CASE rel_type
        WHEN "contract" THEN (SELECT subject FROM tblcontracts WHERE tblcontracts.id = tbltasks.rel_id)
        WHEN "estimate" THEN (SELECT id FROM tblestimates WHERE tblestimates.id = tbltasks.rel_id)
        WHEN "proposal" THEN (SELECT id FROM tblproposals WHERE tblproposals.id = tbltasks.rel_id)
        WHEN "invoice" THEN (SELECT id FROM tblinvoices WHERE tblinvoices.id = tbltasks.rel_id)
        WHEN "ticket" THEN (SELECT CONCAT(CONCAT("#", tbltickets.ticketid), " - ", tbltickets.subject) FROM tbltickets WHERE tbltickets.ticketid=tbltasks.rel_id)
        WHEN "lead" THEN (SELECT CASE tblleads.email WHEN "" THEN tblleads.name ELSE CONCAT(tblleads.name, " - ", tblleads.email) END FROM tblleads WHERE tblleads.id=tbltasks.rel_id)
        WHEN "customer" THEN (SELECT CASE company WHEN "" THEN (SELECT CONCAT(firstname, " ", lastname) FROM tblcontacts WHERE userid = tblclients.userid and is_primary = 1) ELSE company END FROM tblclients WHERE tblclients.userid=tbltasks.rel_id)
        WHEN "project" THEN (SELECT CONCAT(CONCAT(CONCAT("#", tblprojects.id), " - ", tblprojects.name), " - ", (SELECT CASE company WHEN "" THEN (SELECT CONCAT(firstname, " ", lastname) FROM tblcontacts WHERE userid = tblclients.userid and is_primary = 1) ELSE company END FROM tblclients WHERE userid=tblprojects.clientid)) FROM tblprojects WHERE tblprojects.id=tbltasks.rel_id)
        WHEN "expense" THEN (SELECT CASE expense_name WHEN "" THEN tblexpenses_categories.name ELSE
         CONCAT(tblexpenses_categories.name, ' (', tblexpenses.expense_name, ')') END FROM tblexpenses JOIN tblexpenses_categories ON tblexpenses_categories.id = tblexpenses.category WHERE tblexpenses.id=tbltasks.rel_id)
        ELSE NULL
        END) as rel_name, rel_id, status, milestone, CASE WHEN duedate IS NULL THEN startdate ELSE duedate END as date, `id`
FROM `tbltasks`, `tbloptions`
WHERE `status` != 5
AND CASE WHEN duedate IS NULL THEN (startdate BETWEEN '2023-12-31' AND '2024-02-11') ELSE (duedate BETWEEN '2023-12-31' AND '2024-02-11') END
AND `name` = 'calendar_only_assigned_tasks'
ERROR - 2024-01-12 14:59:26 --> Could not find the language line "Branches"
ERROR - 2024-01-12 14:59:31 --> Could not find the language line "Branches"
ERROR - 2024-01-12 14:59:37 --> Could not find the language line "Branches"
ERROR - 2024-01-12 14:59:38 --> Could not find the language line "Branches"
ERROR - 2024-01-12 14:59:42 --> Could not find the language line "Branches"
ERROR - 2024-01-12 14:59:42 --> Could not find the language line "Assign to"
ERROR - 2024-01-12 14:59:42 --> Could not find the language line "Select"
ERROR - 2024-01-12 14:59:42 --> Could not find the language line "features"
ERROR - 2024-01-12 14:59:45 --> Could not find the language line "Branches"
ERROR - 2024-01-12 15:00:43 --> Could not find the language line "Branches"
ERROR - 2024-01-12 15:00:43 --> Could not find the language line "Branches"
ERROR - 2024-01-12 15:00:45 --> Could not find the language line "Branches"
ERROR - 2024-01-12 15:00:45 --> Could not find the language line "Assign to"
ERROR - 2024-01-12 15:00:45 --> Could not find the language line "Select"
ERROR - 2024-01-12 15:00:45 --> Could not find the language line "features"
ERROR - 2024-01-12 15:00:46 --> Could not find the language line "Branches"
ERROR - 2024-01-12 15:03:15 --> Could not find the language line "Assign to"
ERROR - 2024-01-12 15:03:15 --> Could not find the language line "Select"
ERROR - 2024-01-12 15:03:15 --> Could not find the language line "features"
ERROR - 2024-01-12 16:25:03 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:25:05 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:25:08 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-12 16:25:08 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-12 16:25:08 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-12 16:26:13 --> Query error: Unknown column '3clientid' in 'IN/ALL/ANY subquery' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblestimates`
WHERE sale_agent=3clientid IN (SELECT userid FROM tblclients WHERE branch_id = 1)
ERROR - 2024-01-12 16:26:24 --> 404 Page Not Found: admin/Estimate/index
ERROR - 2024-01-12 16:27:36 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:27:36 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:27:36 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:27:36 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-12 16:27:36 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-12 16:27:36 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-12 16:27:39 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:27:41 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:27:43 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:27:43 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:27:44 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:27:56 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:27:57 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:27:59 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:28:03 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:28:03 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:28:03 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:28:10 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:29:10 --> Query error: Unknown column '3clientid' in 'IN/ALL/ANY subquery' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblestimates`
WHERE sale_agent=3clientid IN (SELECT userid FROM tblclients WHERE branch_id = 1)
ERROR - 2024-01-12 16:29:20 --> Query error: Unknown column '3clientid' in 'IN/ALL/ANY subquery' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblestimates`
WHERE sale_agent=3clientid IN (SELECT userid FROM tblclients WHERE branch_id = 1)
ERROR - 2024-01-12 16:29:31 --> Query error: Unknown column '3clientid' in 'IN/ALL/ANY subquery' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblestimates`
WHERE sale_agent=3clientid IN (SELECT userid FROM tblclients WHERE branch_id = 1)
ERROR - 2024-01-12 16:29:33 --> Query error: Unknown column '3clientid' in 'IN/ALL/ANY subquery' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblestimates`
WHERE sale_agent=3clientid IN (SELECT userid FROM tblclients WHERE branch_id = 1)
ERROR - 2024-01-12 16:29:41 --> 404 Page Not Found: admin/Estimate/index
ERROR - 2024-01-12 16:30:41 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:30:41 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:30:42 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:30:42 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-12 16:30:42 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-12 16:30:42 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-12 16:30:47 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:30:48 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:30:48 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:30:51 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:30:51 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:36:10 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:36:10 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\libraries\App.php 284
ERROR - 2024-01-12 16:36:11 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:36:13 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:40:44 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:40:44 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:40:44 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:40:44 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-12 16:40:44 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-12 16:40:44 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-12 16:40:49 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:40:50 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:40:50 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:41:29 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:41:30 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:41:31 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:41:31 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:41:33 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:41:34 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:41:34 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:41:35 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:46:06 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:46:06 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:46:06 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:46:06 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-12 16:46:06 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-12 16:46:06 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-12 16:46:09 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:46:10 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:46:10 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:46:12 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:46:13 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:46:13 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:46:16 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:50:19 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:50:19 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:50:19 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:50:21 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:50:25 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:54:14 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:54:15 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:54:16 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:58:14 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:58:15 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:58:15 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:58:16 --> Could not find the language line "Branches"
ERROR - 2024-01-12 16:58:16 --> Severity: Notice --> Undefined variable: staff C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\expenses\expense.php 132
ERROR - 2024-01-12 16:58:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 334
ERROR - 2024-01-12 17:08:36 --> Could not find the language line "Branches"
ERROR - 2024-01-12 17:08:36 --> Could not find the language line "Branches"
ERROR - 2024-01-12 17:08:37 --> Could not find the language line "Branches"
ERROR - 2024-01-12 17:19:14 --> Could not find the language line "Branches"
ERROR - 2024-01-12 17:19:15 --> Could not find the language line "Branches"
ERROR - 2024-01-12 17:19:15 --> Could not find the language line "Branches"
ERROR - 2024-01-12 17:19:17 --> Could not find the language line "Branches"
ERROR - 2024-01-12 17:19:17 --> Severity: Notice --> Undefined variable: staff C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\expenses\expense.php 132
ERROR - 2024-01-12 17:19:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 334
ERROR - 2024-01-12 17:19:42 --> Could not find the language line "Branches"
ERROR - 2024-01-12 17:21:05 --> Could not find the language line "Branches"
ERROR - 2024-01-12 17:21:05 --> Severity: Notice --> Undefined offset: 0 C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 338
ERROR - 2024-01-12 17:21:05 --> Severity: Notice --> Undefined offset: 1 C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 341
ERROR - 2024-01-12 17:21:05 --> Severity: Notice --> Undefined offset: 1 C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 342
ERROR - 2024-01-12 17:21:05 --> Severity: Notice --> Undefined index:  C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 342
ERROR - 2024-01-12 17:21:05 --> Severity: Notice --> Undefined offset: 0 C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 338
ERROR - 2024-01-12 17:21:05 --> Severity: Notice --> Undefined offset: 1 C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 341
ERROR - 2024-01-12 17:21:05 --> Severity: Notice --> Undefined offset: 1 C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 342
ERROR - 2024-01-12 17:21:05 --> Severity: Notice --> Undefined index:  C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 342
ERROR - 2024-01-12 17:21:05 --> Severity: Notice --> Undefined offset: 0 C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 338
ERROR - 2024-01-12 17:21:05 --> Severity: Notice --> Undefined offset: 1 C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 341
ERROR - 2024-01-12 17:21:05 --> Severity: Notice --> Undefined offset: 1 C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 342
ERROR - 2024-01-12 17:21:05 --> Severity: Notice --> Undefined index:  C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 342
ERROR - 2024-01-12 17:21:05 --> Severity: Notice --> Undefined offset: 0 C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 338
ERROR - 2024-01-12 17:21:05 --> Severity: Notice --> Undefined offset: 1 C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 341
ERROR - 2024-01-12 17:21:05 --> Severity: Notice --> Undefined offset: 1 C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 342
ERROR - 2024-01-12 17:21:05 --> Severity: Notice --> Undefined index:  C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 342
ERROR - 2024-01-12 17:22:33 --> Could not find the language line "Branches"
ERROR - 2024-01-12 17:22:33 --> Severity: Notice --> Undefined offset: 0 C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 338
ERROR - 2024-01-12 17:22:33 --> Severity: Notice --> Undefined offset: 1 C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 341
ERROR - 2024-01-12 17:22:33 --> Severity: Notice --> Undefined offset: 1 C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 342
ERROR - 2024-01-12 17:22:33 --> Severity: Notice --> Undefined index:  C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 342
ERROR - 2024-01-12 17:22:33 --> Severity: Notice --> Undefined offset: 0 C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 338
ERROR - 2024-01-12 17:22:33 --> Severity: Notice --> Undefined offset: 1 C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 341
ERROR - 2024-01-12 17:22:33 --> Severity: Notice --> Undefined offset: 1 C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 342
ERROR - 2024-01-12 17:22:33 --> Severity: Notice --> Undefined index:  C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 342
ERROR - 2024-01-12 17:22:33 --> Severity: Notice --> Undefined offset: 0 C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 338
ERROR - 2024-01-12 17:22:33 --> Severity: Notice --> Undefined offset: 1 C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 341
ERROR - 2024-01-12 17:22:33 --> Severity: Notice --> Undefined offset: 1 C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 342
ERROR - 2024-01-12 17:22:33 --> Severity: Notice --> Undefined index:  C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 342
ERROR - 2024-01-12 17:22:33 --> Severity: Notice --> Undefined offset: 0 C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 338
ERROR - 2024-01-12 17:22:33 --> Severity: Notice --> Undefined offset: 1 C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 341
ERROR - 2024-01-12 17:22:33 --> Severity: Notice --> Undefined offset: 1 C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 342
ERROR - 2024-01-12 17:22:33 --> Severity: Notice --> Undefined index:  C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 342
ERROR - 2024-01-12 17:28:31 --> Could not find the language line "Branches"
ERROR - 2024-01-12 17:30:38 --> Could not find the language line "Branches"
ERROR - 2024-01-12 17:34:35 --> Could not find the language line "Branches"
ERROR - 2024-01-12 17:34:35 --> Severity: Notice --> Undefined index: name C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 342
ERROR - 2024-01-12 17:34:35 --> Severity: Notice --> Undefined index: name C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 342
ERROR - 2024-01-12 17:34:35 --> Severity: Notice --> Undefined index: name C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 342
ERROR - 2024-01-12 17:34:35 --> Severity: Notice --> Undefined index: name C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 342
ERROR - 2024-01-12 17:36:15 --> Could not find the language line "Branches"
