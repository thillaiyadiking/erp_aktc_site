<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-12-11 05:44:20 --> Severity: Notice --> Undefined variable: branch_clients C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 18
ERROR - 2023-12-11 05:44:20 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 18
ERROR - 2023-12-11 05:44:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `status` NOT IN (5,6) AND `clientid` IN ()
ERROR - 2023-12-11 05:45:36 --> Severity: Notice --> Undefined variable: branch_clients C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 18
ERROR - 2023-12-11 05:45:36 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 18
ERROR - 2023-12-11 05:45:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `status` NOT IN (5,6) AND `clientid` IN ()
ERROR - 2023-12-11 05:45:38 --> Severity: Notice --> Undefined variable: branch_clients C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 18
ERROR - 2023-12-11 05:45:38 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 18
ERROR - 2023-12-11 05:45:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `status` NOT IN (5,6) AND `clientid` IN ()
ERROR - 2023-12-11 05:45:43 --> Severity: Notice --> Undefined variable: branch_clients C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 18
ERROR - 2023-12-11 05:45:43 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 18
ERROR - 2023-12-11 05:45:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `status` NOT IN (5,6) AND `clientid` IN ()
ERROR - 2023-12-11 05:58:03 --> Severity: Notice --> Undefined index: id C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 21
ERROR - 2023-12-11 05:58:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 21
ERROR - 2023-12-11 05:59:25 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 21
ERROR - 2023-12-11 05:59:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 21
ERROR - 2023-12-11 05:59:43 --> Severity: Notice --> Undefined index: branch_id C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 21
ERROR - 2023-12-11 05:59:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 21
ERROR - 2023-12-11 06:02:21 --> Severity: Notice --> Undefined variable: bid C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 22
ERROR - 2023-12-11 06:02:21 --> Severity: Notice --> Undefined variable: bid C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 22
ERROR - 2023-12-11 06:02:21 --> Severity: Notice --> Undefined variable: bid C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 22
ERROR - 2023-12-11 06:02:21 --> Severity: Notice --> Undefined variable: bid C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 22
ERROR - 2023-12-11 06:08:59 --> Severity: Notice --> Array to string conversion C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 18
ERROR - 2023-12-11 06:08:59 --> Severity: Notice --> Array to string conversion C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 18
ERROR - 2023-12-11 06:08:59 --> Severity: Notice --> Array to string conversion C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 18
ERROR - 2023-12-11 06:08:59 --> Severity: Notice --> Array to string conversion C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 18
ERROR - 2023-12-11 06:08:59 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `status` NOT IN (5,6) AND `clientid` IN (Array,Array,Array,Array)
ERROR - 2023-12-11 06:10:22 --> Severity: Notice --> Array to string conversion C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 18
ERROR - 2023-12-11 06:10:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'Array' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `status` NOT IN (5,6) AND clientid IN Array
ERROR - 2023-12-11 06:10:23 --> Severity: Notice --> Array to string conversion C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 18
ERROR - 2023-12-11 06:10:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'Array' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `status` NOT IN (5,6) AND clientid IN Array
