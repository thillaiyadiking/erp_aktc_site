<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-01-15 05:47:35 --> Could not find the language line "Branches"
ERROR - 2024-01-15 05:47:35 --> Could not find the language line "Branches"
ERROR - 2024-01-15 05:47:35 --> Could not find the language line "Branches"
ERROR - 2024-01-15 05:47:35 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-15 05:47:35 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-15 05:47:35 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-15 05:47:46 --> Could not find the language line "Branches"
ERROR - 2024-01-15 05:47:49 --> Could not find the language line "Branches"
ERROR - 2024-01-15 05:47:49 --> Could not find the language line "Branches"
ERROR - 2024-01-15 05:47:50 --> Could not find the language line "Branches"
ERROR - 2024-01-15 05:47:52 --> Could not find the language line "Branches"
ERROR - 2024-01-15 05:47:52 --> Could not find the language line "Branches"
ERROR - 2024-01-15 05:47:54 --> Could not find the language line "Branches"
ERROR - 2024-01-15 05:50:21 --> Could not find the language line "Branches"
ERROR - 2024-01-15 05:50:21 --> Could not find the language line "Branches"
ERROR - 2024-01-15 05:50:22 --> Could not find the language line "Branches"
ERROR - 2024-01-15 05:50:25 --> Could not find the language line "Branches"
ERROR - 2024-01-15 06:10:45 --> Could not find the language line "Branches"
ERROR - 2024-01-15 06:10:45 --> Could not find the language line "Branches"
ERROR - 2024-01-15 06:10:45 --> Could not find the language line "Branches"
ERROR - 2024-01-15 06:10:45 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-15 06:10:45 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-15 06:10:45 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-15 06:10:48 --> Could not find the language line "Branches"
ERROR - 2024-01-15 06:10:49 --> Could not find the language line "Branches"
ERROR - 2024-01-15 06:10:49 --> Could not find the language line "Branches"
ERROR - 2024-01-15 06:10:56 --> Could not find the language line "Branches"
ERROR - 2024-01-15 06:10:57 --> Could not find the language line "Branches"
ERROR - 2024-01-15 06:10:57 --> Could not find the language line "Branches"
ERROR - 2024-01-15 06:10:58 --> Could not find the language line "Branches"
ERROR - 2024-01-15 06:10:58 --> Severity: error --> Exception: syntax error, unexpected 'b' (T_STRING) C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\expenses\expense.php 76
ERROR - 2024-01-15 06:11:55 --> Could not find the language line "Branches"
ERROR - 2024-01-15 06:11:55 --> Severity: Notice --> Undefined variable: title C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\expenses\expense.php 14
ERROR - 2024-01-15 06:11:55 --> Severity: Notice --> Undefined variable: members C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\expenses\expense.php 84
ERROR - 2024-01-15 06:11:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 334
ERROR - 2024-01-15 13:25:10 --> Could not find the language line "Branches"
ERROR - 2024-01-15 13:25:10 --> Could not find the language line "Branches"
ERROR - 2024-01-15 13:25:11 --> Could not find the language line "Branches"
ERROR - 2024-01-15 13:25:11 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-15 13:25:11 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-15 13:25:11 --> Could not find the language line "View Dashboard"
ERROR - 2024-01-15 13:25:15 --> Could not find the language line "Branches"
ERROR - 2024-01-15 13:25:18 --> Could not find the language line "Branches"
ERROR - 2024-01-15 13:25:19 --> Could not find the language line "Branches"
ERROR - 2024-01-15 13:25:19 --> Could not find the language line "Branches"
ERROR - 2024-01-15 13:25:20 --> Could not find the language line "Branches"
ERROR - 2024-01-15 13:25:20 --> Could not find the language line "Branches"
ERROR - 2024-01-15 13:25:25 --> Could not find the language line "Branches"
ERROR - 2024-01-15 13:25:25 --> Severity: Notice --> Undefined variable: title C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\expenses\expense.php 14
ERROR - 2024-01-15 13:25:25 --> Severity: Notice --> Undefined variable: members C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\expenses\expense.php 84
ERROR - 2024-01-15 13:25:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 334
ERROR - 2024-01-15 13:28:05 --> Could not find the language line "Branches"
ERROR - 2024-01-15 13:28:05 --> Severity: Notice --> Undefined variable: members C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\expenses\expense.php 84
ERROR - 2024-01-15 13:28:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 334
ERROR - 2024-01-15 13:29:30 --> Could not find the language line "Branches"
ERROR - 2024-01-15 13:29:51 --> Could not find the language line "Branches"
ERROR - 2024-01-15 13:29:51 --> Query error: Unknown column 'member' in 'field list' - Invalid query: UPDATE `tblexpenses` SET `expense_name` = 'br1_expense', `note` = '', `category` = '1', `date` = '2023-10-05', `amount` = '50000.00', `member` = '3', `clientid` = '2', `project_id` = 0, `currency` = '1', `tax` = '', `tax2` = '', `paymentmode` = '', `reference_no` = '', `repeat_every` = '', `cycles` = 0, `total_cycles` = 0, `last_recurring_date` = NULL, `recurring` = 0, `create_invoice_billable` = 0, `billable` = 0, `send_invoice_to_customer` = 0
WHERE `id` = '1'
ERROR - 2024-01-15 13:29:58 --> Could not find the language line "Branches"
ERROR - 2024-01-15 13:29:58 --> Query error: Unknown column 'member' in 'field list' - Invalid query: UPDATE `tblexpenses` SET `expense_name` = 'br1_expense', `note` = '', `category` = '1', `date` = '2023-10-05', `amount` = '50000.00', `member` = '3', `clientid` = '2', `project_id` = 0, `currency` = '1', `tax` = '', `tax2` = '', `paymentmode` = '', `reference_no` = '', `repeat_every` = '', `cycles` = 0, `total_cycles` = 0, `last_recurring_date` = NULL, `recurring` = 0, `create_invoice_billable` = 0, `billable` = 0, `send_invoice_to_customer` = 0
WHERE `id` = '1'
ERROR - 2024-01-15 13:31:17 --> Could not find the language line "Branches"
ERROR - 2024-01-15 13:31:17 --> Query error: Unknown column 'member' in 'field list' - Invalid query: UPDATE `tblexpenses` SET `expense_name` = 'br1_expense', `note` = '', `category` = '1', `date` = '2023-10-05', `amount` = '50000.00', `member` = '3', `clientid` = '2', `project_id` = 0, `currency` = '1', `tax` = '', `tax2` = '', `paymentmode` = '', `reference_no` = '', `repeat_every` = '', `cycles` = 0, `total_cycles` = 0, `last_recurring_date` = NULL, `recurring` = 0, `create_invoice_billable` = 0, `billable` = 0, `send_invoice_to_customer` = 0
WHERE `id` = '1'
ERROR - 2024-01-15 13:33:29 --> Could not find the language line "Branches"
ERROR - 2024-01-15 13:33:34 --> Could not find the language line "Branches"
ERROR - 2024-01-15 13:33:34 --> Query error: Unknown column 'member' in 'field list' - Invalid query: UPDATE `tblexpenses` SET `expense_name` = 'br1_expense', `note` = '', `category` = '1', `date` = '2023-10-05', `amount` = '50000.00', `member` = '1', `clientid` = '2', `project_id` = 0, `currency` = '1', `tax` = '', `tax2` = '', `paymentmode` = '', `reference_no` = '', `repeat_every` = '', `cycles` = 0, `total_cycles` = 0, `last_recurring_date` = NULL, `recurring` = 0, `create_invoice_billable` = 0, `billable` = 0, `send_invoice_to_customer` = 0
WHERE `id` = '1'
ERROR - 2024-01-15 13:34:40 --> Could not find the language line "Branches"
ERROR - 2024-01-15 13:34:57 --> Could not find the language line "Branches"
ERROR - 2024-01-15 13:34:57 --> Query error: Unknown column 'member' in 'field list' - Invalid query: UPDATE `tblexpenses` SET `expense_name` = 'br1_expense', `note` = '', `category` = '1', `date` = '2023-10-05', `amount` = '50000.00', `member` = '3', `clientid` = '', `project_id` = 0, `currency` = '11', `tax` = '', `tax2` = '', `paymentmode` = '', `reference_no` = '', `repeat_every` = '', `cycles` = 0, `total_cycles` = 0, `last_recurring_date` = NULL, `recurring` = 0, `create_invoice_billable` = 0, `billable` = 0, `send_invoice_to_customer` = 0
WHERE `id` = '1'
ERROR - 2024-01-15 13:35:30 --> Could not find the language line "Branches"
ERROR - 2024-01-15 13:35:40 --> Could not find the language line "Branches"
ERROR - 2024-01-15 13:35:40 --> Query error: Unknown column 'member' in 'field list' - Invalid query: UPDATE `tblexpenses` SET `expense_name` = 'br1_expense', `note` = '', `category` = '1', `date` = '2023-10-05', `amount` = '50000.00', `member` = '', `clientid` = '2', `project_id` = 0, `currency` = '1', `tax` = '', `tax2` = '', `paymentmode` = '', `reference_no` = '', `repeat_every` = '', `cycles` = 0, `total_cycles` = 0, `last_recurring_date` = NULL, `recurring` = 0, `create_invoice_billable` = 0, `billable` = 0, `send_invoice_to_customer` = 0
WHERE `id` = '1'
ERROR - 2024-01-15 13:36:57 --> Could not find the language line "Branches"
ERROR - 2024-01-15 13:37:09 --> Could not find the language line "Branches"
ERROR - 2024-01-15 13:37:23 --> Could not find the language line "Branches"
ERROR - 2024-01-15 13:37:35 --> Could not find the language line "Branches"
ERROR - 2024-01-15 13:38:11 --> Could not find the language line "Branches"
ERROR - 2024-01-15 13:38:17 --> Could not find the language line "Branches"
ERROR - 2024-01-15 13:38:18 --> Could not find the language line "Branches"
ERROR - 2024-01-15 13:38:18 --> Could not find the language line "Branches"
ERROR - 2024-01-15 13:38:19 --> Could not find the language line "Branches"
ERROR - 2024-01-15 13:38:19 --> Could not find the language line "Branches"
ERROR - 2024-01-15 13:38:59 --> Could not find the language line "Branches"
ERROR - 2024-01-15 13:39:00 --> Could not find the language line "Branches"
ERROR - 2024-01-15 13:39:00 --> Could not find the language line "Branches"
ERROR - 2024-01-15 13:39:00 --> Could not find the language line "Branches"
ERROR - 2024-01-15 13:39:03 --> Could not find the language line "Branches"
ERROR - 2024-01-15 14:00:57 --> Could not find the language line "Branches"
ERROR - 2024-01-15 14:10:17 --> 404 Page Not Found: admin/Brnaches/index
