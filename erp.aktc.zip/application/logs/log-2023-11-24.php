<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-24 04:07:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp-new\htdocs\finishizer_erp3.0.5\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2023-11-24 04:07:13 --> Unable to connect to the database
ERROR - 2023-11-24 04:11:33 --> Query error: Table 'finishizer_erp.tblsessions' doesn't exist in engine - Invalid query: SELECT `data`
FROM `tblsessions`
WHERE `id` = 'ikamlur4eeg6aojp0rcbmrovqvd3357a'
ERROR - 2023-11-24 04:11:33 --> Severity: Warning --> session_write_close(): Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2023-11-24 04:11:33 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: C:\xampp-new\tmp) Unknown 0
ERROR - 2023-11-24 04:59:16 --> Query error: Table 'finishizer_erp.tblsessions' doesn't exist in engine - Invalid query: SELECT 1
FROM `tblsessions`
WHERE `id` = 'ikamlur4eeg6aojp0rcbmrovqvd3357a'
ERROR - 2023-11-24 05:15:02 --> Unable to delete cache file for admin/dashboard/dashboard
ERROR - 2023-11-24 05:15:09 --> Unable to delete cache file for admin/dashboard/dashboard
ERROR - 2023-11-24 06:10:24 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\libraries\App.php 277
ERROR - 2023-11-24 06:19:29 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\libraries\App.php 277
ERROR - 2023-11-24 06:19:29 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\libraries\App.php 277
