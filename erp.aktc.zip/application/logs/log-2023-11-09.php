<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-09 04:59:07 --> Severity: error --> Exception: Too few arguments to function Dashboard::branch_dashboard(), 0 passed in C:\xampp-new\htdocs\finishizer_erp3.0.5\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Dashboard.php 97
ERROR - 2023-11-09 05:15:31 --> 404 Page Not Found: admin/Dashboard/1
ERROR - 2023-11-09 05:31:04 --> Severity: Notice --> Undefined variable: CI C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 8
ERROR - 2023-11-09 05:31:04 --> Severity: Notice --> Trying to get property 'app_menu' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 8
ERROR - 2023-11-09 05:31:04 --> Severity: error --> Exception: Call to a member function add_sidebar_menu_item() on null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\menu_helper.php 8
