<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-02 04:00:53 --> 404 Page Not Found: 
ERROR - 2023-11-02 04:08:58 --> 404 Page Not Found: admin/Dashboard/2
ERROR - 2023-11-02 04:09:06 --> 404 Page Not Found: admin/Dashboard/1
ERROR - 2023-11-02 04:12:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblestimates`
WHERE `clientid` IN (SELECT userid FROM tblclients WHERE branch_id=)
ERROR - 2023-11-02 04:12:35 --> 404 Page Not Found: admin/Dashboard/1
ERROR - 2023-11-02 04:16:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblestimates`
WHERE `clientid` IN (SELECT userid FROM tblclients WHERE branch_id=)
ERROR - 2023-11-02 04:17:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblestimates`
WHERE `clientid` IN (SELECT userid FROM tblclients WHERE branch_id=)
ERROR - 2023-11-02 04:17:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblestimates`
WHERE `clientid` IN (SELECT userid FROM tblclients WHERE branch_id=)
ERROR - 2023-11-02 04:17:45 --> 404 Page Not Found: admin/Dashboard/1
ERROR - 2023-11-02 04:19:13 --> 404 Page Not Found: admin/Dashboard/1
ERROR - 2023-11-02 04:43:37 --> 404 Page Not Found: 
ERROR - 2023-11-02 04:54:59 --> 404 Page Not Found: 
ERROR - 2023-11-02 04:55:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblestimates`
WHERE `clientid` IN (SELECT userid FROM tblclients WHERE branch_id=)
