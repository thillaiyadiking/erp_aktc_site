<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-28 22:52:44 --> Severity: error --> Exception: Call to undefined function get_current_branch() C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 603
ERROR - 2023-07-28 23:01:27 --> Severity: error --> Exception: Call to undefined function get_current_branch() C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 603
ERROR - 2023-07-28 23:01:29 --> Severity: error --> Exception: Call to undefined function get_current_branch() C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 603
ERROR - 2023-07-28 23:01:31 --> Severity: error --> Exception: Call to undefined function get_current_branch() C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 603
ERROR - 2023-07-28 23:01:50 --> Severity: error --> Exception: Call to undefined function get_current_branch() C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 603
ERROR - 2023-07-28 23:01:51 --> Severity: error --> Exception: Call to undefined function get_current_branch() C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 603
ERROR - 2023-07-28 23:02:27 --> Severity: error --> Exception: Call to undefined function get_current_branch() C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\App_modules.php 603
