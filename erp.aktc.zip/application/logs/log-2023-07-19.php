<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-19 23:26:09 --> Severity: Warning --> Cannot use a scalar value as an array C:\xampp\htdocs\finishizer_erp3.0.5\application\controllers\admin\Authentication.php 100
