<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-21 00:53:23 --> Severity: Notice --> Undefined variable: stripe_tax_rates C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\subscriptions\form.php 154
ERROR - 2023-06-21 00:53:23 --> Severity: Notice --> Trying to get property 'data' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\subscriptions\form.php 154
ERROR - 2023-06-21 00:53:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\subscriptions\form.php 154
ERROR - 2023-06-21 00:53:23 --> Severity: Notice --> Undefined variable: stripe_tax_rates C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\subscriptions\form.php 186
ERROR - 2023-06-21 00:53:23 --> Severity: Notice --> Trying to get property 'data' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\subscriptions\form.php 186
ERROR - 2023-06-21 00:53:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\subscriptions\form.php 186
ERROR - 2023-06-21 23:06:59 --> Could not find the language line "branches"
ERROR - 2023-06-21 23:07:00 --> Could not find the language line "branches"
ERROR - 2023-06-21 23:07:00 --> Could not find the language line "branches"
ERROR - 2023-06-21 22:49:20 --> 404 Page Not Found: admin/Branches/index
ERROR - 2023-06-21 23:08:59 --> 404 Page Not Found: admin/Branches/index
ERROR - 2023-06-21 23:09:43 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file C:\xampp\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 4
