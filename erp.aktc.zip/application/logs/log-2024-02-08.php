<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-02-08 06:10:03 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 06:10:03 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 06:10:03 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 06:10:09 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 06:10:12 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 06:10:13 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 06:10:14 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 06:10:14 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 06:10:27 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 06:10:28 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 06:10:28 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 06:17:35 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 06:17:35 --> Could not find the language line "Add new branch"
ERROR - 2024-02-08 06:17:35 --> Severity: Notice --> Undefined variable: currencies C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 24
ERROR - 2024-02-08 06:17:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 334
ERROR - 2024-02-08 06:19:51 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 06:19:51 --> Could not find the language line "Add new branch"
ERROR - 2024-02-08 06:19:51 --> Severity: Notice --> Undefined variable: currencies C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 24
ERROR - 2024-02-08 06:19:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 334
ERROR - 2024-02-08 06:20:08 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 06:20:08 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 06:20:08 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 06:20:12 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 06:20:13 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 06:20:13 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 06:20:17 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 06:20:18 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 06:20:21 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 06:26:16 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 06:26:20 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 06:26:20 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 06:26:20 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 06:26:22 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 06:26:22 --> Could not find the language line "Add new branch"
ERROR - 2024-02-08 06:29:35 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 06:29:35 --> Could not find the language line "Add new branch"
ERROR - 2024-02-08 06:33:29 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 06:33:29 --> Could not find the language line "Add new branch"
ERROR - 2024-02-08 06:37:54 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 06:37:54 --> Could not find the language line "Add new branch"
ERROR - 2024-02-08 06:54:32 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 06:54:32 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 06:54:32 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 06:54:52 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 06:54:52 --> Could not find the language line "Add new branch"
ERROR - 2024-02-08 06:55:27 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 06:55:27 --> Query error: Unknown column 'address' in 'field list' - Invalid query: INSERT INTO `tblbranches` (`branch_name`, `address`, `city`, `state`, `zip`, `country`) VALUES ('dxb branch', 'tower1', 'deira', 'dubai', '00000000', '194')
ERROR - 2024-02-08 06:56:59 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 06:56:59 --> Query error: Unknown column 'address' in 'field list' - Invalid query: INSERT INTO `tblbranches` (`branch_name`, `address`, `city`, `state`, `zip`, `country`) VALUES ('dxb branch', 'tower1', 'deira', 'dubai', '00000000', '194')
ERROR - 2024-02-08 06:57:06 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 06:57:06 --> Could not find the language line "Add new branch"
ERROR - 2024-02-08 06:57:07 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 06:57:07 --> Could not find the language line "Add new branch"
ERROR - 2024-02-08 06:58:03 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 06:58:03 --> Could not find the language line "Add new branch"
ERROR - 2024-02-08 06:58:46 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 06:58:46 --> Could not find the language line "Add new branch"
ERROR - 2024-02-08 06:59:16 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 06:59:16 --> Could not find the language line "branch"
ERROR - 2024-02-08 06:59:17 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 07:26:01 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 07:26:01 --> Could not find the language line "Add new branch"
ERROR - 2024-02-08 07:26:18 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 07:26:19 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 07:26:19 --> Could not find the language line "Add new branch"
ERROR - 2024-02-08 07:26:46 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 07:26:46 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 07:26:46 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 07:26:46 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 07:26:46 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 07:26:56 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 07:26:56 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 07:26:58 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 07:29:48 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 07:29:49 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 07:29:51 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 07:29:59 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 07:30:00 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 07:34:05 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 07:34:05 --> Could not find the language line "Add new branch"
ERROR - 2024-02-08 07:37:00 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 07:37:00 --> Could not find the language line "Add new branch"
ERROR - 2024-02-08 07:37:55 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 07:38:02 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 07:38:02 --> Could not find the language line "Add new branch"
ERROR - 2024-02-08 07:38:14 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 09:05:26 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 09:05:26 --> Could not find the language line "Branches"
ERROR - 2024-02-08 09:05:26 --> Could not find the language line "branch_dt_name"
ERROR - 2024-02-08 09:05:26 --> Severity: Notice --> Undefined variable: branchess C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 19
ERROR - 2024-02-08 09:05:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 19
ERROR - 2024-02-08 09:05:42 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 09:05:42 --> Could not find the language line "Branches"
ERROR - 2024-02-08 09:05:43 --> Could not find the language line "branch_dt_name"
ERROR - 2024-02-08 09:05:43 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 21
ERROR - 2024-02-08 09:08:26 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 09:08:26 --> Could not find the language line "Branches"
ERROR - 2024-02-08 09:08:26 --> Could not find the language line "branch_dt_name"
ERROR - 2024-02-08 09:08:26 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 30
ERROR - 2024-02-08 09:08:52 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 09:08:52 --> Could not find the language line "Branches"
ERROR - 2024-02-08 09:08:53 --> Could not find the language line "branch_dt_name"
ERROR - 2024-02-08 09:17:02 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 09:17:02 --> Could not find the language line "Branches"
ERROR - 2024-02-08 09:17:02 --> Could not find the language line "branch_dt_name"
ERROR - 2024-02-08 09:19:01 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 09:19:01 --> Could not find the language line "Branches"
ERROR - 2024-02-08 09:19:01 --> Could not find the language line "branch_dt_name"
ERROR - 2024-02-08 07:19:02 --> 404 Page Not Found: admin/Branches/edit
ERROR - 2024-02-08 09:19:33 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 09:19:33 --> Could not find the language line "Branches"
ERROR - 2024-02-08 09:19:33 --> Could not find the language line "branch_dt_name"
ERROR - 2024-02-08 09:19:35 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 09:19:35 --> Could not find the language line "Branches"
ERROR - 2024-02-08 09:19:35 --> Could not find the language line "branch_dt_name"
ERROR - 2024-02-08 09:19:37 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 09:19:37 --> Could not find the language line "Add new branch"
ERROR - 2024-02-08 09:20:08 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 09:20:08 --> Could not find the language line "Branch"
ERROR - 2024-02-08 09:20:08 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 09:20:08 --> Could not find the language line "Branches"
ERROR - 2024-02-08 09:20:08 --> Could not find the language line "branch_dt_name"
ERROR - 2024-02-08 09:20:13 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 09:20:13 --> Could not find the language line "Add new branch"
ERROR - 2024-02-08 09:35:25 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 09:35:25 --> Could not find the language line "Add new branch"
ERROR - 2024-02-08 09:42:07 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 09:42:07 --> Query error: Table 'finishizer2.tbltblbranches' doesn't exist - Invalid query: SELECT *
FROM `tbltblbranches`
WHERE `branch_id` = '1'
ORDER BY `branch_name` ASC
ERROR - 2024-02-08 09:42:39 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 09:42:39 --> Could not find the language line "Add new branch"
ERROR - 2024-02-08 09:42:40 --> Severity: Notice --> Trying to get property 'branch_name' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 22
ERROR - 2024-02-08 09:43:46 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 09:43:46 --> Could not find the language line "Add new branch"
ERROR - 2024-02-08 09:43:46 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 22
ERROR - 2024-02-08 09:44:17 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 09:44:17 --> Could not find the language line "Add new branch"
ERROR - 2024-02-08 09:47:53 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 09:47:53 --> Could not find the language line "Add new branch"
ERROR - 2024-02-08 09:50:31 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 09:50:31 --> Could not find the language line "Add new branch"
ERROR - 2024-02-08 09:51:27 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 09:51:27 --> Could not find the language line "Add new branch"
ERROR - 2024-02-08 09:51:27 --> Could not find the language line "Edit branch"
ERROR - 2024-02-08 09:51:37 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 09:51:37 --> Could not find the language line "Branch"
ERROR - 2024-02-08 09:51:37 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 09:51:37 --> Could not find the language line "Branches"
ERROR - 2024-02-08 09:51:37 --> Could not find the language line "branch_dt_name"
ERROR - 2024-02-08 09:51:37 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 21
ERROR - 2024-02-08 09:51:38 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 23
ERROR - 2024-02-08 09:51:38 --> Severity: Notice --> Trying to get property 'branch_name' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 24
ERROR - 2024-02-08 09:51:38 --> Severity: Notice --> Trying to get property 'branch_name' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 24
ERROR - 2024-02-08 09:51:38 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 28
ERROR - 2024-02-08 09:51:38 --> Severity: Notice --> Trying to get property 'branch_name' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 29
ERROR - 2024-02-08 09:51:38 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 33
ERROR - 2024-02-08 09:51:38 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 21
ERROR - 2024-02-08 09:51:38 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 23
ERROR - 2024-02-08 09:51:38 --> Severity: Notice --> Trying to get property 'branch_name' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 24
ERROR - 2024-02-08 09:51:38 --> Severity: Notice --> Trying to get property 'branch_name' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 24
ERROR - 2024-02-08 09:51:38 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 28
ERROR - 2024-02-08 09:51:38 --> Severity: Notice --> Trying to get property 'branch_name' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 29
ERROR - 2024-02-08 09:51:38 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 33
ERROR - 2024-02-08 09:51:38 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 21
ERROR - 2024-02-08 09:51:38 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 23
ERROR - 2024-02-08 09:51:38 --> Severity: Notice --> Trying to get property 'branch_name' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 24
ERROR - 2024-02-08 09:51:38 --> Severity: Notice --> Trying to get property 'branch_name' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 24
ERROR - 2024-02-08 09:51:38 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 28
ERROR - 2024-02-08 09:51:38 --> Severity: Notice --> Trying to get property 'branch_name' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 29
ERROR - 2024-02-08 09:51:38 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 33
ERROR - 2024-02-08 09:51:38 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 21
ERROR - 2024-02-08 09:51:38 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 23
ERROR - 2024-02-08 09:51:38 --> Severity: Notice --> Trying to get property 'branch_name' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 24
ERROR - 2024-02-08 09:51:38 --> Severity: Notice --> Trying to get property 'branch_name' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 24
ERROR - 2024-02-08 09:51:38 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 28
ERROR - 2024-02-08 09:51:38 --> Severity: Notice --> Trying to get property 'branch_name' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 29
ERROR - 2024-02-08 09:51:38 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 33
ERROR - 2024-02-08 09:52:00 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 09:52:00 --> Could not find the language line "Branches"
ERROR - 2024-02-08 09:52:00 --> Could not find the language line "branch_dt_name"
ERROR - 2024-02-08 09:52:08 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 09:52:08 --> Could not find the language line "Add new branch"
ERROR - 2024-02-08 09:52:37 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 09:52:37 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Dashboard.php 25
ERROR - 2024-02-08 09:53:24 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 09:53:24 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 09:53:24 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 09:53:24 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 09:53:24 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 09:53:32 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 09:53:33 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\includes\header.php 88
ERROR - 2024-02-08 09:54:36 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 09:54:37 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 09:54:38 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 09:54:52 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 09:54:52 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 09:54:55 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 10:01:46 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 10:08:29 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 10:08:29 --> Severity: Notice --> Undefined variable: branch C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\clients\groups\profile.php 195
ERROR - 2024-02-08 10:08:29 --> Severity: Notice --> Trying to get property 'branch_country' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\clients\groups\profile.php 195
ERROR - 2024-02-08 10:08:48 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 10:13:29 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 10:13:30 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 17:26:09 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 17:26:09 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 17:26:09 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 17:26:09 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 17:26:09 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 17:26:19 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 17:26:19 --> Could not find the language line "Add new branch"
ERROR - 2024-02-08 17:26:22 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 17:26:22 --> Could not find the language line "Branches"
ERROR - 2024-02-08 17:26:22 --> Could not find the language line "branch_dt_name"
ERROR - 2024-02-08 17:26:27 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 17:26:27 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 17:26:27 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 17:26:27 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 17:26:27 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 17:58:25 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 17:58:25 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 17:58:25 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 17:58:25 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 17:58:25 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:02:18 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:02:18 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:02:18 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:02:18 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:02:18 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:02:22 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:02:22 --> Could not find the language line "Add new branch"
ERROR - 2024-02-08 18:02:29 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:02:29 --> Could not find the language line "Branches"
ERROR - 2024-02-08 18:02:29 --> Could not find the language line "branch_dt_name"
ERROR - 2024-02-08 18:02:43 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:02:45 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:02:47 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:02:47 --> Could not find the language line "Branches"
ERROR - 2024-02-08 18:02:47 --> Could not find the language line "branch_dt_name"
ERROR - 2024-02-08 18:02:50 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:02:50 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:02:50 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:02:50 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:02:50 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:02:53 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:02:53 --> Could not find the language line "Add new branch"
ERROR - 2024-02-08 18:02:55 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:02:55 --> Could not find the language line "Branches"
ERROR - 2024-02-08 18:02:55 --> Could not find the language line "branch_dt_name"
ERROR - 2024-02-08 18:04:01 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:04:02 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:04:02 --> Could not find the language line "Branches"
ERROR - 2024-02-08 18:04:02 --> Could not find the language line "branch_dt_name"
ERROR - 2024-02-08 18:04:11 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:04:12 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:04:22 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:04:23 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:04:29 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:04:30 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:04:31 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:04:32 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:04:33 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:04:35 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:04:38 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:04:39 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:04:39 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:04:40 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:04:40 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:04:40 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:04:44 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:04:47 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:04:50 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:04:54 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:04:54 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:05:00 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:05:04 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:05:04 --> Severity: Notice --> Trying to get property 'email' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 24
ERROR - 2024-02-08 18:05:04 --> Severity: Notice --> Trying to get property 'active' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 44
ERROR - 2024-02-08 18:05:04 --> Severity: Notice --> Trying to get property 'imap_server' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 51
ERROR - 2024-02-08 18:05:04 --> Severity: Notice --> Trying to get property 'email' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 52
ERROR - 2024-02-08 18:05:04 --> Severity: Notice --> Trying to get property 'password' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 53
ERROR - 2024-02-08 18:05:04 --> Severity: Notice --> Trying to get property 'encryption' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 65
ERROR - 2024-02-08 18:05:04 --> Severity: Notice --> Trying to get property 'encryption' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 71
ERROR - 2024-02-08 18:05:04 --> Severity: Notice --> Trying to get property 'encryption' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 77
ERROR - 2024-02-08 18:05:04 --> Severity: Notice --> Trying to get property 'folder' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 93
ERROR - 2024-02-08 18:05:04 --> Severity: Notice --> Trying to get property 'folder' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 93
ERROR - 2024-02-08 18:05:04 --> Severity: Notice --> Trying to get property 'check_every' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 97
ERROR - 2024-02-08 18:05:04 --> Severity: Notice --> Trying to get property 'only_loop_on_unseen_emails' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 100
ERROR - 2024-02-08 18:05:04 --> Severity: Notice --> Trying to get property 'create_task_if_customer' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 110
ERROR - 2024-02-08 18:05:04 --> Severity: Notice --> Trying to get property 'delete_after_import' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 120
ERROR - 2024-02-08 18:05:04 --> Severity: Notice --> Trying to get property 'mark_public' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 127
ERROR - 2024-02-08 18:05:04 --> Severity: Notice --> Trying to get property 'lead_status' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 136
ERROR - 2024-02-08 18:05:04 --> Severity: Notice --> Trying to get property 'lead_source' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 143
ERROR - 2024-02-08 18:05:04 --> Severity: Notice --> Trying to get property 'responsible' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 150
ERROR - 2024-02-08 18:05:04 --> Severity: Notice --> Trying to get property 'responsible' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 150
ERROR - 2024-02-08 18:05:04 --> Severity: Notice --> Trying to get property 'responsible' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 150
ERROR - 2024-02-08 18:05:04 --> Severity: Notice --> Trying to get property 'responsible' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 150
ERROR - 2024-02-08 18:05:04 --> Severity: Notice --> Trying to get property 'notify_lead_imported' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 161
ERROR - 2024-02-08 18:05:04 --> Severity: Notice --> Trying to get property 'notify_lead_contact_more_times' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 169
ERROR - 2024-02-08 18:05:04 --> Severity: Notice --> Trying to get property 'notify_lead_imported' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 175
ERROR - 2024-02-08 18:05:04 --> Severity: Notice --> Trying to get property 'notify_type' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 181
ERROR - 2024-02-08 18:05:04 --> Severity: Notice --> Trying to get property 'notify_type' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 188
ERROR - 2024-02-08 18:05:04 --> Severity: Notice --> Trying to get property 'notify_type' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 195
ERROR - 2024-02-08 18:05:04 --> Severity: Notice --> Trying to get property 'notify_type' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 201
ERROR - 2024-02-08 18:05:04 --> Severity: Notice --> Trying to get property 'notify_type' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 206
ERROR - 2024-02-08 18:05:04 --> Severity: Notice --> Trying to get property 'notify_type' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 212
ERROR - 2024-02-08 18:05:04 --> Severity: Notice --> Trying to get property 'notify_type' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 217
ERROR - 2024-02-08 18:05:07 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:05:08 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:05:10 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:05:11 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:05:33 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:05:34 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:05:36 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:05:37 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:05:43 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:05:43 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:05:44 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:06:04 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:06:06 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:06:14 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:06:15 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:06:17 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:06:18 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:06:19 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:06:21 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:06:38 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:06:38 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:07:38 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:07:38 --> Severity: Notice --> Trying to get property 'branch_name' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/includes/header.php 88
ERROR - 2024-02-08 18:08:21 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:08:21 --> Severity: Notice --> Trying to get property 'branch_name' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/includes/header.php 88
ERROR - 2024-02-08 18:08:22 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:08:25 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:08:25 --> Severity: Notice --> Trying to get property 'branch_name' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/includes/header.php 88
ERROR - 2024-02-08 18:08:25 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:08:27 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:08:27 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:08:27 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:08:27 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:08:27 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:08:30 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:08:30 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:08:40 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:08:40 --> Severity: Notice --> Trying to get property 'email' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 24
ERROR - 2024-02-08 18:08:40 --> Severity: Notice --> Trying to get property 'active' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 44
ERROR - 2024-02-08 18:08:40 --> Severity: Notice --> Trying to get property 'imap_server' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 51
ERROR - 2024-02-08 18:08:40 --> Severity: Notice --> Trying to get property 'email' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 52
ERROR - 2024-02-08 18:08:40 --> Severity: Notice --> Trying to get property 'password' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 53
ERROR - 2024-02-08 18:08:40 --> Severity: Notice --> Trying to get property 'encryption' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 65
ERROR - 2024-02-08 18:08:40 --> Severity: Notice --> Trying to get property 'encryption' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 71
ERROR - 2024-02-08 18:08:40 --> Severity: Notice --> Trying to get property 'encryption' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 77
ERROR - 2024-02-08 18:08:40 --> Severity: Notice --> Trying to get property 'folder' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 93
ERROR - 2024-02-08 18:08:40 --> Severity: Notice --> Trying to get property 'folder' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 93
ERROR - 2024-02-08 18:08:40 --> Severity: Notice --> Trying to get property 'check_every' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 97
ERROR - 2024-02-08 18:08:40 --> Severity: Notice --> Trying to get property 'only_loop_on_unseen_emails' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 100
ERROR - 2024-02-08 18:08:40 --> Severity: Notice --> Trying to get property 'create_task_if_customer' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 110
ERROR - 2024-02-08 18:08:40 --> Severity: Notice --> Trying to get property 'delete_after_import' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 120
ERROR - 2024-02-08 18:08:40 --> Severity: Notice --> Trying to get property 'mark_public' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 127
ERROR - 2024-02-08 18:08:40 --> Severity: Notice --> Trying to get property 'lead_status' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 136
ERROR - 2024-02-08 18:08:40 --> Severity: Notice --> Trying to get property 'lead_source' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 143
ERROR - 2024-02-08 18:08:40 --> Severity: Notice --> Trying to get property 'responsible' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 150
ERROR - 2024-02-08 18:08:40 --> Severity: Notice --> Trying to get property 'responsible' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 150
ERROR - 2024-02-08 18:08:40 --> Severity: Notice --> Trying to get property 'responsible' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 150
ERROR - 2024-02-08 18:08:40 --> Severity: Notice --> Trying to get property 'responsible' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 150
ERROR - 2024-02-08 18:08:40 --> Severity: Notice --> Trying to get property 'notify_lead_imported' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 161
ERROR - 2024-02-08 18:08:40 --> Severity: Notice --> Trying to get property 'notify_lead_contact_more_times' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 169
ERROR - 2024-02-08 18:08:40 --> Severity: Notice --> Trying to get property 'notify_lead_imported' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 175
ERROR - 2024-02-08 18:08:40 --> Severity: Notice --> Trying to get property 'notify_type' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 181
ERROR - 2024-02-08 18:08:40 --> Severity: Notice --> Trying to get property 'notify_type' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 188
ERROR - 2024-02-08 18:08:40 --> Severity: Notice --> Trying to get property 'notify_type' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 195
ERROR - 2024-02-08 18:08:40 --> Severity: Notice --> Trying to get property 'notify_type' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 201
ERROR - 2024-02-08 18:08:40 --> Severity: Notice --> Trying to get property 'notify_type' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 206
ERROR - 2024-02-08 18:08:40 --> Severity: Notice --> Trying to get property 'notify_type' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 212
ERROR - 2024-02-08 18:08:40 --> Severity: Notice --> Trying to get property 'notify_type' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 217
ERROR - 2024-02-08 18:08:48 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:08:49 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:08:52 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:08:53 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:08:54 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:08:55 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:08:56 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:08:57 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:08:59 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:09:00 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:09:00 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:09:05 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:09:08 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:09:12 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:09:19 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:09:32 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:09:37 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:09:44 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:09:49 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:09:55 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:10:03 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:10:17 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:10:20 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:10:30 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:10:37 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:10:39 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:10:40 --> Could not find the language line "data"
ERROR - 2024-02-08 18:10:49 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:10:53 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:10:56 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:10:59 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:11:06 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:11:07 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:11:09 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:11:09 --> Could not find the language line "features"
ERROR - 2024-02-08 18:11:11 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:11:12 --> Severity: Notice --> Trying to get property 'branch_name' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/includes/header.php 88
ERROR - 2024-02-08 18:11:17 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:11:17 --> Severity: Notice --> Trying to get property 'branch_name' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/includes/header.php 88
ERROR - 2024-02-08 18:11:21 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:11:21 --> Severity: Notice --> Trying to get property 'branch_name' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/includes/header.php 88
ERROR - 2024-02-08 18:11:22 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:11:24 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:11:24 --> Severity: Notice --> Trying to get property 'branch_name' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/includes/header.php 88
ERROR - 2024-02-08 18:11:24 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:11:26 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:11:26 --> Severity: Notice --> Trying to get property 'branch_name' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/includes/header.php 88
ERROR - 2024-02-08 18:11:27 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:11:28 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:11:28 --> Severity: Notice --> Trying to get property 'branch_name' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/includes/header.php 88
ERROR - 2024-02-08 18:11:29 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:11:32 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:11:32 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:11:32 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:11:32 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:11:32 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 23:11:32 --> 404 Page Not Found: /index
ERROR - 2024-02-08 18:11:35 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:11:35 --> Severity: Notice --> Trying to get property 'branch_name' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/includes/header.php 88
ERROR - 2024-02-08 23:11:35 --> 404 Page Not Found: /index
ERROR - 2024-02-08 18:11:40 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:11:40 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:11:40 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:11:40 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:11:40 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:11:43 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:11:43 --> 404 Page Not Found: /index
ERROR - 2024-02-08 18:11:44 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:11:47 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:11:47 --> Severity: Notice --> Trying to get property 'branch_name' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/includes/header.php 88
ERROR - 2024-02-08 23:11:47 --> 404 Page Not Found: /index
ERROR - 2024-02-08 18:11:50 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:11:50 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:11:54 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:11:54 --> Severity: Notice --> Trying to get property 'branch_name' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/includes/header.php 88
ERROR - 2024-02-08 23:11:55 --> 404 Page Not Found: /index
ERROR - 2024-02-08 18:17:00 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:17:00 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:17:00 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:17:00 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:17:00 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 23:17:00 --> 404 Page Not Found: /index
ERROR - 2024-02-08 18:17:02 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:17:03 --> 404 Page Not Found: /index
ERROR - 2024-02-08 18:17:04 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:17:04 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:17:08 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:17:08 --> 404 Page Not Found: /index
ERROR - 2024-02-08 18:17:09 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:17:11 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:17:12 --> 404 Page Not Found: /index
ERROR - 2024-02-08 18:17:12 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:17:14 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:17:14 --> 404 Page Not Found: /index
ERROR - 2024-02-08 18:17:15 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:17:16 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:17:16 --> 404 Page Not Found: /index
ERROR - 2024-02-08 18:17:17 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:17:18 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:17:18 --> 404 Page Not Found: /index
ERROR - 2024-02-08 18:17:18 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:17:19 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:17:20 --> 404 Page Not Found: /index
ERROR - 2024-02-08 18:17:20 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:17:21 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:17:22 --> 404 Page Not Found: /index
ERROR - 2024-02-08 18:17:22 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:17:24 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:17:24 --> 404 Page Not Found: /index
ERROR - 2024-02-08 18:17:24 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:17:26 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:17:27 --> 404 Page Not Found: /index
ERROR - 2024-02-08 18:17:27 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:17:27 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:17:28 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:17:28 --> 404 Page Not Found: /index
ERROR - 2024-02-08 18:17:29 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:17:30 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:17:30 --> 404 Page Not Found: /index
ERROR - 2024-02-08 18:17:31 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:17:32 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:17:33 --> 404 Page Not Found: /index
ERROR - 2024-02-08 18:17:33 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:17:34 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:17:35 --> 404 Page Not Found: /index
ERROR - 2024-02-08 18:17:35 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:17:36 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:17:36 --> 404 Page Not Found: /index
ERROR - 2024-02-08 18:17:37 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:17:48 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:17:49 --> 404 Page Not Found: /index
ERROR - 2024-02-08 18:17:49 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:17:51 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:17:51 --> 404 Page Not Found: /index
ERROR - 2024-02-08 18:17:52 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:17:56 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:17:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '"invoice ORDER BY taxname ASC' at line 1 - Invalid query: SELECT DISTINCT taxname,tblitem_tax.taxrate FROM tblitem_tax LEFT JOIN tbltaxes ON tblitem_tax.taxname = tbltaxes.name WHERE rel_type="invoice ORDER BY taxname ASC
ERROR - 2024-02-08 18:18:00 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:18:01 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:18:03 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:18:04 --> 404 Page Not Found: /index
ERROR - 2024-02-08 18:18:07 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:18:07 --> 404 Page Not Found: /index
ERROR - 2024-02-08 18:18:08 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:18:09 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:18:10 --> 404 Page Not Found: /index
ERROR - 2024-02-08 18:18:10 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:18:12 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:18:12 --> 404 Page Not Found: /index
ERROR - 2024-02-08 18:18:13 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:18:15 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:18:15 --> 404 Page Not Found: /index
ERROR - 2024-02-08 18:18:24 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:18:25 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:18:25 --> 404 Page Not Found: /index
ERROR - 2024-02-08 18:18:32 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:18:33 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:18:33 --> 404 Page Not Found: /index
ERROR - 2024-02-08 18:18:35 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:18:35 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:18:35 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:18:35 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:18:35 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 23:18:35 --> 404 Page Not Found: /index
ERROR - 2024-02-08 18:22:13 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:22:13 --> 404 Page Not Found: /index
ERROR - 2024-02-08 18:22:14 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:22:14 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:22:18 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:22:18 --> 404 Page Not Found: /index
ERROR - 2024-02-08 18:22:19 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:22:19 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:22:22 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:22:23 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:22:23 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:22:58 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:22:58 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:22:58 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:22:58 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:22:58 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 23:22:58 --> 404 Page Not Found: /index
ERROR - 2024-02-08 18:27:14 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:27:15 --> 404 Page Not Found: /index
ERROR - 2024-02-08 18:27:16 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:27:16 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:27:17 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:27:17 --> 404 Page Not Found: /index
ERROR - 2024-02-08 18:27:18 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:27:18 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:27:21 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:27:21 --> 404 Page Not Found: /index
ERROR - 2024-02-08 18:27:22 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:27:22 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:27:23 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:27:24 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:27:24 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:27:26 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:27:26 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:27:26 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:27:26 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:27:26 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:27:29 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:27:29 --> 404 Page Not Found: /index
ERROR - 2024-02-08 18:27:30 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:27:30 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:27:31 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:27:31 --> 404 Page Not Found: /index
ERROR - 2024-02-08 18:27:32 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:27:32 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:27:34 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:27:35 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:27:35 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:27:36 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:27:36 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:27:36 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:27:36 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:27:36 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:27:39 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:27:39 --> 404 Page Not Found: /index
ERROR - 2024-02-08 18:27:40 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:27:40 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:27:43 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:27:43 --> 404 Page Not Found: /index
ERROR - 2024-02-08 18:27:44 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:27:44 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:27:46 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:27:47 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:27:47 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:27:48 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:27:48 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:27:48 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:27:48 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:27:48 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:27:51 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:27:51 --> 404 Page Not Found: /index
ERROR - 2024-02-08 18:27:52 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:27:52 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:27:55 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:27:56 --> 404 Page Not Found: /index
ERROR - 2024-02-08 18:27:56 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:27:56 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:27:58 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:27:58 --> 404 Page Not Found: /index
ERROR - 2024-02-08 18:27:59 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:27:59 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:31:01 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:31:01 --> 404 Page Not Found: /index
ERROR - 2024-02-08 18:31:02 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:31:02 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:31:05 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:31:05 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:31:05 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:31:05 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:31:05 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 23:31:06 --> 404 Page Not Found: /index
ERROR - 2024-02-08 18:31:07 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:31:08 --> 404 Page Not Found: /index
ERROR - 2024-02-08 18:31:09 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:31:09 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:31:11 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:31:11 --> 404 Page Not Found: /index
ERROR - 2024-02-08 18:31:14 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:31:15 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:31:15 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:31:18 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:31:18 --> 404 Page Not Found: /index
ERROR - 2024-02-08 18:31:19 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:31:19 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:31:57 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:31:57 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:31:57 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:31:57 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:31:57 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 23:31:58 --> 404 Page Not Found: /index
ERROR - 2024-02-08 18:32:04 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:32:05 --> 404 Page Not Found: /index
ERROR - 2024-02-08 18:32:14 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:32:14 --> 404 Page Not Found: /index
ERROR - 2024-02-08 18:32:17 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:32:18 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:32:46 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:32:46 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:32:50 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:32:52 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:32:56 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:32:56 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:32:56 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:32:56 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:32:56 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:32:59 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:32:59 --> Could not find the language line "Add new branch"
ERROR - 2024-02-08 18:33:01 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:33:01 --> Could not find the language line "Branches"
ERROR - 2024-02-08 18:33:01 --> Could not find the language line "branch_dt_name"
ERROR - 2024-02-08 18:33:04 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:33:04 --> Could not find the language line "Add new branch"
ERROR - 2024-02-08 18:33:12 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:33:13 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:40:34 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:40:38 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:40:42 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:40:44 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:40:45 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:40:51 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:40:54 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:40:57 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:40:58 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:40:58 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:41:01 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:41:03 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:41:04 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:41:04 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:41:06 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:41:07 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:41:07 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:41:11 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:41:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '"invoice ORDER BY taxname ASC' at line 1 - Invalid query: SELECT DISTINCT taxname,tblitem_tax.taxrate FROM tblitem_tax LEFT JOIN tbltaxes ON tblitem_tax.taxname = tbltaxes.name WHERE rel_type="invoice ORDER BY taxname ASC
ERROR - 2024-02-08 18:41:17 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:41:18 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:41:18 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:45:14 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:45:15 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:45:17 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:45:18 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:45:19 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:45:20 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:45:22 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:45:22 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:45:23 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:45:24 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:45:25 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:45:26 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:45:28 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:45:33 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:45:33 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:45:36 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:45:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '"invoice ORDER BY taxname ASC' at line 1 - Invalid query: SELECT DISTINCT taxname,tblitem_tax.taxrate FROM tblitem_tax LEFT JOIN tbltaxes ON tblitem_tax.taxname = tbltaxes.name WHERE rel_type="invoice ORDER BY taxname ASC
ERROR - 2024-02-08 18:45:39 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:45:39 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:45:43 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:45:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '"invoice ORDER BY taxname ASC' at line 1 - Invalid query: SELECT DISTINCT taxname,tblitem_tax.taxrate FROM tblitem_tax LEFT JOIN tbltaxes ON tblitem_tax.taxname = tbltaxes.name WHERE rel_type="invoice ORDER BY taxname ASC
ERROR - 2024-02-08 18:45:44 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:45:45 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:45:47 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:45:50 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:45:50 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:45:52 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:45:53 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:45:54 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:45:55 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:45:57 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:46:00 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:46:02 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:46:04 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:46:05 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:46:06 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:46:08 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:46:09 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:46:14 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:46:14 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:46:15 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:46:17 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:46:17 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:46:18 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:46:20 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:46:22 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:46:23 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:46:29 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:46:30 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:46:33 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:46:34 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:46:37 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:46:37 --> Could not find the language line "features"
ERROR - 2024-02-08 18:47:13 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:47:16 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:47:17 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:47:17 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:48:31 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:48:31 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:48:31 --> Could not find the language line "features"
ERROR - 2024-02-08 18:48:31 --> Could not find the language line "capabilities"
ERROR - 2024-02-08 18:48:31 --> Could not find the language line "permission_view_all_templates"
ERROR - 2024-02-08 18:48:31 --> Could not find the language line "permission_view_all_templates"
ERROR - 2024-02-08 18:48:49 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:48:50 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:48:50 --> Could not find the language line "features"
ERROR - 2024-02-08 18:50:00 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:50:00 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:50:00 --> Could not find the language line "features"
ERROR - 2024-02-08 18:50:04 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:50:06 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:50:06 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:50:06 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:50:07 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:50:07 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:50:10 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:50:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '"invoice ORDER BY taxname ASC' at line 1 - Invalid query: SELECT DISTINCT taxname,tblitem_tax.taxrate FROM tblitem_tax LEFT JOIN tbltaxes ON tblitem_tax.taxname = tbltaxes.name WHERE rel_type="invoice ORDER BY taxname ASC
ERROR - 2024-02-08 18:50:11 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:50:12 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:50:12 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:50:14 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:50:20 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:50:21 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:50:22 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:50:40 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:50:40 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:50:40 --> Could not find the language line "features"
ERROR - 2024-02-08 18:50:45 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:50:45 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:50:46 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:50:46 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:50:48 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:50:49 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:50:49 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:50:49 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:50:52 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:50:54 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:50:55 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:50:55 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:50:56 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:50:58 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:50:59 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:50:59 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:51:01 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:51:03 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:51:04 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:51:04 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:51:05 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:51:06 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:51:08 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:51:09 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:51:11 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:51:12 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:51:13 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:51:14 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:51:14 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:51:15 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:51:16 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:51:17 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:51:18 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:51:19 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:51:19 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:51:20 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:51:21 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:51:22 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:51:23 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:51:25 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:51:26 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:51:27 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:51:28 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:51:29 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:51:30 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:51:31 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:51:32 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:51:35 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:51:41 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:51:42 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:51:44 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:51:45 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:51:48 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:52:27 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:52:27 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:52:27 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:52:27 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:52:27 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:52:31 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:52:31 --> Could not find the language line "Add new branch"
ERROR - 2024-02-08 18:52:34 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:52:34 --> Could not find the language line "Branches"
ERROR - 2024-02-08 18:52:34 --> Could not find the language line "branch_dt_name"
ERROR - 2024-02-08 18:52:40 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:52:42 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:53:36 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:53:36 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:53:36 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:53:36 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:53:36 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 18:53:49 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:53:51 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:53:51 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:53:54 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:54:02 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:54:03 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:54:06 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 18:54:07 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 19:51:35 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 19:51:35 --> Severity: Notice --> Trying to get property 'branch_name' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/includes/header.php 88
ERROR - 2024-02-08 19:51:43 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 19:51:43 --> Severity: Notice --> Trying to get property 'email' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 24
ERROR - 2024-02-08 19:51:43 --> Severity: Notice --> Trying to get property 'active' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 44
ERROR - 2024-02-08 19:51:43 --> Severity: Notice --> Trying to get property 'imap_server' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 51
ERROR - 2024-02-08 19:51:43 --> Severity: Notice --> Trying to get property 'email' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 52
ERROR - 2024-02-08 19:51:43 --> Severity: Notice --> Trying to get property 'password' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 53
ERROR - 2024-02-08 19:51:43 --> Severity: Notice --> Trying to get property 'encryption' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 65
ERROR - 2024-02-08 19:51:43 --> Severity: Notice --> Trying to get property 'encryption' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 71
ERROR - 2024-02-08 19:51:43 --> Severity: Notice --> Trying to get property 'encryption' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 77
ERROR - 2024-02-08 19:51:43 --> Severity: Notice --> Trying to get property 'folder' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 93
ERROR - 2024-02-08 19:51:43 --> Severity: Notice --> Trying to get property 'folder' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 93
ERROR - 2024-02-08 19:51:43 --> Severity: Notice --> Trying to get property 'check_every' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 97
ERROR - 2024-02-08 19:51:43 --> Severity: Notice --> Trying to get property 'only_loop_on_unseen_emails' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 100
ERROR - 2024-02-08 19:51:43 --> Severity: Notice --> Trying to get property 'create_task_if_customer' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 110
ERROR - 2024-02-08 19:51:43 --> Severity: Notice --> Trying to get property 'delete_after_import' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 120
ERROR - 2024-02-08 19:51:43 --> Severity: Notice --> Trying to get property 'mark_public' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 127
ERROR - 2024-02-08 19:51:43 --> Severity: Notice --> Trying to get property 'lead_status' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 136
ERROR - 2024-02-08 19:51:43 --> Severity: Notice --> Trying to get property 'lead_source' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 143
ERROR - 2024-02-08 19:51:43 --> Severity: Notice --> Trying to get property 'responsible' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 150
ERROR - 2024-02-08 19:51:43 --> Severity: Notice --> Trying to get property 'responsible' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 150
ERROR - 2024-02-08 19:51:43 --> Severity: Notice --> Trying to get property 'responsible' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 150
ERROR - 2024-02-08 19:51:43 --> Severity: Notice --> Trying to get property 'responsible' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 150
ERROR - 2024-02-08 19:51:43 --> Severity: Notice --> Trying to get property 'notify_lead_imported' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 161
ERROR - 2024-02-08 19:51:43 --> Severity: Notice --> Trying to get property 'notify_lead_contact_more_times' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 169
ERROR - 2024-02-08 19:51:43 --> Severity: Notice --> Trying to get property 'notify_lead_imported' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 175
ERROR - 2024-02-08 19:51:43 --> Severity: Notice --> Trying to get property 'notify_type' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 181
ERROR - 2024-02-08 19:51:43 --> Severity: Notice --> Trying to get property 'notify_type' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 188
ERROR - 2024-02-08 19:51:43 --> Severity: Notice --> Trying to get property 'notify_type' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 195
ERROR - 2024-02-08 19:51:43 --> Severity: Notice --> Trying to get property 'notify_type' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 201
ERROR - 2024-02-08 19:51:43 --> Severity: Notice --> Trying to get property 'notify_type' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 206
ERROR - 2024-02-08 19:51:43 --> Severity: Notice --> Trying to get property 'notify_type' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 212
ERROR - 2024-02-08 19:51:43 --> Severity: Notice --> Trying to get property 'notify_type' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/leads/email_integration.php 217
ERROR - 2024-02-08 19:51:48 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 19:51:48 --> Severity: Notice --> Trying to get property 'branch_name' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/includes/header.php 88
ERROR - 2024-02-08 19:51:56 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 19:51:56 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 19:51:56 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 19:51:56 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 19:51:56 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 19:52:16 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 19:52:27 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 19:52:27 --> Severity: Notice --> Trying to get property 'branch_name' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/includes/header.php 88
ERROR - 2024-02-08 19:52:42 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 19:52:43 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 19:52:44 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 19:52:46 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 19:52:46 --> Severity: Notice --> Trying to get property 'branch_name' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/includes/header.php 88
ERROR - 2024-02-08 19:52:47 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 19:53:02 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 19:53:03 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 19:53:06 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 19:53:06 --> Could not find the language line "Assign to"
ERROR - 2024-02-08 19:53:06 --> Could not find the language line "Select"
ERROR - 2024-02-08 19:53:06 --> Could not find the language line "features"
ERROR - 2024-02-08 19:53:07 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 19:53:31 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 19:53:32 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 19:53:32 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 19:53:32 --> Could not find the language line "Assign to"
ERROR - 2024-02-08 19:53:32 --> Could not find the language line "Select"
ERROR - 2024-02-08 19:53:32 --> Could not find the language line "features"
ERROR - 2024-02-08 19:53:34 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 19:53:35 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 19:53:39 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 19:53:40 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 19:53:40 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 19:53:42 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 19:53:48 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 19:53:49 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 19:53:49 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 19:53:51 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 19:53:52 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 19:53:52 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 19:53:57 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 20:00:50 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 20:00:50 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 20:00:50 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 20:00:50 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 20:00:50 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 20:01:02 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 20:01:04 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 20:01:04 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 20:01:05 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 20:01:06 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 20:01:06 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 20:01:12 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 20:01:18 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 20:01:19 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 20:01:30 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 20:01:31 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 20:01:31 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 20:01:32 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 20:01:33 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 20:01:33 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 20:01:34 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 20:01:40 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 20:01:41 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 20:01:45 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 20:01:46 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 20:01:47 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 20:01:48 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 20:01:48 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 20:01:50 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 20:01:51 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 20:01:52 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 20:01:53 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 20:01:56 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 20:01:57 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 20:01:58 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 20:01:59 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 20:02:00 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 20:02:01 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 20:02:01 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 20:02:02 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 20:02:04 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 20:02:05 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 20:02:09 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 20:02:12 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 20:02:13 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 20:02:15 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 20:02:16 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 20:02:19 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 20:02:19 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 20:02:19 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 20:02:19 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 20:02:19 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 20:02:21 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 20:02:22 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 20:02:26 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 20:02:26 --> Could not find the language line "Assign to"
ERROR - 2024-02-08 20:02:26 --> Could not find the language line "Select"
ERROR - 2024-02-08 20:02:26 --> Could not find the language line "features"
ERROR - 2024-02-08 20:02:27 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 20:06:53 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 20:06:53 --> Severity: Notice --> Trying to get property 'branch_name' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/includes/header.php 88
ERROR - 2024-02-08 20:06:54 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 20:27:51 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 20:27:51 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 20:27:51 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 20:27:51 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 20:27:51 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 22:57:52 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 22:58:01 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 22:58:02 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 22:58:09 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 22:58:09 --> Severity: Notice --> Trying to get property 'branch_name' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/includes/header.php 88
ERROR - 2024-02-08 23:00:03 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:00:03 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 23:00:03 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 23:00:03 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 23:00:03 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 23:00:16 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:00:16 --> Severity: Notice --> Trying to get property 'branch_name' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/includes/header.php 88
ERROR - 2024-02-08 23:00:18 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:00:19 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:00:19 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 23:00:19 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 23:00:19 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 23:00:19 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 23:00:22 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:00:23 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:00:23 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:00:29 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:00:29 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 23:00:29 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 23:00:29 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 23:00:29 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 23:00:40 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:00:40 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 23:00:40 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 23:00:40 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 23:00:40 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 23:00:46 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:00:46 --> Severity: Notice --> Trying to get property 'branch_name' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/includes/header.php 88
ERROR - 2024-02-08 23:00:47 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:00:49 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:00:49 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 23:00:49 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 23:00:49 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 23:00:49 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-08 23:00:51 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:00:52 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:00:56 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:00:56 --> Could not find the language line "Assign to"
ERROR - 2024-02-08 23:00:56 --> Could not find the language line "Select"
ERROR - 2024-02-08 23:00:56 --> Could not find the language line "features"
ERROR - 2024-02-08 23:00:57 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:01:06 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:01:06 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:01:07 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:01:07 --> Could not find the language line "Assign to"
ERROR - 2024-02-08 23:01:07 --> Could not find the language line "Select"
ERROR - 2024-02-08 23:01:07 --> Could not find the language line "features"
ERROR - 2024-02-08 23:01:08 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:45:13 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:45:13 --> Could not find the language line "Add new branch"
ERROR - 2024-02-08 23:45:23 --> Could not find the language line "Main Dashboard"
ERROR - 2024-02-08 23:45:23 --> Could not find the language line "Branches"
ERROR - 2024-02-08 23:45:23 --> Could not find the language line "branch_dt_name"
