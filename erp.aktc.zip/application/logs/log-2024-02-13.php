<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-02-13 01:17:07 --> Severity: Notice --> Trying to get property 'branch_name' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/includes/header.php 88
