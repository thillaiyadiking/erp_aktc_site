<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-22 14:09:36 --> Query error: Column 'branch_id' cannot be null - Invalid query: INSERT INTO `tblbranch_options` (`branch_id`, `option_id`, `value`, `autoload`) VALUES (NULL, 569, '', 1)
ERROR - 2023-11-22 14:09:36 --> Query error: Column 'branch_id' cannot be null - Invalid query: INSERT INTO `tblbranch_options` (`branch_id`, `option_id`, `value`, `autoload`) VALUES (NULL, 570, '', 1)
ERROR - 2023-11-22 14:15:35 --> Query error: Column 'branch_id' cannot be null - Invalid query: INSERT INTO `tblbranch_options` (`branch_id`, `option_id`, `value`, `autoload`) VALUES (NULL, 571, '', 1)
