<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-04 05:54:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblestimates`
WHERE `clientid` IN (SELECT userid FROM tblclients WHERE branch_id=)
ERROR - 2023-10-04 05:55:41 --> Could not find the language line "features"
ERROR - 2023-10-04 05:56:21 --> Severity: Notice --> Undefined index: activated C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\email_templates_helper.php 163
ERROR - 2023-10-04 05:56:21 --> Severity: error --> Exception: Too few arguments to function Staff_created::__construct(), 2 passed in C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\email_templates_helper.php on line 146 and exactly 3 expected C:\xampp\htdocs\finishizer_erp3.0.5\application\libraries\mails\Staff_created.php 19
ERROR - 2023-10-04 05:56:46 --> Could not find the language line "features"
ERROR - 2023-10-04 05:58:47 --> Could not find the language line "features"
ERROR - 2023-10-04 06:14:45 --> Severity: Warning --> Illegal string offset 'app-field-wrapper' C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 70
ERROR - 2023-10-04 06:14:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 72
ERROR - 2023-10-04 06:14:45 --> Could not find the language line "features"
ERROR - 2023-10-04 06:17:34 --> Could not find the language line "features"
ERROR - 2023-10-04 06:21:54 --> Could not find the language line "features"
ERROR - 2023-10-04 06:23:48 --> Could not find the language line "features"
ERROR - 2023-10-04 06:24:33 --> Could not find the language line "features"
ERROR - 2023-10-04 06:33:09 --> Could not find the language line "features"
ERROR - 2023-10-04 06:33:24 --> Could not find the language line "features"
ERROR - 2023-10-04 06:34:00 --> 404 Page Not Found: /index
ERROR - 2023-10-04 06:34:00 --> 404 Page Not Found: /index
ERROR - 2023-10-04 06:34:18 --> 404 Page Not Found: /index
ERROR - 2023-10-04 06:34:18 --> 404 Page Not Found: /index
ERROR - 2023-10-04 06:34:33 --> 404 Page Not Found: /index
ERROR - 2023-10-04 06:34:33 --> 404 Page Not Found: /index
ERROR - 2023-10-04 06:35:16 --> Could not find the language line "branch"
ERROR - 2023-10-04 06:57:55 --> Could not find the language line "features"
ERROR - 2023-10-04 06:58:39 --> Could not find the language line "features"
ERROR - 2023-10-04 07:04:23 --> Could not find the language line "features"
ERROR - 2023-10-04 07:04:36 --> Could not find the language line "features"
ERROR - 2023-10-04 07:04:45 --> 404 Page Not Found: /index
ERROR - 2023-10-04 07:04:46 --> 404 Page Not Found: /index
ERROR - 2023-10-04 07:05:16 --> 404 Page Not Found: /index
ERROR - 2023-10-04 07:05:16 --> 404 Page Not Found: /index
ERROR - 2023-10-04 07:05:34 --> 404 Page Not Found: /index
ERROR - 2023-10-04 07:05:35 --> 404 Page Not Found: /index
