<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-26 18:07:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'branch_id 1
    
    ORDER BY firstname ASC
    LIMIT 0, 25' at line 5 - Invalid query: 
    SELECT SQL_CALC_FOUND_ROWS firstname, email, `tblroles`.`name` AS `tblroles.name`, last_login, active ,profile_image,lastname,staffid
    FROM tblstaff
    LEFT JOIN tblroles ON tblroles.roleid = tblstaff.role
    
    branch_id 1
    
    ORDER BY firstname ASC
    LIMIT 0, 25
    
ERROR - 2023-07-26 18:18:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
    
    ORDER BY firstname ASC
    LIMIT 0, 25' at line 5 - Invalid query: 
    SELECT SQL_CALC_FOUND_ROWS firstname, email, `tblroles`.`name` AS `tblroles.name`, last_login, active ,profile_image,lastname,staffid,branch_id
    FROM tblstaff
    LEFT JOIN tblroles ON tblroles.roleid = tblstaff.role
    
    1
    
    ORDER BY firstname ASC
    LIMIT 0, 25
    
ERROR - 2023-07-26 18:19:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
    
    ORDER BY firstname ASC
    LIMIT 0, 25' at line 5 - Invalid query: 
    SELECT SQL_CALC_FOUND_ROWS firstname, email, `tblroles`.`name` AS `tblroles.name`, last_login, active ,profile_image,lastname,staffid,branch_id
    FROM tblstaff
    LEFT JOIN tblroles ON tblroles.roleid = tblstaff.role
    
    1
    
    ORDER BY firstname ASC
    LIMIT 0, 25
    
ERROR - 2023-07-26 18:52:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1
    
    ORDER BY firstname ASC
    LIMIT 0, 25' at line 5 - Invalid query: 
    SELECT SQL_CALC_FOUND_ROWS firstname, email, `tblroles`.`name` AS `tblroles.name`, last_login, active ,profile_image,lastname,staffid,branch_id
    FROM tblstaff
    LEFT JOIN tblroles ON tblroles.roleid = tblstaff.role
    
    1
    
    ORDER BY firstname ASC
    LIMIT 0, 25
    
ERROR - 2023-07-26 18:52:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'branch_id 1
    
    ORDER BY firstname ASC
    LIMIT 0, 25' at line 5 - Invalid query: 
    SELECT SQL_CALC_FOUND_ROWS firstname, email, `tblroles`.`name` AS `tblroles.name`, last_login, active ,profile_image,lastname,staffid,branch_id
    FROM tblstaff
    LEFT JOIN tblroles ON tblroles.roleid = tblstaff.role
    
    branch_id 1
    
    ORDER BY firstname ASC
    LIMIT 0, 25
    
ERROR - 2023-07-26 18:53:01 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\tables\staff.php 36
ERROR - 2023-07-26 18:53:01 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\datatables_helper.php 214
ERROR - 2023-07-26 18:53:19 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\tables\staff.php 36
ERROR - 2023-07-26 18:53:19 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\datatables_helper.php 214
ERROR - 2023-07-26 18:59:52 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\tables\staff.php 36
ERROR - 2023-07-26 18:59:52 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\datatables_helper.php 214
ERROR - 2023-07-26 19:01:51 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\datatables_helper.php 214
ERROR - 2023-07-26 19:10:03 --> Severity: Notice --> Undefined property: App::$session C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\tables\staff.php 36
ERROR - 2023-07-26 19:10:03 --> Severity: error --> Exception: Call to a member function userdata() on null C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\tables\staff.php 36
ERROR - 2023-07-26 19:15:38 --> Severity: Notice --> Undefined property: App::$session C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\tables\staff.php 36
ERROR - 2023-07-26 19:15:38 --> Severity: error --> Exception: Call to a member function userdata() on null C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\tables\staff.php 36
ERROR - 2023-07-26 19:16:07 --> Severity: Notice --> Undefined variable: CI C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\tables\staff.php 36
ERROR - 2023-07-26 19:16:07 --> Severity: Notice --> Trying to get property 'session' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\tables\staff.php 36
ERROR - 2023-07-26 19:16:07 --> Severity: error --> Exception: Call to a member function userdata() on null C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\tables\staff.php 36
ERROR - 2023-07-26 19:17:11 --> Severity: Notice --> Undefined variable: CI C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 586
ERROR - 2023-07-26 19:17:11 --> Severity: Notice --> Trying to get property 'session' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 586
ERROR - 2023-07-26 19:17:11 --> Severity: error --> Exception: Call to a member function userdata() on null C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 586
ERROR - 2023-07-26 19:17:13 --> Severity: Notice --> Undefined variable: CI C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 586
ERROR - 2023-07-26 19:17:13 --> Severity: Notice --> Trying to get property 'session' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 586
ERROR - 2023-07-26 19:17:13 --> Severity: error --> Exception: Call to a member function userdata() on null C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 586
ERROR - 2023-07-26 19:17:14 --> Severity: Notice --> Undefined variable: CI C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 586
ERROR - 2023-07-26 19:17:14 --> Severity: Notice --> Trying to get property 'session' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 586
ERROR - 2023-07-26 19:17:14 --> Severity: error --> Exception: Call to a member function userdata() on null C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 586
ERROR - 2023-07-26 21:00:48 --> Could not find the language line "features"
ERROR - 2023-07-26 21:01:31 --> Could not find the language line "features"
ERROR - 2023-07-26 23:09:39 --> Severity: Notice --> Undefined variable: bid C:\xampp\htdocs\finishizer_erp3.0.5\application\controllers\admin\Spam_filters.php 27
ERROR - 2023-07-26 23:09:39 --> Severity: Notice --> Undefined variable: bid C:\xampp\htdocs\finishizer_erp3.0.5\application\controllers\admin\Spam_filters.php 27
ERROR - 2023-07-26 23:09:39 --> Severity: Notice --> Undefined variable: bid C:\xampp\htdocs\finishizer_erp3.0.5\application\controllers\admin\Spam_filters.php 27
