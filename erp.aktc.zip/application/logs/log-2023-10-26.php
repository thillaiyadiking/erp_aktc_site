<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-26 05:13:31 --> Could not find the language line "features"
ERROR - 2023-10-26 06:54:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblcontacts`
WHERE `active` =0 AND `userid` IN ()
ERROR - 2023-10-26 06:55:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblcontacts`
WHERE `active` =0 AND `userid` IN ()
ERROR - 2023-10-26 06:56:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblcontacts`
WHERE `active` =0 AND `userid` IN ()
ERROR - 2023-10-26 06:56:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblcontacts`
WHERE `active` =0 AND `userid` IN ()
ERROR - 2023-10-26 06:57:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ') AND `last_login` LIKE "2023-10-26%"' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblcontacts`
WHERE `userid` IN () AND `last_login` LIKE "2023-10-26%"
ERROR - 2023-10-26 13:13:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ') AND `last_login` LIKE "2023-10-26%"' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblcontacts`
WHERE `userid` IN () AND `last_login` LIKE "2023-10-26%"
