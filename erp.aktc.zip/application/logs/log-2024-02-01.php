<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-02-01 07:54:10 --> Could not find the language line "Branches"
ERROR - 2024-02-01 07:54:10 --> Could not find the language line "Branches"
ERROR - 2024-02-01 07:54:10 --> Could not find the language line "Branches"
ERROR - 2024-02-01 07:54:11 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-01 07:54:11 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-01 07:54:11 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-01 07:54:11 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-01 07:54:13 --> Could not find the language line "Branches"
ERROR - 2024-02-01 07:54:17 --> Could not find the language line "Branches"
ERROR - 2024-02-01 07:54:17 --> Could not find the language line "Branches"
ERROR - 2024-02-01 07:55:14 --> Could not find the language line "Branches"
ERROR - 2024-02-01 07:55:14 --> Could not find the language line "Branches"
ERROR - 2024-02-01 07:55:15 --> Could not find the language line "Branches"
ERROR - 2024-02-01 07:55:15 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-01 07:55:15 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-01 07:55:15 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-01 07:55:15 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-01 07:55:16 --> Could not find the language line "Branches"
ERROR - 2024-02-01 07:56:18 --> Could not find the language line "Branches"
ERROR - 2024-02-01 07:56:22 --> Could not find the language line "Branches"
ERROR - 2024-02-01 07:56:24 --> Could not find the language line "Branches"
ERROR - 2024-02-01 07:56:24 --> Could not find the language line "Branches"
ERROR - 2024-02-01 07:56:30 --> Could not find the language line "Branches"
ERROR - 2024-02-01 07:56:31 --> Could not find the language line "Branches"
ERROR - 2024-02-01 07:56:32 --> Could not find the language line "Branches"
ERROR - 2024-02-01 07:56:49 --> Could not find the language line "Branches"
ERROR - 2024-02-01 07:56:50 --> Could not find the language line "Branches"
ERROR - 2024-02-01 07:56:53 --> Could not find the language line "Branches"
ERROR - 2024-02-01 07:56:54 --> Could not find the language line "Branches"
ERROR - 2024-02-01 08:01:01 --> Could not find the language line "Branches"
ERROR - 2024-02-01 08:01:01 --> Could not find the language line "Branches"
ERROR - 2024-02-01 08:01:01 --> Could not find the language line "Branches"
ERROR - 2024-02-01 08:01:01 --> Severity: Notice --> Undefined variable: branch_clients C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 22
ERROR - 2024-02-01 08:01:01 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 22
ERROR - 2024-02-01 08:01:01 --> Severity: Notice --> Undefined variable: branch_clients C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 110
ERROR - 2024-02-01 08:01:01 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 110
ERROR - 2024-02-01 08:01:01 --> Severity: Notice --> Undefined variable: branch_clients C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 115
ERROR - 2024-02-01 08:01:01 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 115
ERROR - 2024-02-01 08:01:02 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-01 08:01:02 --> Severity: Notice --> Undefined variable: branch_clients C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 22
ERROR - 2024-02-01 08:01:02 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 22
ERROR - 2024-02-01 08:01:02 --> Severity: Notice --> Undefined variable: branch_clients C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 110
ERROR - 2024-02-01 08:01:02 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 110
ERROR - 2024-02-01 08:01:02 --> Severity: Notice --> Undefined variable: branch_clients C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 115
ERROR - 2024-02-01 08:01:02 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 115
ERROR - 2024-02-01 08:01:02 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-01 08:01:02 --> Severity: Notice --> Undefined variable: branch_clients C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 22
ERROR - 2024-02-01 08:01:02 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 22
ERROR - 2024-02-01 08:01:02 --> Severity: Notice --> Undefined variable: branch_clients C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 110
ERROR - 2024-02-01 08:01:02 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 110
ERROR - 2024-02-01 08:01:02 --> Severity: Notice --> Undefined variable: branch_clients C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 115
ERROR - 2024-02-01 08:01:02 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 115
ERROR - 2024-02-01 08:01:02 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-01 08:01:02 --> Severity: Notice --> Undefined variable: branch_clients C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 22
ERROR - 2024-02-01 08:01:02 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 22
ERROR - 2024-02-01 08:01:02 --> Severity: Notice --> Undefined variable: branch_clients C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 110
ERROR - 2024-02-01 08:01:02 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 110
ERROR - 2024-02-01 08:01:02 --> Severity: Notice --> Undefined variable: branch_clients C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 115
ERROR - 2024-02-01 08:01:02 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 115
ERROR - 2024-02-01 08:01:02 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-01 08:03:52 --> Could not find the language line "Branches"
ERROR - 2024-02-01 08:03:52 --> Could not find the language line "Branches"
ERROR - 2024-02-01 08:03:52 --> Could not find the language line "Branches"
ERROR - 2024-02-01 08:03:52 --> Severity: Notice --> Undefined variable: branch_clients C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 110
ERROR - 2024-02-01 08:03:52 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 110
ERROR - 2024-02-01 08:03:52 --> Severity: Notice --> Undefined variable: branch_clients C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 115
ERROR - 2024-02-01 08:03:52 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 115
ERROR - 2024-02-01 08:03:52 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-01 08:03:52 --> Severity: Notice --> Undefined variable: branch_clients C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 110
ERROR - 2024-02-01 08:03:52 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 110
ERROR - 2024-02-01 08:03:52 --> Severity: Notice --> Undefined variable: branch_clients C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 115
ERROR - 2024-02-01 08:03:52 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 115
ERROR - 2024-02-01 08:03:52 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-01 08:03:52 --> Severity: Notice --> Undefined variable: branch_clients C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 110
ERROR - 2024-02-01 08:03:52 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 110
ERROR - 2024-02-01 08:03:52 --> Severity: Notice --> Undefined variable: branch_clients C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 115
ERROR - 2024-02-01 08:03:52 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 115
ERROR - 2024-02-01 08:03:52 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-01 08:03:52 --> Severity: Notice --> Undefined variable: branch_clients C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 110
ERROR - 2024-02-01 08:03:52 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 110
ERROR - 2024-02-01 08:03:52 --> Severity: Notice --> Undefined variable: branch_clients C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 115
ERROR - 2024-02-01 08:03:52 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 115
ERROR - 2024-02-01 08:03:52 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-01 08:05:49 --> Could not find the language line "Branches"
ERROR - 2024-02-01 08:05:49 --> Could not find the language line "Branches"
ERROR - 2024-02-01 08:05:49 --> Could not find the language line "Branches"
ERROR - 2024-02-01 08:05:49 --> Severity: Notice --> Undefined variable: branch_clients C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 107
ERROR - 2024-02-01 08:05:49 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 107
ERROR - 2024-02-01 08:05:49 --> Severity: Notice --> Undefined variable: branch_clients C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 112
ERROR - 2024-02-01 08:05:49 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 112
ERROR - 2024-02-01 08:05:49 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-01 08:05:49 --> Severity: Notice --> Undefined variable: branch_clients C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 107
ERROR - 2024-02-01 08:05:49 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 107
ERROR - 2024-02-01 08:05:49 --> Severity: Notice --> Undefined variable: branch_clients C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 112
ERROR - 2024-02-01 08:05:49 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 112
ERROR - 2024-02-01 08:05:49 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-01 08:05:49 --> Severity: Notice --> Undefined variable: branch_clients C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 107
ERROR - 2024-02-01 08:05:49 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 107
ERROR - 2024-02-01 08:05:49 --> Severity: Notice --> Undefined variable: branch_clients C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 112
ERROR - 2024-02-01 08:05:49 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 112
ERROR - 2024-02-01 08:05:49 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-01 08:05:49 --> Severity: Notice --> Undefined variable: branch_clients C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 107
ERROR - 2024-02-01 08:05:49 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 107
ERROR - 2024-02-01 08:05:49 --> Severity: Notice --> Undefined variable: branch_clients C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 112
ERROR - 2024-02-01 08:05:49 --> Severity: Warning --> sizeof(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 112
ERROR - 2024-02-01 08:05:49 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-01 08:07:12 --> Could not find the language line "Branches"
ERROR - 2024-02-01 08:07:12 --> Could not find the language line "Branches"
ERROR - 2024-02-01 08:07:12 --> Could not find the language line "Branches"
ERROR - 2024-02-01 08:07:12 --> Severity: Notice --> Undefined variable: _where C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 112
ERROR - 2024-02-01 08:07:12 --> Severity: Notice --> Undefined variable: _where C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 113
ERROR - 2024-02-01 08:07:12 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-01 08:07:12 --> Severity: Notice --> Undefined variable: _where C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 112
ERROR - 2024-02-01 08:07:12 --> Severity: Notice --> Undefined variable: _where C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 113
ERROR - 2024-02-01 08:07:12 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-01 08:07:12 --> Severity: Notice --> Undefined variable: _where C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 112
ERROR - 2024-02-01 08:07:12 --> Severity: Notice --> Undefined variable: _where C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 113
ERROR - 2024-02-01 08:07:12 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-01 08:07:12 --> Severity: Notice --> Undefined variable: _where C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 112
ERROR - 2024-02-01 08:07:12 --> Severity: Notice --> Undefined variable: _where C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 113
ERROR - 2024-02-01 08:07:12 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-01 08:07:56 --> Could not find the language line "Branches"
ERROR - 2024-02-01 08:07:56 --> Could not find the language line "Branches"
ERROR - 2024-02-01 08:07:56 --> Could not find the language line "Branches"
ERROR - 2024-02-01 08:07:56 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-01 08:07:56 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-01 08:07:56 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-01 08:07:56 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-01 08:11:05 --> Could not find the language line "Branches"
ERROR - 2024-02-01 08:11:05 --> Could not find the language line "Branches"
ERROR - 2024-02-01 08:11:05 --> Could not find the language line "Branches"
ERROR - 2024-02-01 08:11:05 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-01 08:11:05 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-01 08:11:05 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-01 08:11:05 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-01 08:11:54 --> Could not find the language line "Branches"
ERROR - 2024-02-01 08:11:54 --> Could not find the language line "Branches"
ERROR - 2024-02-01 08:11:54 --> Could not find the language line "Branches"
ERROR - 2024-02-01 08:11:54 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-01 08:11:54 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-01 08:11:54 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-01 08:11:54 --> Could not find the language line "View Dashboard"
