<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-30 05:17:57 --> Query error: Unknown column 'branch_id' in 'where clause' - Invalid query: DELETE FROM `tblleads_email_integration`
WHERE `branch_id` = '7'
ERROR - 2023-11-30 05:21:29 --> Severity: Warning --> Illegal string offset 'id' C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 154
ERROR - 2023-11-30 05:21:29 --> Severity: Warning --> Illegal string offset 'id' C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 154
ERROR - 2023-11-30 05:21:29 --> Severity: Warning --> Illegal string offset 'id' C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 154
ERROR - 2023-11-30 05:21:29 --> Severity: Warning --> Illegal string offset 'id' C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 154
ERROR - 2023-11-30 05:21:29 --> Severity: Warning --> Illegal string offset 'id' C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 154
ERROR - 2023-11-30 05:21:29 --> Severity: Warning --> Illegal string offset 'id' C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 154
ERROR - 2023-11-30 05:21:30 --> Severity: Warning --> Illegal string offset 'id' C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 154
ERROR - 2023-11-30 05:21:30 --> Severity: Warning --> Illegal string offset 'id' C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 154
ERROR - 2023-11-30 05:21:30 --> Severity: Warning --> Illegal string offset 'id' C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 154
ERROR - 2023-11-30 05:21:30 --> Severity: Warning --> Illegal string offset 'id' C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 154
ERROR - 2023-11-30 05:21:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 154
ERROR - 2023-11-30 05:21:30 --> Severity: Warning --> Illegal string offset 'id' C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 154
ERROR - 2023-11-30 05:21:30 --> Severity: Warning --> Illegal string offset 'id' C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 154
ERROR - 2023-11-30 05:21:30 --> Severity: Warning --> Illegal string offset 'id' C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 154
ERROR - 2023-11-30 05:21:30 --> Severity: Warning --> Illegal string offset 'id' C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 154
ERROR - 2023-11-30 05:21:30 --> Severity: Warning --> Illegal string offset 'id' C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 154
ERROR - 2023-11-30 05:21:30 --> Severity: Warning --> Illegal string offset 'id' C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 154
ERROR - 2023-11-30 05:21:30 --> Severity: Warning --> Illegal string offset 'id' C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 154
ERROR - 2023-11-30 05:21:30 --> Severity: Notice --> Uninitialized string offset: 0 C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 154
ERROR - 2023-11-30 05:21:30 --> Severity: Warning --> Illegal string offset 'id' C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 154
ERROR - 2023-11-30 05:21:30 --> Severity: Notice --> Uninitialized string offset: 0 C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 154
ERROR - 2023-11-30 05:21:30 --> Severity: Warning --> Illegal string offset 'id' C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 154
ERROR - 2023-11-30 05:21:30 --> Severity: Warning --> Illegal string offset 'id' C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 154
ERROR - 2023-11-30 05:21:30 --> Severity: Warning --> Illegal string offset 'id' C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 154
ERROR - 2023-11-30 05:21:30 --> Severity: Warning --> Illegal string offset 'id' C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 154
ERROR - 2023-11-30 05:21:30 --> Severity: Notice --> Uninitialized string offset: 0 C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 154
ERROR - 2023-11-30 05:21:30 --> Severity: Warning --> Illegal string offset 'id' C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 154
ERROR - 2023-11-30 05:21:30 --> Severity: Notice --> Uninitialized string offset: 0 C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 154
ERROR - 2023-11-30 05:21:30 --> Severity: Warning --> Illegal string offset 'id' C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 154
ERROR - 2023-11-30 05:21:30 --> Severity: Warning --> Illegal string offset 'id' C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 154
ERROR - 2023-11-30 05:21:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp-new\htdocs\finishizer_erp3.0.5\system\core\Exceptions.php:271) C:\xampp-new\htdocs\finishizer_erp3.0.5\system\helpers\url_helper.php 564
ERROR - 2023-11-30 05:30:12 --> Could not find the language line "branch_Language"
ERROR - 2023-11-30 05:30:12 --> Could not find the language line "branch_currency"
ERROR - 2023-11-30 05:36:23 --> Could not find the language line "branch_Language"
ERROR - 2023-11-30 05:40:52 --> Could not find the language line "branch"
ERROR - 2023-11-30 05:43:07 --> Could not find the language line "features"
ERROR - 2023-11-30 13:43:57 --> Severity: error --> Exception: Call to undefined method Branches_model::getBranches() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 16
ERROR - 2023-11-30 13:44:42 --> Severity: Notice --> Undefined variable: data C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 26
ERROR - 2023-11-30 13:55:30 --> Severity: Warning --> Illegal string offset 'branch' C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 25
ERROR - 2023-11-30 13:55:30 --> Severity: Notice --> Array to string conversion C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 25
ERROR - 2023-11-30 13:56:19 --> Severity: Warning --> Illegal string offset 'branch' C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 25
ERROR - 2023-11-30 13:56:19 --> Severity: Notice --> Array to string conversion C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 25
ERROR - 2023-11-30 13:56:56 --> Severity: Notice --> Trying to get property 'branch_name' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 12
ERROR - 2023-11-30 13:56:56 --> Severity: Notice --> Trying to get property 'branch_location' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 18
ERROR - 2023-11-30 13:56:56 --> Severity: Notice --> Trying to get property 'branch_language' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 22
ERROR - 2023-11-30 13:56:56 --> Severity: Notice --> Trying to get property 'branch_currency' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 27
ERROR - 2023-11-30 13:57:22 --> Severity: Notice --> Trying to get property 'branch_name' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 12
ERROR - 2023-11-30 13:57:22 --> Severity: Notice --> Trying to get property 'branch_location' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 18
ERROR - 2023-11-30 13:57:22 --> Severity: Notice --> Trying to get property 'branch_language' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 22
ERROR - 2023-11-30 13:57:22 --> Severity: Notice --> Trying to get property 'branch_currency' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 27
ERROR - 2023-11-30 13:58:27 --> Severity: Notice --> Undefined index: branch_name C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 12
ERROR - 2023-11-30 13:58:27 --> Severity: Notice --> Trying to get property 'branch_location' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 18
ERROR - 2023-11-30 13:58:27 --> Severity: Notice --> Trying to get property 'branch_language' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 22
ERROR - 2023-11-30 13:58:27 --> Severity: Notice --> Trying to get property 'branch_currency' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 27
ERROR - 2023-11-30 13:59:15 --> Severity: Notice --> Undefined index: branch_name C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 12
ERROR - 2023-11-30 13:59:15 --> Severity: Notice --> Trying to get property 'branch_location' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 18
ERROR - 2023-11-30 13:59:15 --> Severity: Notice --> Trying to get property 'branch_language' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 22
ERROR - 2023-11-30 13:59:15 --> Severity: Notice --> Trying to get property 'branch_currency' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 27
ERROR - 2023-11-30 14:02:21 --> Severity: Notice --> Undefined offset: 1 C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 12
ERROR - 2023-11-30 14:02:21 --> Severity: Notice --> Trying to get property 'branch_name' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 12
ERROR - 2023-11-30 14:02:21 --> Severity: Notice --> Trying to get property 'branch_location' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 18
ERROR - 2023-11-30 14:02:21 --> Severity: Notice --> Trying to get property 'branch_language' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 22
ERROR - 2023-11-30 14:02:21 --> Severity: Notice --> Trying to get property 'branch_currency' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 27
ERROR - 2023-11-30 14:03:41 --> Severity: Notice --> Undefined offset: 1 C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 12
ERROR - 2023-11-30 14:03:41 --> Severity: Notice --> Trying to get property 'branch_name' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 12
ERROR - 2023-11-30 14:03:41 --> Severity: Notice --> Trying to get property 'branch_location' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 18
ERROR - 2023-11-30 14:03:41 --> Severity: Notice --> Trying to get property 'branch_language' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 22
ERROR - 2023-11-30 14:03:41 --> Severity: Notice --> Trying to get property 'branch_currency' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 27
ERROR - 2023-11-30 14:04:12 --> Severity: Notice --> Trying to get property 'branch_name' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 12
ERROR - 2023-11-30 14:04:12 --> Severity: Notice --> Trying to get property 'branch_location' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 18
ERROR - 2023-11-30 14:04:12 --> Severity: Notice --> Trying to get property 'branch_language' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 22
ERROR - 2023-11-30 14:04:12 --> Severity: Notice --> Trying to get property 'branch_currency' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 27
ERROR - 2023-11-30 14:04:14 --> Severity: Notice --> Trying to get property 'branch_name' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 12
ERROR - 2023-11-30 14:04:14 --> Severity: Notice --> Trying to get property 'branch_location' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 18
ERROR - 2023-11-30 14:04:14 --> Severity: Notice --> Trying to get property 'branch_language' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 22
ERROR - 2023-11-30 14:04:14 --> Severity: Notice --> Trying to get property 'branch_currency' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 27
ERROR - 2023-11-30 14:06:09 --> Severity: Notice --> Trying to get property 'branch_name' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 12
ERROR - 2023-11-30 14:06:09 --> Severity: Notice --> Trying to get property 'branch_location' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 18
ERROR - 2023-11-30 14:06:09 --> Severity: Notice --> Trying to get property 'branch_language' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 22
ERROR - 2023-11-30 14:06:09 --> Severity: Notice --> Trying to get property 'branch_currency' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 27
ERROR - 2023-11-30 14:08:01 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 24
ERROR - 2023-11-30 14:08:01 --> Severity: Notice --> Trying to get property 'branch_name' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 25
ERROR - 2023-11-30 14:08:01 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 26
ERROR - 2023-11-30 14:08:01 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 28
ERROR - 2023-11-30 14:08:01 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 30
ERROR - 2023-11-30 14:08:01 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 24
ERROR - 2023-11-30 14:08:01 --> Severity: Notice --> Trying to get property 'branch_name' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 25
ERROR - 2023-11-30 14:08:01 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 26
ERROR - 2023-11-30 14:08:01 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 28
ERROR - 2023-11-30 14:08:01 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 30
ERROR - 2023-11-30 14:08:01 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 24
ERROR - 2023-11-30 14:08:01 --> Severity: Notice --> Trying to get property 'branch_name' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 25
ERROR - 2023-11-30 14:08:01 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 26
ERROR - 2023-11-30 14:08:01 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 28
ERROR - 2023-11-30 14:08:01 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 30
ERROR - 2023-11-30 14:08:01 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 24
ERROR - 2023-11-30 14:08:01 --> Severity: Notice --> Trying to get property 'branch_name' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 25
ERROR - 2023-11-30 14:08:01 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 26
ERROR - 2023-11-30 14:08:01 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 28
ERROR - 2023-11-30 14:08:01 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 30
ERROR - 2023-11-30 14:08:03 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 24
ERROR - 2023-11-30 14:08:03 --> Severity: Notice --> Trying to get property 'branch_name' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 25
ERROR - 2023-11-30 14:08:03 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 26
ERROR - 2023-11-30 14:08:03 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 28
ERROR - 2023-11-30 14:08:03 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 30
ERROR - 2023-11-30 14:08:03 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 24
ERROR - 2023-11-30 14:08:03 --> Severity: Notice --> Trying to get property 'branch_name' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 25
ERROR - 2023-11-30 14:08:03 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 26
ERROR - 2023-11-30 14:08:03 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 28
ERROR - 2023-11-30 14:08:03 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 30
ERROR - 2023-11-30 14:08:03 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 24
ERROR - 2023-11-30 14:08:03 --> Severity: Notice --> Trying to get property 'branch_name' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 25
ERROR - 2023-11-30 14:08:03 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 26
ERROR - 2023-11-30 14:08:03 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 28
ERROR - 2023-11-30 14:08:03 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 30
ERROR - 2023-11-30 14:08:03 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 24
ERROR - 2023-11-30 14:08:03 --> Severity: Notice --> Trying to get property 'branch_name' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 25
ERROR - 2023-11-30 14:08:03 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 26
ERROR - 2023-11-30 14:08:03 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 28
ERROR - 2023-11-30 14:08:03 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 30
ERROR - 2023-11-30 14:08:25 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 24
ERROR - 2023-11-30 14:08:25 --> Severity: Notice --> Trying to get property 'branch_name' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 25
ERROR - 2023-11-30 14:08:25 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 26
ERROR - 2023-11-30 14:08:25 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 28
ERROR - 2023-11-30 14:08:25 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 30
ERROR - 2023-11-30 14:08:25 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 24
ERROR - 2023-11-30 14:08:25 --> Severity: Notice --> Trying to get property 'branch_name' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 25
ERROR - 2023-11-30 14:08:25 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 26
ERROR - 2023-11-30 14:08:25 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 28
ERROR - 2023-11-30 14:08:25 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 30
ERROR - 2023-11-30 14:08:25 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 24
ERROR - 2023-11-30 14:08:25 --> Severity: Notice --> Trying to get property 'branch_name' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 25
ERROR - 2023-11-30 14:08:25 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 26
ERROR - 2023-11-30 14:08:25 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 28
ERROR - 2023-11-30 14:08:25 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 30
ERROR - 2023-11-30 14:08:25 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 24
ERROR - 2023-11-30 14:08:25 --> Severity: Notice --> Trying to get property 'branch_name' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 25
ERROR - 2023-11-30 14:08:25 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 26
ERROR - 2023-11-30 14:08:25 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 28
ERROR - 2023-11-30 14:08:25 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 30
ERROR - 2023-11-30 14:08:38 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 24
ERROR - 2023-11-30 14:08:38 --> Severity: Notice --> Trying to get property 'branch_name' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 25
ERROR - 2023-11-30 14:08:38 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 26
ERROR - 2023-11-30 14:08:38 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 28
ERROR - 2023-11-30 14:08:38 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 30
ERROR - 2023-11-30 14:08:38 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 24
ERROR - 2023-11-30 14:08:38 --> Severity: Notice --> Trying to get property 'branch_name' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 25
ERROR - 2023-11-30 14:08:38 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 26
ERROR - 2023-11-30 14:08:38 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 28
ERROR - 2023-11-30 14:08:38 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 30
ERROR - 2023-11-30 14:08:38 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 24
ERROR - 2023-11-30 14:08:38 --> Severity: Notice --> Trying to get property 'branch_name' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 25
ERROR - 2023-11-30 14:08:38 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 26
ERROR - 2023-11-30 14:08:38 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 28
ERROR - 2023-11-30 14:08:38 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 30
ERROR - 2023-11-30 14:08:38 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 24
ERROR - 2023-11-30 14:08:38 --> Severity: Notice --> Trying to get property 'branch_name' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 25
ERROR - 2023-11-30 14:08:38 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 26
ERROR - 2023-11-30 14:08:38 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 28
ERROR - 2023-11-30 14:08:38 --> Severity: Notice --> Trying to get property 'branch_id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 30
ERROR - 2023-11-30 14:10:35 --> Severity: Notice --> Trying to get property 'branch_name' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 12
ERROR - 2023-11-30 14:10:35 --> Severity: Notice --> Trying to get property 'branch_location' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 18
ERROR - 2023-11-30 14:10:35 --> Severity: Notice --> Trying to get property 'branch_language' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 22
ERROR - 2023-11-30 14:10:35 --> Severity: Notice --> Trying to get property 'branch_currency' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 27
ERROR - 2023-11-30 14:11:26 --> Severity: Notice --> Trying to get property 'branch_name' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 12
ERROR - 2023-11-30 14:11:26 --> Severity: Notice --> Trying to get property 'branch_location' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 18
ERROR - 2023-11-30 14:11:26 --> Severity: Notice --> Trying to get property 'branch_language' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 22
ERROR - 2023-11-30 14:11:26 --> Severity: Notice --> Trying to get property 'branch_currency' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 27
ERROR - 2023-11-30 14:26:11 --> Severity: Notice --> Trying to get property 'branch_name' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 12
ERROR - 2023-11-30 14:26:11 --> Severity: Notice --> Trying to get property 'branch_location' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 18
ERROR - 2023-11-30 14:26:11 --> Severity: Notice --> Trying to get property 'branch_language' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 22
ERROR - 2023-11-30 14:26:11 --> Severity: Notice --> Trying to get property 'branch_currency' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 27
ERROR - 2023-11-30 14:26:41 --> Severity: Notice --> Undefined index: branch_name C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 12
ERROR - 2023-11-30 14:26:41 --> Severity: Notice --> Trying to get property 'branch_location' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 18
ERROR - 2023-11-30 14:26:41 --> Severity: Notice --> Trying to get property 'branch_language' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 22
ERROR - 2023-11-30 14:26:41 --> Severity: Notice --> Trying to get property 'branch_currency' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 27
ERROR - 2023-11-30 14:28:02 --> Severity: Notice --> Trying to get property 'branch_location' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 18
ERROR - 2023-11-30 14:28:02 --> Severity: Notice --> Trying to get property 'branch_language' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 22
ERROR - 2023-11-30 14:28:02 --> Severity: Notice --> Trying to get property 'branch_currency' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 27
ERROR - 2023-11-30 14:28:36 --> Severity: Notice --> Array to string conversion C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 18
ERROR - 2023-11-30 14:28:36 --> Severity: Notice --> Undefined variable: Array C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 18
ERROR - 2023-11-30 14:28:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 18
ERROR - 2023-11-30 14:28:36 --> Severity: Notice --> Trying to get property 'branch_location' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 18
ERROR - 2023-11-30 14:28:36 --> Severity: Notice --> Array to string conversion C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 22
ERROR - 2023-11-30 14:28:36 --> Severity: Notice --> Undefined variable: Array C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 22
ERROR - 2023-11-30 14:28:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 22
ERROR - 2023-11-30 14:28:36 --> Severity: Notice --> Trying to get property 'branch_language' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 22
ERROR - 2023-11-30 14:28:36 --> Severity: Notice --> Undefined property: stdClass::$branch_currency C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 27
ERROR - 2023-11-30 14:28:38 --> Severity: Notice --> Array to string conversion C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 18
ERROR - 2023-11-30 14:28:38 --> Severity: Notice --> Undefined variable: Array C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 18
ERROR - 2023-11-30 14:28:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 18
ERROR - 2023-11-30 14:28:38 --> Severity: Notice --> Trying to get property 'branch_location' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 18
ERROR - 2023-11-30 14:28:38 --> Severity: Notice --> Array to string conversion C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 22
ERROR - 2023-11-30 14:28:38 --> Severity: Notice --> Undefined variable: Array C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 22
ERROR - 2023-11-30 14:28:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 22
ERROR - 2023-11-30 14:28:38 --> Severity: Notice --> Trying to get property 'branch_language' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 22
ERROR - 2023-11-30 14:28:38 --> Severity: Notice --> Undefined property: stdClass::$branch_currency C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 27
ERROR - 2023-11-30 14:29:05 --> Severity: Notice --> Undefined property: stdClass::$branch_language C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 22
ERROR - 2023-11-30 14:29:05 --> Severity: Notice --> Undefined property: stdClass::$branch_currency C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 27
ERROR - 2023-11-30 14:29:07 --> Severity: Notice --> Undefined property: stdClass::$branch_language C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 22
ERROR - 2023-11-30 14:29:07 --> Severity: Notice --> Undefined property: stdClass::$branch_currency C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 27
ERROR - 2023-11-30 14:29:45 --> Severity: Notice --> Undefined property: stdClass::$branch_language C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 22
ERROR - 2023-11-30 14:29:45 --> Severity: Notice --> Undefined property: stdClass::$branch_currency C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 27
ERROR - 2023-11-30 14:29:48 --> Severity: Notice --> Undefined property: stdClass::$branch_language C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 22
ERROR - 2023-11-30 14:29:48 --> Severity: Notice --> Undefined property: stdClass::$branch_currency C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 27
ERROR - 2023-11-30 14:33:49 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 25
ERROR - 2023-11-30 14:34:24 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 25
ERROR - 2023-11-30 14:34:26 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 25
ERROR - 2023-11-30 14:35:49 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 25
ERROR - 2023-11-30 14:36:29 --> Severity: Notice --> Trying to get property 'branch_name' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 12
ERROR - 2023-11-30 14:36:29 --> Severity: Notice --> Trying to get property 'branch_location' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 18
ERROR - 2023-11-30 14:36:29 --> Severity: Notice --> Trying to get property 'language' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 22
ERROR - 2023-11-30 14:36:29 --> Severity: Notice --> Trying to get property 'currency' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 27
ERROR - 2023-11-30 15:01:42 --> Query error: Unknown column 'branch_language' in 'field list' - Invalid query: INSERT INTO `tblbranches` (`branch_name`, `branch_location`, `branch_language`, `branch_currency`) VALUES ('branch5', 'test', 'test', 'test')
ERROR - 2023-11-30 15:03:08 --> Could not find the language line "branch"
ERROR - 2023-11-30 15:11:16 --> Could not find the language line "branch"
ERROR - 2023-11-30 15:11:55 --> Severity: Notice --> Undefined variable: id C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 246
ERROR - 2023-11-30 15:12:27 --> Severity: Notice --> Undefined variable: id C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 244
ERROR - 2023-11-30 15:14:14 --> Severity: Notice --> Undefined variable: id C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Branches.php 244
ERROR - 2023-11-30 15:52:13 --> Could not find the language line "branch"
ERROR - 2023-11-30 16:04:37 --> Could not find the language line "Branch"
