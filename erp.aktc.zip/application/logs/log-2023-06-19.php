<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-19 10:13:45 --> Query error: Table 'finishizer_erp.tblsessions' doesn't exist - Invalid query: SELECT `data`
FROM `tblsessions`
WHERE `id` = 'tni22nchiuvqesoro1pf79qmrja6g94k'
ERROR - 2023-06-19 10:13:45 --> Severity: Warning --> session_write_close(): Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2023-06-19 10:13:45 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: C:\xampp\tmp) Unknown 0
ERROR - 2023-06-19 11:09:44 --> Query error: Table 'finishizer_erp.tbloptions' doesn't exist - Invalid query: SHOW COLUMNS FROM `tbloptions`
ERROR - 2023-06-19 11:36:03 --> Not Found: /index
ERROR - 2023-06-19 11:36:12 --> Not Found: /index
ERROR - 2023-06-19 11:36:26 --> Not Found: Migration/101_version_101.php
ERROR - 2023-06-19 11:36:38 --> Not Found: /index
ERROR - 2023-06-19 11:36:54 --> Not Found: Migration/101_version_101
ERROR - 2023-06-19 11:37:13 --> Not Found: /index
ERROR - 2023-06-19 11:37:21 --> Not Found: Migration/101
ERROR - 2023-06-19 11:38:34 --> Not Found: /index
ERROR - 2023-06-19 11:46:10 --> Not Found: /index
ERROR - 2023-06-19 11:46:35 --> Not Found: Migration/version
ERROR - 2023-06-19 11:46:59 --> Query error: Table 'finishizer_erp.tbloptions' doesn't exist - Invalid query: SHOW COLUMNS FROM `tbloptions`
ERROR - 2023-06-19 11:56:04 --> Not Found: /index
ERROR - 2023-06-19 11:56:15 --> Not Found: Migration/index
ERROR - 2023-06-19 11:57:48 --> Not Found: /index
ERROR - 2023-06-19 11:58:05 --> Not Found: Migration/index
ERROR - 2023-06-19 20:15:18 --> Not Found: Migration/index
ERROR - 2023-06-19 20:21:48 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\finishizer_erp3.0.5\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2023-06-19 20:21:48 --> Unable to connect to the database
ERROR - 2023-06-19 20:27:32 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\finishizer_erp3.0.5\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2023-06-19 20:27:32 --> Unable to connect to the database
ERROR - 2023-06-19 20:33:55 --> Not Found: /index
ERROR - 2023-06-19 20:34:01 --> Not Found: /index
ERROR - 2023-06-19 20:34:12 --> Query error: Table 'finishizer_erp.tbloptions' doesn't exist - Invalid query: SHOW COLUMNS FROM `tbloptions`
ERROR - 2023-06-19 20:38:55 --> Query error: Table 'finishizer_erp.tbloptions' doesn't exist - Invalid query: SHOW COLUMNS FROM `tbloptions`
ERROR - 2023-06-19 20:40:24 --> Query error: Table 'finishizer_erp.tbloptions' doesn't exist - Invalid query: SHOW COLUMNS FROM `tbloptions`
ERROR - 2023-06-19 21:13:37 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `tbloptions` (`name`, `value`, `autoload`) VALUES ('sms_clickatell_active', 0, 1)
ERROR - 2023-06-19 21:16:24 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `tbloptions` (`name`, `value`, `autoload`) VALUES ('sms_clickatell_active', 0, 1)
ERROR - 2023-06-19 21:32:17 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `tbloptions` (`name`, `value`, `autoload`) VALUES ('sms_clickatell_active', 0, 1)
ERROR - 2023-06-19 21:33:37 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `tbloptions` (`name`, `value`, `autoload`) VALUES ('sms_clickatell_active', 0, 1)
ERROR - 2023-06-19 21:33:56 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `tbloptions` (`name`, `value`, `autoload`) VALUES ('sms_clickatell_active', 0, 1)
