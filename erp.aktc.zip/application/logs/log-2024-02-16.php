<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-02-16 00:29:35 --> Could not find the language line "E-Sign"
ERROR - 2024-02-16 00:29:35 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-16 00:29:35 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-16 00:29:35 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-16 00:29:35 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-16 00:29:35 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-16 00:59:44 --> Could not find the language line "E-Sign"
ERROR - 2024-02-16 00:59:44 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-16 00:59:44 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-16 00:59:44 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-16 00:59:44 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-16 00:59:44 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-16 08:46:28 --> Could not find the language line "E-Sign"
ERROR - 2024-02-16 08:46:28 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-16 08:46:28 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-16 08:46:28 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-16 08:46:28 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-16 08:46:28 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-16 08:56:05 --> Could not find the language line "E-Sign"
ERROR - 2024-02-16 08:56:07 --> Could not find the language line "E-Sign"
ERROR - 2024-02-16 08:56:07 --> Could not find the language line "E-Sign"
ERROR - 2024-02-16 09:13:39 --> Could not find the language line "E-Sign"
ERROR - 2024-02-16 09:13:43 --> Could not find the language line "E-Sign"
ERROR - 2024-02-16 09:13:43 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-16 09:13:43 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-16 09:13:43 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-16 09:13:43 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-16 09:13:43 --> Could not find the language line "View Dashboard"
ERROR - 2024-02-16 09:13:45 --> Could not find the language line "E-Sign"
ERROR - 2024-02-16 09:13:47 --> Could not find the language line "E-Sign"
ERROR - 2024-02-16 09:13:47 --> Could not find the language line "E-Sign"
ERROR - 2024-02-16 09:13:49 --> Could not find the language line "E-Sign"
ERROR - 2024-02-16 09:13:50 --> Could not find the language line "E-Sign"
ERROR - 2024-02-16 09:13:50 --> Could not find the language line "E-Sign"
ERROR - 2024-02-16 09:13:52 --> Could not find the language line "E-Sign"
ERROR - 2024-02-16 09:25:22 --> Could not find the language line "E-Sign"
ERROR - 2024-02-16 09:31:11 --> Could not find the language line "E-Sign"
ERROR - 2024-02-16 17:32:06 --> Severity: Notice --> Undefined variable: stripe_tax_rates /home/cgarabsc/erp.elegance77.com/application/views/admin/subscriptions/form.php 154
ERROR - 2024-02-16 17:32:06 --> Severity: Notice --> Trying to get property 'data' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/subscriptions/form.php 154
ERROR - 2024-02-16 17:32:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/cgarabsc/erp.elegance77.com/application/views/admin/subscriptions/form.php 154
ERROR - 2024-02-16 17:32:06 --> Severity: Notice --> Undefined variable: stripe_tax_rates /home/cgarabsc/erp.elegance77.com/application/views/admin/subscriptions/form.php 186
ERROR - 2024-02-16 17:32:06 --> Severity: Notice --> Trying to get property 'data' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/subscriptions/form.php 186
ERROR - 2024-02-16 17:32:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/cgarabsc/erp.elegance77.com/application/views/admin/subscriptions/form.php 186
ERROR - 2024-02-16 17:32:13 --> Severity: Notice --> Undefined variable: stripe_tax_rates /home/cgarabsc/erp.elegance77.com/application/views/admin/subscriptions/form.php 154
ERROR - 2024-02-16 17:32:13 --> Severity: Notice --> Trying to get property 'data' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/subscriptions/form.php 154
ERROR - 2024-02-16 17:32:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/cgarabsc/erp.elegance77.com/application/views/admin/subscriptions/form.php 154
ERROR - 2024-02-16 17:32:13 --> Severity: Notice --> Undefined variable: stripe_tax_rates /home/cgarabsc/erp.elegance77.com/application/views/admin/subscriptions/form.php 186
ERROR - 2024-02-16 17:32:13 --> Severity: Notice --> Trying to get property 'data' of non-object /home/cgarabsc/erp.elegance77.com/application/views/admin/subscriptions/form.php 186
ERROR - 2024-02-16 17:32:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/cgarabsc/erp.elegance77.com/application/views/admin/subscriptions/form.php 186
