<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-12 05:24:30 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 26
ERROR - 2023-10-12 05:24:31 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 26
ERROR - 2023-10-12 05:24:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblestimates`
WHERE `clientid` IN (SELECT userid FROM tblclients WHERE branch_id=)
ERROR - 2023-10-12 05:24:41 --> Severity: Notice --> Undefined variable: CI C:\xampp\htdocs\finishizer_erp3.0.5\application\models\Invoices_model.php 244
ERROR - 2023-10-12 05:24:41 --> Severity: Notice --> Trying to get property 'load' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\models\Invoices_model.php 244
ERROR - 2023-10-12 05:24:41 --> Severity: error --> Exception: Call to a member function model() on null C:\xampp\htdocs\finishizer_erp3.0.5\application\models\Invoices_model.php 244
ERROR - 2023-10-12 05:25:00 --> Severity: Notice --> Undefined variable: CI C:\xampp\htdocs\finishizer_erp3.0.5\application\models\Invoices_model.php 244
ERROR - 2023-10-12 05:25:00 --> Severity: Notice --> Trying to get property 'load' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\models\Invoices_model.php 244
ERROR - 2023-10-12 05:25:00 --> Severity: error --> Exception: Call to a member function model() on null C:\xampp\htdocs\finishizer_erp3.0.5\application\models\Invoices_model.php 244
ERROR - 2023-10-12 05:25:47 --> Severity: Notice --> Undefined variable: CI C:\xampp\htdocs\finishizer_erp3.0.5\application\models\Invoices_model.php 244
ERROR - 2023-10-12 05:25:47 --> Severity: Notice --> Trying to get property 'load' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\models\Invoices_model.php 244
ERROR - 2023-10-12 05:25:47 --> Severity: error --> Exception: Call to a member function model() on null C:\xampp\htdocs\finishizer_erp3.0.5\application\models\Invoices_model.php 244
ERROR - 2023-10-12 05:27:13 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 26
ERROR - 2023-10-12 05:27:13 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 26
ERROR - 2023-10-12 05:27:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblestimates`
WHERE `clientid` IN (SELECT userid FROM tblclients WHERE branch_id=)
ERROR - 2023-10-12 05:29:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblestimates`
WHERE `clientid` IN (SELECT userid FROM tblclients WHERE branch_id=)
ERROR - 2023-10-12 07:52:37 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 26
ERROR - 2023-10-12 07:52:37 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 26
ERROR - 2023-10-12 07:52:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblestimates`
WHERE `clientid` IN (SELECT userid FROM tblclients WHERE branch_id=)
