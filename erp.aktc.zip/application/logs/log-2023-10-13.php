<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-13 06:15:03 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 26
ERROR - 2023-10-13 06:15:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 26
ERROR - 2023-10-13 06:15:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblestimates`
WHERE `clientid` IN (SELECT userid FROM tblclients WHERE branch_id=)
ERROR - 2023-10-13 06:15:48 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 26
ERROR - 2023-10-13 06:15:48 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 26
ERROR - 2023-10-13 06:15:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblestimates`
WHERE `clientid` IN (SELECT userid FROM tblclients WHERE branch_id=)
ERROR - 2023-10-13 06:18:52 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 26
ERROR - 2023-10-13 06:18:54 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 26
ERROR - 2023-10-13 06:18:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblestimates`
WHERE `clientid` IN (SELECT userid FROM tblclients WHERE branch_id=)
ERROR - 2023-10-13 06:34:21 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 26
ERROR - 2023-10-13 06:34:21 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 26
ERROR - 2023-10-13 06:34:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblestimates`
WHERE `clientid` IN (SELECT userid FROM tblclients WHERE branch_id=)
ERROR - 2023-10-13 06:36:05 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 26
ERROR - 2023-10-13 06:36:05 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 26
ERROR - 2023-10-13 06:36:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblestimates`
WHERE `clientid` IN (SELECT userid FROM tblclients WHERE branch_id=)
ERROR - 2023-10-13 06:36:07 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 26
ERROR - 2023-10-13 06:36:07 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 26
ERROR - 2023-10-13 06:36:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblestimates`
WHERE `clientid` IN (SELECT userid FROM tblclients WHERE branch_id=)
ERROR - 2023-10-13 06:36:17 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 26
ERROR - 2023-10-13 06:36:17 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 26
ERROR - 2023-10-13 06:36:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblestimates`
WHERE `clientid` IN (SELECT userid FROM tblclients WHERE branch_id=)
ERROR - 2023-10-13 06:36:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 26
ERROR - 2023-10-13 06:36:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 26
ERROR - 2023-10-13 06:36:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblestimates`
WHERE `clientid` IN (SELECT userid FROM tblclients WHERE branch_id=)
ERROR - 2023-10-13 06:39:09 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 26
ERROR - 2023-10-13 06:39:09 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 26
ERROR - 2023-10-13 06:39:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblestimates`
WHERE `clientid` IN (SELECT userid FROM tblclients WHERE branch_id=)
ERROR - 2023-10-13 06:39:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 26
ERROR - 2023-10-13 06:39:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 26
ERROR - 2023-10-13 06:39:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblestimates`
WHERE `clientid` IN (SELECT userid FROM tblclients WHERE branch_id=)
ERROR - 2023-10-13 06:39:59 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 26
ERROR - 2023-10-13 06:39:59 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 26
ERROR - 2023-10-13 06:39:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblestimates`
WHERE `clientid` IN (SELECT userid FROM tblclients WHERE branch_id=)
ERROR - 2023-10-13 06:40:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 26
ERROR - 2023-10-13 06:40:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 26
ERROR - 2023-10-13 06:40:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblestimates`
WHERE `clientid` IN (SELECT userid FROM tblclients WHERE branch_id=)
ERROR - 2023-10-13 06:41:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 26
ERROR - 2023-10-13 06:41:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 26
ERROR - 2023-10-13 06:41:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblestimates`
WHERE `clientid` IN (SELECT userid FROM tblclients WHERE branch_id=)
ERROR - 2023-10-13 06:42:16 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 26
ERROR - 2023-10-13 06:42:16 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 26
ERROR - 2023-10-13 06:42:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblestimates`
WHERE `clientid` IN (SELECT userid FROM tblclients WHERE branch_id=)
ERROR - 2023-10-13 06:44:25 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 26
ERROR - 2023-10-13 06:44:25 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 26
ERROR - 2023-10-13 06:44:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblestimates`
WHERE `clientid` IN (SELECT userid FROM tblclients WHERE branch_id=)
ERROR - 2023-10-13 06:52:18 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 26
ERROR - 2023-10-13 06:52:18 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 26
ERROR - 2023-10-13 06:52:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblestimates`
WHERE `clientid` IN (SELECT userid FROM tblclients WHERE branch_id=)
