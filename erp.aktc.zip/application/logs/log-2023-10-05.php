<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-05 05:02:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblestimates`
WHERE `clientid` IN (SELECT userid FROM tblclients WHERE branch_id=)
ERROR - 2023-10-05 05:10:36 --> Query error: Unknown column 'branch_id' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tbltemplates`
WHERE `type` = 'contracts'
AND `branch_id` = '1'
ERROR - 2023-10-05 05:10:49 --> Query error: Unknown column 'branch_id' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tbltemplates`
WHERE `type` = 'contracts'
AND `branch_id` = '1'
ERROR - 2023-10-05 05:11:16 --> Query error: Unknown column 'branch_id' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tbltemplates`
WHERE `type` = 'contracts'
AND `branch_id` = '1'
ERROR - 2023-10-05 05:11:58 --> Query error: Unknown column 'branch_id' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tbltemplates`
WHERE `type` = 'contracts'
AND `branch_id` = '1'
ERROR - 2023-10-05 05:12:16 --> Query error: Unknown column 'branch_id' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tbltemplates`
WHERE `type` = 'contracts'
AND `branch_id` = '1'
ERROR - 2023-10-05 05:14:06 --> Query error: Unknown column 'branch_id' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tbltemplates`
WHERE `type` = 'contracts'
AND `branch_id` = '1'
ERROR - 2023-10-05 05:18:47 --> Query error: Unknown column 'branch_id' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tbltemplates`
WHERE `type` = 'contracts'
AND `branch_id` = '1'
ERROR - 2023-10-05 05:23:39 --> Query error: Unknown column 'branch_id' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tbltemplates`
WHERE `type` = 'contracts'
AND `branch_id` = '1'
ERROR - 2023-10-05 05:42:01 --> Query error: Unknown column 'branch_id' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tbltemplates`
WHERE `type` = 'contracts'
AND `branch_id` = '1'
ERROR - 2023-10-05 05:42:33 --> Query error: Unknown column 'branch_id' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tbltemplates`
WHERE `type` = 'contracts'
AND `branch_id` = '1'
ERROR - 2023-10-05 05:53:01 --> Query error: Unknown column 'branch_id' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tbltemplates`
WHERE `type` = 'contracts'
AND `branch_id` = '1'
ERROR - 2023-10-05 05:57:59 --> Query error: Unknown column 'branch_id' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tbltemplates`
WHERE `type` = 'contracts'
AND `branch_id` = '1'
ERROR - 2023-10-05 06:02:26 --> Query error: Unknown column 'branch_id' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tbltemplates`
WHERE `type` = 'contracts'
AND `branch_id` = '1'
ERROR - 2023-10-05 06:03:59 --> Query error: Unknown column 'branch_id' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tbltemplates`
WHERE `type` = 'contracts'
AND `branch_id` = '1'
ERROR - 2023-10-05 15:02:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblestimates`
WHERE `clientid` IN (SELECT userid FROM tblclients WHERE branch_id=)
ERROR - 2023-10-05 15:04:36 --> Query error: Unknown column 'branch_id' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tbltemplates`
WHERE `type` = 'contracts'
AND `branch_id` = '1'
ERROR - 2023-10-05 15:05:32 --> Query error: Unknown column 'branch_id' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tbltemplates`
WHERE `type` = 'contracts'
AND `branch_id` = '1'
ERROR - 2023-10-05 15:15:33 --> Query error: Unknown column 'branch_id' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tbltemplates`
WHERE `type` = 'contracts'
AND `branch_id` = '1'
ERROR - 2023-10-05 15:16:35 --> Query error: Unknown column 'branch_id' in 'where clause' - Invalid query: SELECT *
FROM `tbltemplates`
WHERE `type` = 'contracts'
AND `branch_id` = '1'
ORDER BY `name` ASC
ERROR - 2023-10-05 15:24:07 --> Query error: Unknown column 'branch_id' in 'where clause' - Invalid query: SELECT *
FROM `tbltemplates`
WHERE `type` = 'contracts'
AND `branch_id` = '1'
ORDER BY `name` ASC
ERROR - 2023-10-05 15:24:21 --> Query error: Unknown column 'branch_id' in 'field list' - Invalid query: INSERT INTO `tbltemplates` (`name`, `branch_id`, `content`, `addedfrom`, `type`) VALUES ('br1_contract_title', '1', '', '1', 'contracts')
