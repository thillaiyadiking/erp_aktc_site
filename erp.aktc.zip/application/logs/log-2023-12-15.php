<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-12-15 04:10:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp-new\htdocs\finishizer_erp3.0.5\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2023-12-15 04:10:25 --> Unable to connect to the database
ERROR - 2023-12-15 04:28:44 --> Could not find the language line "branches"
ERROR - 2023-12-15 04:28:44 --> Could not find the language line "new_branch"
ERROR - 2023-12-15 04:30:47 --> Could not find the language line "branches"
ERROR - 2023-12-15 04:30:47 --> Could not find the language line "new_branch"
ERROR - 2023-12-15 04:30:47 --> Could not find the language line "Edit"
ERROR - 2023-12-15 04:30:47 --> Could not find the language line "Edit"
ERROR - 2023-12-15 04:30:47 --> Could not find the language line "Edit"
ERROR - 2023-12-15 04:31:00 --> Could not find the language line "branches"
ERROR - 2023-12-15 04:31:00 --> Could not find the language line "new_branch"
ERROR - 2023-12-15 04:32:38 --> Could not find the language line "branches"
ERROR - 2023-12-15 04:32:38 --> Could not find the language line "new_branch"
ERROR - 2023-12-15 06:30:39 --> Could not find the language line "branches"
ERROR - 2023-12-15 06:30:40 --> Could not find the language line "new_branch"
ERROR - 2023-12-15 06:32:15 --> Could not find the language line "branches"
ERROR - 2023-12-15 06:33:26 --> Could not find the language line "branches"
ERROR - 2023-12-15 06:34:18 --> Could not find the language line "branches"
ERROR - 2023-12-15 06:34:24 --> Could not find the language line "branches"
ERROR - 2023-12-15 06:34:24 --> Severity: Notice --> Undefined variable: currencies C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 24
ERROR - 2023-12-15 06:34:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 334
ERROR - 2023-12-15 06:36:31 --> Could not find the language line "branches"
ERROR - 2023-12-15 06:36:31 --> Severity: Notice --> Undefined variable: currencies C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 24
ERROR - 2023-12-15 06:36:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 334
ERROR - 2023-12-15 06:36:44 --> Could not find the language line "branches"
ERROR - 2023-12-15 06:36:44 --> Severity: Notice --> Undefined variable: currencies C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 24
ERROR - 2023-12-15 06:36:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 334
ERROR - 2023-12-15 06:36:47 --> Could not find the language line "branches"
ERROR - 2023-12-15 06:37:18 --> Could not find the language line "branches"
ERROR - 2023-12-15 06:37:20 --> Could not find the language line "branches"
ERROR - 2023-12-15 06:37:20 --> Could not find the language line "branches"
ERROR - 2023-12-15 06:37:22 --> Could not find the language line "branches"
ERROR - 2023-12-15 06:37:23 --> Could not find the language line "subscription_last_sent"
ERROR - 2023-12-15 06:37:23 --> Could not find the language line "branches"
ERROR - 2023-12-15 06:37:28 --> Could not find the language line "branches"
ERROR - 2023-12-15 06:37:29 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\libraries\App.php 283
ERROR - 2023-12-15 06:37:29 --> Could not find the language line "branches"
ERROR - 2023-12-15 06:39:42 --> Could not find the language line "branches"
ERROR - 2023-12-15 06:40:03 --> Could not find the language line "branches"
ERROR - 2023-12-15 06:40:10 --> Could not find the language line "Branches"
ERROR - 2023-12-15 06:40:10 --> Could not find the language line "View Dashboard"
ERROR - 2023-12-15 06:40:10 --> Could not find the language line "View Dashboard"
ERROR - 2023-12-15 06:40:10 --> Could not find the language line "View Dashboard"
ERROR - 2023-12-15 06:40:51 --> Could not find the language line "Branches"
ERROR - 2023-12-15 06:40:51 --> Could not find the language line "View Dashboard"
ERROR - 2023-12-15 06:40:51 --> Could not find the language line "View Dashboard"
ERROR - 2023-12-15 06:40:51 --> Could not find the language line "View Dashboard"
ERROR - 2023-12-15 06:43:39 --> Could not find the language line "branches"
ERROR - 2023-12-15 06:43:45 --> Could not find the language line "branches"
ERROR - 2023-12-15 06:43:47 --> Could not find the language line "branches"
ERROR - 2023-12-15 06:43:47 --> Could not find the language line "branches"
ERROR - 2023-12-15 06:43:51 --> Could not find the language line "branches"
ERROR - 2023-12-15 06:43:59 --> Could not find the language line "branches"
ERROR - 2023-12-15 06:43:59 --> Could not find the language line "branches"
ERROR - 2023-12-15 06:44:03 --> Could not find the language line "branches"
ERROR - 2023-12-15 06:44:03 --> Could not find the language line "subscription_last_sent"
ERROR - 2023-12-15 06:44:03 --> Could not find the language line "branches"
ERROR - 2023-12-15 06:45:14 --> Could not find the language line "subscription_last_sent"
