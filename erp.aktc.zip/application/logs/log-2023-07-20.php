<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-20 00:27:37 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `tbloptions` (`name`, `value`, `autoload`) VALUES ('auto_backup_every', '7', 1)
ERROR - 2023-07-20 00:43:23 --> Could not find the language line "branch"
ERROR - 2023-07-20 00:44:29 --> Could not find the language line "features"
ERROR - 2023-07-20 00:45:12 --> Could not find the language line "features"
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 39
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 39
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 39
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 39
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 39
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 39
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 39
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 39
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 39
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 39
ERROR - 2023-07-20 00:45:12 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 39
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 39
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 39
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 39
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 39
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 39
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 39
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 39
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 39
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 39
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'roleid' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\views\admin\staff\permissions.php 45
ERROR - 2023-07-20 00:45:13 --> Severity: Notice --> Trying to get property 'permissions' of non-object C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 181
ERROR - 2023-07-20 00:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\finishizer_erp3.0.5\application\helpers\admin_helper.php 183
ERROR - 2023-07-20 00:45:21 --> Could not find the language line "features"
ERROR - 2023-07-20 17:37:24 --> 404 Page Not Found: Migration/index
ERROR - 2023-07-20 17:38:10 --> Not Found: /index
