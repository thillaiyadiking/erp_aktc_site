<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-12-07 05:31:38 --> Severity: Notice --> Undefined variable: currencies C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 24
ERROR - 2023-12-07 05:31:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 334
ERROR - 2023-12-07 05:32:17 --> Severity: Notice --> Undefined variable: currencies C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 24
ERROR - 2023-12-07 05:32:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 334
ERROR - 2023-12-07 05:32:56 --> Severity: Notice --> Undefined variable: currencies C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 24
ERROR - 2023-12-07 05:32:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 334
ERROR - 2023-12-07 05:33:52 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\models\Currencies_model.php 23
ERROR - 2023-12-07 05:33:52 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 05:33:52 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 05:33:52 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 05:33:52 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 05:33:59 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 05:33:59 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 05:33:59 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 05:33:59 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 05:33:59 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 05:33:59 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 05:33:59 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 05:33:59 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 05:34:28 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\models\Currencies_model.php 23
ERROR - 2023-12-07 05:34:28 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 05:34:28 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 05:34:28 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 05:34:28 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 05:34:31 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\libraries\App.php 283
ERROR - 2023-12-07 05:36:59 --> Severity: Notice --> Undefined variable: currencies C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 24
ERROR - 2023-12-07 05:36:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 334
ERROR - 2023-12-07 05:37:56 --> Severity: Notice --> Undefined variable: currencies C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\branch.php 24
ERROR - 2023-12-07 05:37:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\fields_helper.php 334
ERROR - 2023-12-07 06:33:13 --> 404 Page Not Found: admin/Branches/1
ERROR - 2023-12-07 06:39:17 --> Severity: Notice --> Undefined variable: item C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 17
ERROR - 2023-12-07 06:39:17 --> Severity: Notice --> Trying to get property 'branch_name' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 17
ERROR - 2023-12-07 06:39:17 --> Severity: Notice --> Undefined variable: item C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 17
ERROR - 2023-12-07 06:39:17 --> Severity: Notice --> Trying to get property 'branch_name' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 17
ERROR - 2023-12-07 06:39:17 --> Severity: Notice --> Undefined variable: item C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 17
ERROR - 2023-12-07 06:39:17 --> Severity: Notice --> Trying to get property 'branch_name' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 17
ERROR - 2023-12-07 06:39:17 --> Severity: Notice --> Undefined variable: item C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 17
ERROR - 2023-12-07 06:39:17 --> Severity: Notice --> Trying to get property 'branch_name' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\branches\manage.php 17
ERROR - 2023-12-07 06:45:49 --> Severity: Warning --> array_splice() expects parameter 1 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 183
ERROR - 2023-12-07 06:45:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 184
ERROR - 2023-12-07 06:45:49 --> Severity: Notice --> Undefined variable: proposal_statuses C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 230
ERROR - 2023-12-07 06:45:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 230
ERROR - 2023-12-07 06:45:49 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\models\Invoices_model.php 232
ERROR - 2023-12-07 06:45:49 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 06:45:49 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 06:45:49 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 06:45:49 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 06:45:49 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 06:45:49 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 06:45:49 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 06:45:49 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 06:45:49 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 06:45:49 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 06:45:49 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 06:45:49 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 06:45:49 --> Severity: Notice --> Undefined variable: total_undismissed_announcements C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\user_data.php 54
ERROR - 2023-12-07 06:45:49 --> Severity: Notice --> Undefined variable: activity_log C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\user_data.php 148
ERROR - 2023-12-07 06:45:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\user_data.php 148
ERROR - 2023-12-07 06:45:49 --> Severity: Notice --> Undefined variable: upcoming_events C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 2
ERROR - 2023-12-07 06:45:49 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 2
ERROR - 2023-12-07 06:45:49 --> Severity: Notice --> Undefined variable: upcoming_events C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 5
ERROR - 2023-12-07 06:45:49 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 5
ERROR - 2023-12-07 06:45:49 --> Severity: Notice --> Undefined variable: todos C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 30
ERROR - 2023-12-07 06:45:49 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 30
ERROR - 2023-12-07 06:45:49 --> Severity: Notice --> Undefined variable: todos C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 36
ERROR - 2023-12-07 06:45:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 36
ERROR - 2023-12-07 06:45:49 --> Severity: Notice --> Undefined variable: todos_finished C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 72
ERROR - 2023-12-07 06:45:49 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 72
ERROR - 2023-12-07 06:45:49 --> Severity: Notice --> Undefined variable: todos_finished C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 78
ERROR - 2023-12-07 06:45:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 78
ERROR - 2023-12-07 06:45:49 --> Severity: Notice --> Undefined variable: tickets_reply_by_status_no_json C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:45:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:45:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:45:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:45:49 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:45:49 --> Severity: Notice --> Undefined variable: tickets_awaiting_reply_by_department_no_json C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:45:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:45:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:45:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:45:49 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:45:49 --> Severity: Notice --> Undefined variable: projects_activity C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 2
ERROR - 2023-12-07 06:45:49 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 2
ERROR - 2023-12-07 06:45:49 --> Severity: Notice --> Undefined variable: projects_activity C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 26
ERROR - 2023-12-07 06:45:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 26
ERROR - 2023-12-07 06:45:49 --> Severity: Notice --> Undefined variable: tickets_report C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_report_table.php 17
ERROR - 2023-12-07 06:45:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_report_table.php 17
ERROR - 2023-12-07 06:46:41 --> Severity: Warning --> array_splice() expects parameter 1 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 183
ERROR - 2023-12-07 06:46:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 184
ERROR - 2023-12-07 06:46:41 --> Severity: Notice --> Undefined variable: proposal_statuses C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 230
ERROR - 2023-12-07 06:46:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 230
ERROR - 2023-12-07 06:46:41 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\models\Invoices_model.php 232
ERROR - 2023-12-07 06:46:41 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 06:46:41 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 06:46:41 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 06:46:41 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 06:46:41 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 06:46:41 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 06:46:41 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 06:46:41 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 06:46:41 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 06:46:41 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 06:46:41 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 06:46:41 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 06:46:41 --> Severity: Notice --> Undefined variable: total_undismissed_announcements C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\user_data.php 54
ERROR - 2023-12-07 06:46:41 --> Severity: Notice --> Undefined variable: activity_log C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\user_data.php 148
ERROR - 2023-12-07 06:46:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\user_data.php 148
ERROR - 2023-12-07 06:46:41 --> Severity: Notice --> Undefined variable: upcoming_events C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 2
ERROR - 2023-12-07 06:46:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 2
ERROR - 2023-12-07 06:46:41 --> Severity: Notice --> Undefined variable: upcoming_events C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 5
ERROR - 2023-12-07 06:46:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 5
ERROR - 2023-12-07 06:46:41 --> Severity: Notice --> Undefined variable: todos C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 30
ERROR - 2023-12-07 06:46:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 30
ERROR - 2023-12-07 06:46:41 --> Severity: Notice --> Undefined variable: todos C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 36
ERROR - 2023-12-07 06:46:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 36
ERROR - 2023-12-07 06:46:41 --> Severity: Notice --> Undefined variable: todos_finished C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 72
ERROR - 2023-12-07 06:46:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 72
ERROR - 2023-12-07 06:46:41 --> Severity: Notice --> Undefined variable: todos_finished C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 78
ERROR - 2023-12-07 06:46:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 78
ERROR - 2023-12-07 06:46:41 --> Severity: Notice --> Undefined variable: tickets_reply_by_status_no_json C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:46:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:46:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:46:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:46:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:46:41 --> Severity: Notice --> Undefined variable: tickets_awaiting_reply_by_department_no_json C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:46:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:46:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:46:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:46:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:46:41 --> Severity: Notice --> Undefined variable: projects_activity C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 2
ERROR - 2023-12-07 06:46:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 2
ERROR - 2023-12-07 06:46:41 --> Severity: Notice --> Undefined variable: projects_activity C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 26
ERROR - 2023-12-07 06:46:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 26
ERROR - 2023-12-07 06:46:41 --> Severity: Notice --> Undefined variable: tickets_report C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_report_table.php 17
ERROR - 2023-12-07 06:46:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_report_table.php 17
ERROR - 2023-12-07 06:47:16 --> Severity: Warning --> array_splice() expects parameter 1 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 183
ERROR - 2023-12-07 06:47:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 184
ERROR - 2023-12-07 06:47:16 --> Severity: Notice --> Undefined variable: proposal_statuses C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 230
ERROR - 2023-12-07 06:47:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 230
ERROR - 2023-12-07 06:47:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\models\Invoices_model.php 232
ERROR - 2023-12-07 06:47:16 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 06:47:16 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 06:47:16 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 06:47:16 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 06:47:16 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 06:47:16 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 06:47:16 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 06:47:16 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 06:47:16 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 06:47:16 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 06:47:16 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 06:47:16 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 06:47:16 --> Severity: Notice --> Undefined variable: total_undismissed_announcements C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\user_data.php 54
ERROR - 2023-12-07 06:47:16 --> Severity: Notice --> Undefined variable: activity_log C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\user_data.php 148
ERROR - 2023-12-07 06:47:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\user_data.php 148
ERROR - 2023-12-07 06:47:16 --> Severity: Notice --> Undefined variable: upcoming_events C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 2
ERROR - 2023-12-07 06:47:16 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 2
ERROR - 2023-12-07 06:47:16 --> Severity: Notice --> Undefined variable: upcoming_events C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 5
ERROR - 2023-12-07 06:47:16 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 5
ERROR - 2023-12-07 06:47:16 --> Severity: Notice --> Undefined variable: todos C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 30
ERROR - 2023-12-07 06:47:16 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 30
ERROR - 2023-12-07 06:47:16 --> Severity: Notice --> Undefined variable: todos C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 36
ERROR - 2023-12-07 06:47:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 36
ERROR - 2023-12-07 06:47:16 --> Severity: Notice --> Undefined variable: todos_finished C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 72
ERROR - 2023-12-07 06:47:16 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 72
ERROR - 2023-12-07 06:47:16 --> Severity: Notice --> Undefined variable: todos_finished C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 78
ERROR - 2023-12-07 06:47:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 78
ERROR - 2023-12-07 06:47:16 --> Severity: Notice --> Undefined variable: tickets_reply_by_status_no_json C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:47:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:47:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:47:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:47:16 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:47:16 --> Severity: Notice --> Undefined variable: tickets_awaiting_reply_by_department_no_json C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:47:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:47:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:47:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:47:16 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:47:16 --> Severity: Notice --> Undefined variable: projects_activity C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 2
ERROR - 2023-12-07 06:47:16 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 2
ERROR - 2023-12-07 06:47:16 --> Severity: Notice --> Undefined variable: projects_activity C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 26
ERROR - 2023-12-07 06:47:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 26
ERROR - 2023-12-07 06:47:16 --> Severity: Notice --> Undefined variable: tickets_report C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_report_table.php 17
ERROR - 2023-12-07 06:47:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_report_table.php 17
ERROR - 2023-12-07 06:50:09 --> Severity: Warning --> array_splice() expects parameter 1 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 183
ERROR - 2023-12-07 06:50:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 184
ERROR - 2023-12-07 06:50:09 --> Severity: Notice --> Undefined variable: proposal_statuses C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 230
ERROR - 2023-12-07 06:50:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 230
ERROR - 2023-12-07 06:50:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\models\Invoices_model.php 232
ERROR - 2023-12-07 06:50:09 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 06:50:09 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 06:50:09 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 06:50:09 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 06:50:09 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 06:50:09 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 06:50:09 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 06:50:09 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 06:50:09 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 06:50:09 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 06:50:09 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 06:50:09 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 06:50:09 --> Severity: Notice --> Undefined variable: total_undismissed_announcements C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\user_data.php 54
ERROR - 2023-12-07 06:50:09 --> Severity: Notice --> Undefined variable: activity_log C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\user_data.php 148
ERROR - 2023-12-07 06:50:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\user_data.php 148
ERROR - 2023-12-07 06:50:09 --> Severity: Notice --> Undefined variable: upcoming_events C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 2
ERROR - 2023-12-07 06:50:09 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 2
ERROR - 2023-12-07 06:50:09 --> Severity: Notice --> Undefined variable: upcoming_events C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 5
ERROR - 2023-12-07 06:50:09 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 5
ERROR - 2023-12-07 06:50:09 --> Severity: Notice --> Undefined variable: todos C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 30
ERROR - 2023-12-07 06:50:09 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 30
ERROR - 2023-12-07 06:50:09 --> Severity: Notice --> Undefined variable: todos C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 36
ERROR - 2023-12-07 06:50:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 36
ERROR - 2023-12-07 06:50:09 --> Severity: Notice --> Undefined variable: todos_finished C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 72
ERROR - 2023-12-07 06:50:09 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 72
ERROR - 2023-12-07 06:50:09 --> Severity: Notice --> Undefined variable: todos_finished C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 78
ERROR - 2023-12-07 06:50:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 78
ERROR - 2023-12-07 06:50:09 --> Severity: Notice --> Undefined variable: tickets_reply_by_status_no_json C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:50:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:50:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:50:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:50:09 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:50:09 --> Severity: Notice --> Undefined variable: tickets_awaiting_reply_by_department_no_json C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:50:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:50:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:50:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:50:09 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:50:09 --> Severity: Notice --> Undefined variable: projects_activity C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 2
ERROR - 2023-12-07 06:50:09 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 2
ERROR - 2023-12-07 06:50:09 --> Severity: Notice --> Undefined variable: projects_activity C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 26
ERROR - 2023-12-07 06:50:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 26
ERROR - 2023-12-07 06:50:09 --> Severity: Notice --> Undefined variable: tickets_report C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_report_table.php 17
ERROR - 2023-12-07 06:50:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_report_table.php 17
ERROR - 2023-12-07 06:50:55 --> Severity: Warning --> array_splice() expects parameter 1 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 183
ERROR - 2023-12-07 06:50:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 184
ERROR - 2023-12-07 06:50:55 --> Severity: Notice --> Undefined variable: proposal_statuses C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 230
ERROR - 2023-12-07 06:50:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 230
ERROR - 2023-12-07 06:50:55 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\models\Invoices_model.php 232
ERROR - 2023-12-07 06:50:55 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 06:50:55 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 06:50:55 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 06:50:55 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 06:50:55 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 06:50:55 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 06:50:55 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 06:50:55 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 06:50:55 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 06:50:55 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 06:50:55 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 06:50:55 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 06:50:55 --> Severity: Notice --> Undefined variable: total_undismissed_announcements C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\user_data.php 54
ERROR - 2023-12-07 06:50:55 --> Severity: Notice --> Undefined variable: activity_log C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\user_data.php 148
ERROR - 2023-12-07 06:50:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\user_data.php 148
ERROR - 2023-12-07 06:50:55 --> Severity: Notice --> Undefined variable: upcoming_events C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 2
ERROR - 2023-12-07 06:50:55 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 2
ERROR - 2023-12-07 06:50:55 --> Severity: Notice --> Undefined variable: upcoming_events C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 5
ERROR - 2023-12-07 06:50:55 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 5
ERROR - 2023-12-07 06:50:55 --> Severity: Notice --> Undefined variable: todos C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 30
ERROR - 2023-12-07 06:50:55 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 30
ERROR - 2023-12-07 06:50:55 --> Severity: Notice --> Undefined variable: todos C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 36
ERROR - 2023-12-07 06:50:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 36
ERROR - 2023-12-07 06:50:55 --> Severity: Notice --> Undefined variable: todos_finished C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 72
ERROR - 2023-12-07 06:50:55 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 72
ERROR - 2023-12-07 06:50:55 --> Severity: Notice --> Undefined variable: todos_finished C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 78
ERROR - 2023-12-07 06:50:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 78
ERROR - 2023-12-07 06:50:55 --> Severity: Notice --> Undefined variable: tickets_reply_by_status_no_json C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:50:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:50:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:50:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:50:55 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:50:55 --> Severity: Notice --> Undefined variable: tickets_awaiting_reply_by_department_no_json C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:50:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:50:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:50:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:50:55 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:50:55 --> Severity: Notice --> Undefined variable: projects_activity C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 2
ERROR - 2023-12-07 06:50:55 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 2
ERROR - 2023-12-07 06:50:55 --> Severity: Notice --> Undefined variable: projects_activity C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 26
ERROR - 2023-12-07 06:50:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 26
ERROR - 2023-12-07 06:50:55 --> Severity: Notice --> Undefined variable: tickets_report C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_report_table.php 17
ERROR - 2023-12-07 06:50:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_report_table.php 17
ERROR - 2023-12-07 06:52:22 --> Severity: Warning --> array_splice() expects parameter 1 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 183
ERROR - 2023-12-07 06:52:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 184
ERROR - 2023-12-07 06:52:22 --> Severity: Notice --> Undefined variable: proposal_statuses C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 230
ERROR - 2023-12-07 06:52:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 230
ERROR - 2023-12-07 06:52:22 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\models\Invoices_model.php 232
ERROR - 2023-12-07 06:52:22 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 06:52:22 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 06:52:22 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 06:52:22 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 06:52:22 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 06:52:22 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 06:52:22 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 06:52:22 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 06:52:22 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 06:52:22 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 06:52:22 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 06:52:22 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 06:52:22 --> Severity: Notice --> Undefined variable: total_undismissed_announcements C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\user_data.php 54
ERROR - 2023-12-07 06:52:22 --> Severity: Notice --> Undefined variable: activity_log C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\user_data.php 148
ERROR - 2023-12-07 06:52:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\user_data.php 148
ERROR - 2023-12-07 06:52:22 --> Severity: Notice --> Undefined variable: upcoming_events C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 2
ERROR - 2023-12-07 06:52:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 2
ERROR - 2023-12-07 06:52:22 --> Severity: Notice --> Undefined variable: upcoming_events C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 5
ERROR - 2023-12-07 06:52:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 5
ERROR - 2023-12-07 06:52:22 --> Severity: Notice --> Undefined variable: todos C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 30
ERROR - 2023-12-07 06:52:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 30
ERROR - 2023-12-07 06:52:22 --> Severity: Notice --> Undefined variable: todos C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 36
ERROR - 2023-12-07 06:52:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 36
ERROR - 2023-12-07 06:52:22 --> Severity: Notice --> Undefined variable: todos_finished C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 72
ERROR - 2023-12-07 06:52:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 72
ERROR - 2023-12-07 06:52:22 --> Severity: Notice --> Undefined variable: todos_finished C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 78
ERROR - 2023-12-07 06:52:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 78
ERROR - 2023-12-07 06:52:22 --> Severity: Notice --> Undefined variable: tickets_reply_by_status_no_json C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:52:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:52:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:52:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:52:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:52:22 --> Severity: Notice --> Undefined variable: tickets_awaiting_reply_by_department_no_json C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:52:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:52:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:52:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:52:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:52:22 --> Severity: Notice --> Undefined variable: projects_activity C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 2
ERROR - 2023-12-07 06:52:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 2
ERROR - 2023-12-07 06:52:22 --> Severity: Notice --> Undefined variable: projects_activity C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 26
ERROR - 2023-12-07 06:52:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 26
ERROR - 2023-12-07 06:52:22 --> Severity: Notice --> Undefined variable: tickets_report C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_report_table.php 17
ERROR - 2023-12-07 06:52:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_report_table.php 17
ERROR - 2023-12-07 06:52:34 --> Severity: Warning --> array_splice() expects parameter 1 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 183
ERROR - 2023-12-07 06:52:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 184
ERROR - 2023-12-07 06:52:34 --> Severity: Notice --> Undefined variable: proposal_statuses C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 230
ERROR - 2023-12-07 06:52:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 230
ERROR - 2023-12-07 06:52:34 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\models\Invoices_model.php 232
ERROR - 2023-12-07 06:52:34 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 06:52:34 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 06:52:34 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 06:52:34 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 06:52:34 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 06:52:34 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 06:52:34 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 06:52:34 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 06:52:34 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 06:52:34 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 06:52:34 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 06:52:34 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 06:52:34 --> Severity: Notice --> Undefined variable: total_undismissed_announcements C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\user_data.php 54
ERROR - 2023-12-07 06:52:34 --> Severity: Notice --> Undefined variable: activity_log C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\user_data.php 148
ERROR - 2023-12-07 06:52:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\user_data.php 148
ERROR - 2023-12-07 06:52:34 --> Severity: Notice --> Undefined variable: upcoming_events C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 2
ERROR - 2023-12-07 06:52:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 2
ERROR - 2023-12-07 06:52:34 --> Severity: Notice --> Undefined variable: upcoming_events C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 5
ERROR - 2023-12-07 06:52:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 5
ERROR - 2023-12-07 06:52:34 --> Severity: Notice --> Undefined variable: todos C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 30
ERROR - 2023-12-07 06:52:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 30
ERROR - 2023-12-07 06:52:34 --> Severity: Notice --> Undefined variable: todos C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 36
ERROR - 2023-12-07 06:52:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 36
ERROR - 2023-12-07 06:52:34 --> Severity: Notice --> Undefined variable: todos_finished C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 72
ERROR - 2023-12-07 06:52:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 72
ERROR - 2023-12-07 06:52:34 --> Severity: Notice --> Undefined variable: todos_finished C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 78
ERROR - 2023-12-07 06:52:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 78
ERROR - 2023-12-07 06:52:34 --> Severity: Notice --> Undefined variable: tickets_reply_by_status_no_json C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:52:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:52:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:52:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:52:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:52:34 --> Severity: Notice --> Undefined variable: tickets_awaiting_reply_by_department_no_json C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:52:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:52:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:52:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:52:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:52:34 --> Severity: Notice --> Undefined variable: projects_activity C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 2
ERROR - 2023-12-07 06:52:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 2
ERROR - 2023-12-07 06:52:34 --> Severity: Notice --> Undefined variable: projects_activity C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 26
ERROR - 2023-12-07 06:52:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 26
ERROR - 2023-12-07 06:52:34 --> Severity: Notice --> Undefined variable: tickets_report C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_report_table.php 17
ERROR - 2023-12-07 06:52:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_report_table.php 17
ERROR - 2023-12-07 06:55:46 --> Severity: Warning --> array_splice() expects parameter 1 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 183
ERROR - 2023-12-07 06:55:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 184
ERROR - 2023-12-07 06:55:46 --> Severity: Notice --> Undefined variable: proposal_statuses C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 230
ERROR - 2023-12-07 06:55:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 230
ERROR - 2023-12-07 06:55:46 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\models\Invoices_model.php 232
ERROR - 2023-12-07 06:55:46 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 06:55:46 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 06:55:46 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 06:55:46 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 06:55:46 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 06:55:46 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 06:55:46 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 06:55:46 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 06:55:46 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 06:55:46 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 06:55:46 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 06:55:46 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 06:55:46 --> Severity: Notice --> Undefined variable: total_undismissed_announcements C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\user_data.php 54
ERROR - 2023-12-07 06:55:46 --> Severity: Notice --> Undefined variable: activity_log C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\user_data.php 148
ERROR - 2023-12-07 06:55:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\user_data.php 148
ERROR - 2023-12-07 06:55:46 --> Severity: Notice --> Undefined variable: upcoming_events C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 2
ERROR - 2023-12-07 06:55:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 2
ERROR - 2023-12-07 06:55:46 --> Severity: Notice --> Undefined variable: upcoming_events C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 5
ERROR - 2023-12-07 06:55:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 5
ERROR - 2023-12-07 06:55:46 --> Severity: Notice --> Undefined variable: todos C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 30
ERROR - 2023-12-07 06:55:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 30
ERROR - 2023-12-07 06:55:46 --> Severity: Notice --> Undefined variable: todos C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 36
ERROR - 2023-12-07 06:55:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 36
ERROR - 2023-12-07 06:55:46 --> Severity: Notice --> Undefined variable: todos_finished C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 72
ERROR - 2023-12-07 06:55:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 72
ERROR - 2023-12-07 06:55:46 --> Severity: Notice --> Undefined variable: todos_finished C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 78
ERROR - 2023-12-07 06:55:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 78
ERROR - 2023-12-07 06:55:46 --> Severity: Notice --> Undefined variable: tickets_reply_by_status_no_json C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:55:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:55:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:55:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:55:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:55:46 --> Severity: Notice --> Undefined variable: tickets_awaiting_reply_by_department_no_json C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:55:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:55:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:55:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:55:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 06:55:46 --> Severity: Notice --> Undefined variable: projects_activity C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 2
ERROR - 2023-12-07 06:55:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 2
ERROR - 2023-12-07 06:55:46 --> Severity: Notice --> Undefined variable: projects_activity C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 26
ERROR - 2023-12-07 06:55:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 26
ERROR - 2023-12-07 06:55:46 --> Severity: Notice --> Undefined variable: tickets_report C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_report_table.php 17
ERROR - 2023-12-07 06:55:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_report_table.php 17
ERROR - 2023-12-07 07:01:06 --> Severity: Warning --> array_splice() expects parameter 1 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 183
ERROR - 2023-12-07 07:01:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 184
ERROR - 2023-12-07 07:01:06 --> Severity: Notice --> Undefined variable: proposal_statuses C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 230
ERROR - 2023-12-07 07:01:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 230
ERROR - 2023-12-07 07:01:06 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\models\Invoices_model.php 232
ERROR - 2023-12-07 07:01:06 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 07:01:06 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 07:01:06 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 07:01:06 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 07:01:06 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 07:01:06 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 07:01:06 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 07:01:06 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 07:01:06 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 07:01:06 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 07:01:06 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 07:01:06 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 07:01:06 --> Severity: Notice --> Undefined variable: total_undismissed_announcements C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\user_data.php 54
ERROR - 2023-12-07 07:01:06 --> Severity: Notice --> Undefined variable: activity_log C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\user_data.php 148
ERROR - 2023-12-07 07:01:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\user_data.php 148
ERROR - 2023-12-07 07:01:06 --> Severity: Notice --> Undefined variable: upcoming_events C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 2
ERROR - 2023-12-07 07:01:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 2
ERROR - 2023-12-07 07:01:06 --> Severity: Notice --> Undefined variable: upcoming_events C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 5
ERROR - 2023-12-07 07:01:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 5
ERROR - 2023-12-07 07:01:06 --> Severity: Notice --> Undefined variable: todos C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 30
ERROR - 2023-12-07 07:01:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 30
ERROR - 2023-12-07 07:01:06 --> Severity: Notice --> Undefined variable: todos C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 36
ERROR - 2023-12-07 07:01:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 36
ERROR - 2023-12-07 07:01:06 --> Severity: Notice --> Undefined variable: todos_finished C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 72
ERROR - 2023-12-07 07:01:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 72
ERROR - 2023-12-07 07:01:06 --> Severity: Notice --> Undefined variable: todos_finished C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 78
ERROR - 2023-12-07 07:01:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 78
ERROR - 2023-12-07 07:01:06 --> Severity: Notice --> Undefined variable: tickets_reply_by_status_no_json C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 07:01:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 07:01:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 07:01:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 07:01:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 07:01:06 --> Severity: Notice --> Undefined variable: tickets_awaiting_reply_by_department_no_json C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 07:01:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 07:01:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 07:01:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 07:01:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 07:01:06 --> Severity: Notice --> Undefined variable: projects_activity C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 2
ERROR - 2023-12-07 07:01:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 2
ERROR - 2023-12-07 07:01:06 --> Severity: Notice --> Undefined variable: projects_activity C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 26
ERROR - 2023-12-07 07:01:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 26
ERROR - 2023-12-07 07:01:06 --> Severity: Notice --> Undefined variable: tickets_report C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_report_table.php 17
ERROR - 2023-12-07 07:01:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_report_table.php 17
ERROR - 2023-12-07 07:01:15 --> Severity: Warning --> array_splice() expects parameter 1 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 183
ERROR - 2023-12-07 07:01:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 184
ERROR - 2023-12-07 07:01:15 --> Severity: Notice --> Undefined variable: proposal_statuses C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 230
ERROR - 2023-12-07 07:01:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 230
ERROR - 2023-12-07 07:01:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\models\Invoices_model.php 232
ERROR - 2023-12-07 07:01:15 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 07:01:15 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 07:01:15 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 07:01:15 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 07:01:15 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 07:01:15 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 07:01:15 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 07:01:15 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 07:01:15 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 07:01:15 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 07:01:15 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 07:01:15 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 07:01:15 --> Severity: Notice --> Undefined variable: total_undismissed_announcements C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\user_data.php 54
ERROR - 2023-12-07 07:01:15 --> Severity: Notice --> Undefined variable: activity_log C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\user_data.php 148
ERROR - 2023-12-07 07:01:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\user_data.php 148
ERROR - 2023-12-07 07:01:15 --> Severity: Notice --> Undefined variable: upcoming_events C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 2
ERROR - 2023-12-07 07:01:15 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 2
ERROR - 2023-12-07 07:01:15 --> Severity: Notice --> Undefined variable: upcoming_events C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 5
ERROR - 2023-12-07 07:01:15 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 5
ERROR - 2023-12-07 07:01:15 --> Severity: Notice --> Undefined variable: todos C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 30
ERROR - 2023-12-07 07:01:15 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 30
ERROR - 2023-12-07 07:01:15 --> Severity: Notice --> Undefined variable: todos C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 36
ERROR - 2023-12-07 07:01:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 36
ERROR - 2023-12-07 07:01:15 --> Severity: Notice --> Undefined variable: todos_finished C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 72
ERROR - 2023-12-07 07:01:15 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 72
ERROR - 2023-12-07 07:01:15 --> Severity: Notice --> Undefined variable: todos_finished C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 78
ERROR - 2023-12-07 07:01:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 78
ERROR - 2023-12-07 07:01:15 --> Severity: Notice --> Undefined variable: tickets_reply_by_status_no_json C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 07:01:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 07:01:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 07:01:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 07:01:15 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 07:01:15 --> Severity: Notice --> Undefined variable: tickets_awaiting_reply_by_department_no_json C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 07:01:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 07:01:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 07:01:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 07:01:15 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 07:01:15 --> Severity: Notice --> Undefined variable: projects_activity C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 2
ERROR - 2023-12-07 07:01:15 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 2
ERROR - 2023-12-07 07:01:15 --> Severity: Notice --> Undefined variable: projects_activity C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 26
ERROR - 2023-12-07 07:01:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 26
ERROR - 2023-12-07 07:01:15 --> Severity: Notice --> Undefined variable: tickets_report C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_report_table.php 17
ERROR - 2023-12-07 07:01:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_report_table.php 17
ERROR - 2023-12-07 07:04:34 --> Severity: Warning --> array_splice() expects parameter 1 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 183
ERROR - 2023-12-07 07:04:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 184
ERROR - 2023-12-07 07:04:34 --> Severity: Notice --> Undefined variable: proposal_statuses C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 230
ERROR - 2023-12-07 07:04:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 230
ERROR - 2023-12-07 07:04:34 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\models\Invoices_model.php 232
ERROR - 2023-12-07 07:04:34 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 07:04:34 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 07:04:34 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 07:04:34 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 07:04:34 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 07:04:34 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 07:04:34 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 07:04:34 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 07:04:34 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 07:04:34 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 07:04:34 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 07:04:34 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 07:04:34 --> Severity: Notice --> Undefined variable: total_undismissed_announcements C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\user_data.php 54
ERROR - 2023-12-07 07:04:34 --> Severity: Notice --> Undefined variable: activity_log C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\user_data.php 148
ERROR - 2023-12-07 07:04:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\user_data.php 148
ERROR - 2023-12-07 07:04:34 --> Severity: Notice --> Undefined variable: upcoming_events C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 2
ERROR - 2023-12-07 07:04:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 2
ERROR - 2023-12-07 07:04:34 --> Severity: Notice --> Undefined variable: upcoming_events C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 5
ERROR - 2023-12-07 07:04:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 5
ERROR - 2023-12-07 07:04:34 --> Severity: Notice --> Undefined variable: todos C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 30
ERROR - 2023-12-07 07:04:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 30
ERROR - 2023-12-07 07:04:34 --> Severity: Notice --> Undefined variable: todos C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 36
ERROR - 2023-12-07 07:04:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 36
ERROR - 2023-12-07 07:04:34 --> Severity: Notice --> Undefined variable: todos_finished C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 72
ERROR - 2023-12-07 07:04:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 72
ERROR - 2023-12-07 07:04:34 --> Severity: Notice --> Undefined variable: todos_finished C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 78
ERROR - 2023-12-07 07:04:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 78
ERROR - 2023-12-07 07:04:34 --> Severity: Notice --> Undefined variable: tickets_reply_by_status_no_json C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 07:04:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 07:04:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 07:04:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 07:04:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 07:04:34 --> Severity: Notice --> Undefined variable: tickets_awaiting_reply_by_department_no_json C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 07:04:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 07:04:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 07:04:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 07:04:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 07:04:34 --> Severity: Notice --> Undefined variable: projects_activity C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 2
ERROR - 2023-12-07 07:04:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 2
ERROR - 2023-12-07 07:04:34 --> Severity: Notice --> Undefined variable: projects_activity C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 26
ERROR - 2023-12-07 07:04:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 26
ERROR - 2023-12-07 07:04:34 --> Severity: Notice --> Undefined variable: tickets_report C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_report_table.php 17
ERROR - 2023-12-07 07:04:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_report_table.php 17
ERROR - 2023-12-07 07:05:16 --> Severity: Warning --> array_splice() expects parameter 1 to be array, null given C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 183
ERROR - 2023-12-07 07:05:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 184
ERROR - 2023-12-07 07:05:16 --> Severity: Notice --> Undefined variable: proposal_statuses C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 230
ERROR - 2023-12-07 07:05:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\finance_overview.php 230
ERROR - 2023-12-07 07:05:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\models\Invoices_model.php 232
ERROR - 2023-12-07 07:05:16 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 07:05:16 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 07:05:16 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 07:05:16 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 07:05:16 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 07:05:16 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 07:05:16 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 07:05:16 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 07:05:16 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 07:05:16 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 07:05:16 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 07:05:16 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 07:05:16 --> Severity: Notice --> Undefined variable: total_undismissed_announcements C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\user_data.php 54
ERROR - 2023-12-07 07:05:16 --> Severity: Notice --> Undefined variable: activity_log C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\user_data.php 148
ERROR - 2023-12-07 07:05:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\user_data.php 148
ERROR - 2023-12-07 07:05:16 --> Severity: Notice --> Undefined variable: upcoming_events C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 2
ERROR - 2023-12-07 07:05:16 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 2
ERROR - 2023-12-07 07:05:16 --> Severity: Notice --> Undefined variable: upcoming_events C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 5
ERROR - 2023-12-07 07:05:16 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\upcoming_events.php 5
ERROR - 2023-12-07 07:05:16 --> Severity: Notice --> Undefined variable: todos C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 30
ERROR - 2023-12-07 07:05:16 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 30
ERROR - 2023-12-07 07:05:16 --> Severity: Notice --> Undefined variable: todos C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 36
ERROR - 2023-12-07 07:05:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 36
ERROR - 2023-12-07 07:05:16 --> Severity: Notice --> Undefined variable: todos_finished C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 72
ERROR - 2023-12-07 07:05:16 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 72
ERROR - 2023-12-07 07:05:16 --> Severity: Notice --> Undefined variable: todos_finished C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 78
ERROR - 2023-12-07 07:05:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\todos.php 78
ERROR - 2023-12-07 07:05:16 --> Severity: Notice --> Undefined variable: tickets_reply_by_status_no_json C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 07:05:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 07:05:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 07:05:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 07:05:16 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 07:05:16 --> Severity: Notice --> Undefined variable: tickets_awaiting_reply_by_department_no_json C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 07:05:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 07:05:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 07:05:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 07:05:16 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_chart.php 3
ERROR - 2023-12-07 07:05:16 --> Severity: Notice --> Undefined variable: projects_activity C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 2
ERROR - 2023-12-07 07:05:16 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 2
ERROR - 2023-12-07 07:05:16 --> Severity: Notice --> Undefined variable: projects_activity C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 26
ERROR - 2023-12-07 07:05:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\projects_activity.php 26
ERROR - 2023-12-07 07:05:16 --> Severity: Notice --> Undefined variable: tickets_report C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_report_table.php 17
ERROR - 2023-12-07 07:05:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\tickets_report_table.php 17
ERROR - 2023-12-07 07:05:55 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 07:05:55 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 07:05:55 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 07:05:55 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 07:05:55 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 07:05:55 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 07:05:55 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 07:05:55 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 07:05:55 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 07:05:55 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 07:05:55 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 07:05:55 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 07:05:55 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 07:05:55 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 07:05:55 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 07:05:55 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 07:05:55 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 07:05:55 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 07:05:55 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 07:05:55 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 07:05:55 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 07:05:55 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 07:05:55 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 07:05:55 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 18:10:06 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 18:10:06 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 18:10:06 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 18:10:06 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 18:10:06 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 18:10:06 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 18:10:06 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 18:10:06 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 18:10:06 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 18:10:06 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 18:10:06 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 18:10:06 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 18:10:06 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 18:10:06 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 18:10:06 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 18:10:06 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 18:10:06 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 18:10:06 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 18:10:06 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 18:10:06 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 18:10:06 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 18:10:06 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 18:10:06 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 18:10:06 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 18:34:02 --> Severity: Notice --> Array to string conversion C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 18
ERROR - 2023-12-07 18:34:02 --> Severity: Notice --> Array to string conversion C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 19
ERROR - 2023-12-07 18:34:02 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `status` NOT IN (5,6) AND `clientid` IN (Array)
ERROR - 2023-12-07 18:35:42 --> Severity: Notice --> Array to string conversion C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 19
ERROR - 2023-12-07 18:35:42 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `status` NOT IN (5,6) AND `clientid` IN (Array)
ERROR - 2023-12-07 18:36:31 --> Severity: Notice --> Array to string conversion C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 19
ERROR - 2023-12-07 18:36:31 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `status` NOT IN (5,6) AND `clientid` IN (Array)
ERROR - 2023-12-07 18:38:42 --> Severity: Notice --> Array to string conversion C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 18
ERROR - 2023-12-07 18:46:02 --> Severity: Notice --> Array to string conversion C:\xampp-new\htdocs\finishizer_erp3.0.5\application\views\admin\dashboard\widgets\top_stats.php 18
ERROR - 2023-12-07 18:49:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '1' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `status` NOT IN (5,6) AND clientid IN 1
ERROR - 2023-12-07 18:53:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '2' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `tblinvoices`
WHERE `status` NOT IN (5,6) AND clientid IN 2
ERROR - 2023-12-07 19:00:42 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\libraries\App.php 283
ERROR - 2023-12-07 19:00:47 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 19:00:47 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 19:00:47 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 19:00:47 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 19:00:51 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\models\Currencies_model.php 23
ERROR - 2023-12-07 19:00:51 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 19:00:51 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 19:00:51 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 19:00:51 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 19:01:41 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\models\Currencies_model.php 23
ERROR - 2023-12-07 19:01:41 --> Severity: Notice --> Trying to get property 'symbol' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 137
ERROR - 2023-12-07 19:01:41 --> Severity: Notice --> Trying to get property 'decimal_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 19:01:41 --> Severity: Notice --> Trying to get property 'thousand_separator' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 150
ERROR - 2023-12-07 19:01:41 --> Severity: Notice --> Trying to get property 'placement' of non-object C:\xampp-new\htdocs\finishizer_erp3.0.5\application\helpers\sales_helper.php 156
ERROR - 2023-12-07 19:07:22 --> Query error: Column 'id' in field list is ambiguous - Invalid query: SELECT tbltasks.name as title, id, (CASE rel_type
        WHEN "contract" THEN (SELECT subject FROM tblcontracts WHERE tblcontracts.id = tbltasks.rel_id)
        WHEN "estimate" THEN (SELECT id FROM tblestimates WHERE tblestimates.id = tbltasks.rel_id)
        WHEN "proposal" THEN (SELECT id FROM tblproposals WHERE tblproposals.id = tbltasks.rel_id)
        WHEN "invoice" THEN (SELECT id FROM tblinvoices WHERE tblinvoices.id = tbltasks.rel_id)
        WHEN "ticket" THEN (SELECT CONCAT(CONCAT("#", tbltickets.ticketid), " - ", tbltickets.subject) FROM tbltickets WHERE tbltickets.ticketid=tbltasks.rel_id)
        WHEN "lead" THEN (SELECT CASE tblleads.email WHEN "" THEN tblleads.name ELSE CONCAT(tblleads.name, " - ", tblleads.email) END FROM tblleads WHERE tblleads.id=tbltasks.rel_id)
        WHEN "customer" THEN (SELECT CASE company WHEN "" THEN (SELECT CONCAT(firstname, " ", lastname) FROM tblcontacts WHERE userid = tblclients.userid and is_primary = 1) ELSE company END FROM tblclients WHERE tblclients.userid=tbltasks.rel_id)
        WHEN "project" THEN (SELECT CONCAT(CONCAT(CONCAT("#", tblprojects.id), " - ", tblprojects.name), " - ", (SELECT CASE company WHEN "" THEN (SELECT CONCAT(firstname, " ", lastname) FROM tblcontacts WHERE userid = tblclients.userid and is_primary = 1) ELSE company END FROM tblclients WHERE userid=tblprojects.clientid)) FROM tblprojects WHERE tblprojects.id=tbltasks.rel_id)
        WHEN "expense" THEN (SELECT CASE expense_name WHEN "" THEN tblexpenses_categories.name ELSE
         CONCAT(tblexpenses_categories.name, ' (', tblexpenses.expense_name, ')') END FROM tblexpenses JOIN tblexpenses_categories ON tblexpenses_categories.id = tblexpenses.category WHERE tblexpenses.id=tbltasks.rel_id)
        ELSE NULL
        END) as rel_name, rel_id, status, milestone, CASE WHEN duedate IS NULL THEN startdate ELSE duedate END as date, `id`
FROM `tbltasks`, `tbloptions`
WHERE `status` != 5
AND CASE WHEN duedate IS NULL THEN (startdate BETWEEN '2023-11-26' AND '2024-01-07') ELSE (duedate BETWEEN '2023-11-26' AND '2024-01-07') END
AND `name` = 'calendar_only_assigned_tasks'
ERROR - 2023-12-07 19:07:46 --> Query error: Column 'id' in field list is ambiguous - Invalid query: SELECT tbltasks.name as title, id, (CASE rel_type
        WHEN "contract" THEN (SELECT subject FROM tblcontracts WHERE tblcontracts.id = tbltasks.rel_id)
        WHEN "estimate" THEN (SELECT id FROM tblestimates WHERE tblestimates.id = tbltasks.rel_id)
        WHEN "proposal" THEN (SELECT id FROM tblproposals WHERE tblproposals.id = tbltasks.rel_id)
        WHEN "invoice" THEN (SELECT id FROM tblinvoices WHERE tblinvoices.id = tbltasks.rel_id)
        WHEN "ticket" THEN (SELECT CONCAT(CONCAT("#", tbltickets.ticketid), " - ", tbltickets.subject) FROM tbltickets WHERE tbltickets.ticketid=tbltasks.rel_id)
        WHEN "lead" THEN (SELECT CASE tblleads.email WHEN "" THEN tblleads.name ELSE CONCAT(tblleads.name, " - ", tblleads.email) END FROM tblleads WHERE tblleads.id=tbltasks.rel_id)
        WHEN "customer" THEN (SELECT CASE company WHEN "" THEN (SELECT CONCAT(firstname, " ", lastname) FROM tblcontacts WHERE userid = tblclients.userid and is_primary = 1) ELSE company END FROM tblclients WHERE tblclients.userid=tbltasks.rel_id)
        WHEN "project" THEN (SELECT CONCAT(CONCAT(CONCAT("#", tblprojects.id), " - ", tblprojects.name), " - ", (SELECT CASE company WHEN "" THEN (SELECT CONCAT(firstname, " ", lastname) FROM tblcontacts WHERE userid = tblclients.userid and is_primary = 1) ELSE company END FROM tblclients WHERE userid=tblprojects.clientid)) FROM tblprojects WHERE tblprojects.id=tbltasks.rel_id)
        WHEN "expense" THEN (SELECT CASE expense_name WHEN "" THEN tblexpenses_categories.name ELSE
         CONCAT(tblexpenses_categories.name, ' (', tblexpenses.expense_name, ')') END FROM tblexpenses JOIN tblexpenses_categories ON tblexpenses_categories.id = tblexpenses.category WHERE tblexpenses.id=tbltasks.rel_id)
        ELSE NULL
        END) as rel_name, rel_id, status, milestone, CASE WHEN duedate IS NULL THEN startdate ELSE duedate END as date, `id`
FROM `tbltasks`, `tbloptions`
WHERE `status` != 5
AND CASE WHEN duedate IS NULL THEN (startdate BETWEEN '2023-11-26' AND '2024-01-07') ELSE (duedate BETWEEN '2023-11-26' AND '2024-01-07') END
AND `name` = 'calendar_only_assigned_tasks'
ERROR - 2023-12-07 19:08:50 --> Query error: Column 'id' in field list is ambiguous - Invalid query: SELECT tbltasks.name as title, id, (CASE rel_type
        WHEN "contract" THEN (SELECT subject FROM tblcontracts WHERE tblcontracts.id = tbltasks.rel_id)
        WHEN "estimate" THEN (SELECT id FROM tblestimates WHERE tblestimates.id = tbltasks.rel_id)
        WHEN "proposal" THEN (SELECT id FROM tblproposals WHERE tblproposals.id = tbltasks.rel_id)
        WHEN "invoice" THEN (SELECT id FROM tblinvoices WHERE tblinvoices.id = tbltasks.rel_id)
        WHEN "ticket" THEN (SELECT CONCAT(CONCAT("#", tbltickets.ticketid), " - ", tbltickets.subject) FROM tbltickets WHERE tbltickets.ticketid=tbltasks.rel_id)
        WHEN "lead" THEN (SELECT CASE tblleads.email WHEN "" THEN tblleads.name ELSE CONCAT(tblleads.name, " - ", tblleads.email) END FROM tblleads WHERE tblleads.id=tbltasks.rel_id)
        WHEN "customer" THEN (SELECT CASE company WHEN "" THEN (SELECT CONCAT(firstname, " ", lastname) FROM tblcontacts WHERE userid = tblclients.userid and is_primary = 1) ELSE company END FROM tblclients WHERE tblclients.userid=tbltasks.rel_id)
        WHEN "project" THEN (SELECT CONCAT(CONCAT(CONCAT("#", tblprojects.id), " - ", tblprojects.name), " - ", (SELECT CASE company WHEN "" THEN (SELECT CONCAT(firstname, " ", lastname) FROM tblcontacts WHERE userid = tblclients.userid and is_primary = 1) ELSE company END FROM tblclients WHERE userid=tblprojects.clientid)) FROM tblprojects WHERE tblprojects.id=tbltasks.rel_id)
        WHEN "expense" THEN (SELECT CASE expense_name WHEN "" THEN tblexpenses_categories.name ELSE
         CONCAT(tblexpenses_categories.name, ' (', tblexpenses.expense_name, ')') END FROM tblexpenses JOIN tblexpenses_categories ON tblexpenses_categories.id = tblexpenses.category WHERE tblexpenses.id=tbltasks.rel_id)
        ELSE NULL
        END) as rel_name, rel_id, status, milestone, CASE WHEN duedate IS NULL THEN startdate ELSE duedate END as date, `id`
FROM `tbltasks`, `tbloptions`
WHERE `status` != 5
AND CASE WHEN duedate IS NULL THEN (startdate BETWEEN '2023-11-26' AND '2024-01-07') ELSE (duedate BETWEEN '2023-11-26' AND '2024-01-07') END
AND `name` = 'calendar_only_assigned_tasks'
ERROR - 2023-12-07 19:09:05 --> Query error: Column 'id' in field list is ambiguous - Invalid query: SELECT tbltasks.name as title, id, (CASE rel_type
        WHEN "contract" THEN (SELECT subject FROM tblcontracts WHERE tblcontracts.id = tbltasks.rel_id)
        WHEN "estimate" THEN (SELECT id FROM tblestimates WHERE tblestimates.id = tbltasks.rel_id)
        WHEN "proposal" THEN (SELECT id FROM tblproposals WHERE tblproposals.id = tbltasks.rel_id)
        WHEN "invoice" THEN (SELECT id FROM tblinvoices WHERE tblinvoices.id = tbltasks.rel_id)
        WHEN "ticket" THEN (SELECT CONCAT(CONCAT("#", tbltickets.ticketid), " - ", tbltickets.subject) FROM tbltickets WHERE tbltickets.ticketid=tbltasks.rel_id)
        WHEN "lead" THEN (SELECT CASE tblleads.email WHEN "" THEN tblleads.name ELSE CONCAT(tblleads.name, " - ", tblleads.email) END FROM tblleads WHERE tblleads.id=tbltasks.rel_id)
        WHEN "customer" THEN (SELECT CASE company WHEN "" THEN (SELECT CONCAT(firstname, " ", lastname) FROM tblcontacts WHERE userid = tblclients.userid and is_primary = 1) ELSE company END FROM tblclients WHERE tblclients.userid=tbltasks.rel_id)
        WHEN "project" THEN (SELECT CONCAT(CONCAT(CONCAT("#", tblprojects.id), " - ", tblprojects.name), " - ", (SELECT CASE company WHEN "" THEN (SELECT CONCAT(firstname, " ", lastname) FROM tblcontacts WHERE userid = tblclients.userid and is_primary = 1) ELSE company END FROM tblclients WHERE userid=tblprojects.clientid)) FROM tblprojects WHERE tblprojects.id=tbltasks.rel_id)
        WHEN "expense" THEN (SELECT CASE expense_name WHEN "" THEN tblexpenses_categories.name ELSE
         CONCAT(tblexpenses_categories.name, ' (', tblexpenses.expense_name, ')') END FROM tblexpenses JOIN tblexpenses_categories ON tblexpenses_categories.id = tblexpenses.category WHERE tblexpenses.id=tbltasks.rel_id)
        ELSE NULL
        END) as rel_name, rel_id, status, milestone, CASE WHEN duedate IS NULL THEN startdate ELSE duedate END as date, `id`
FROM `tbltasks`, `tbloptions`
WHERE `status` != 5
AND CASE WHEN duedate IS NULL THEN (startdate BETWEEN '2023-11-26' AND '2024-01-07') ELSE (duedate BETWEEN '2023-11-26' AND '2024-01-07') END
AND `name` = 'calendar_only_assigned_tasks'
ERROR - 2023-12-07 19:09:25 --> Query error: Column 'id' in field list is ambiguous - Invalid query: SELECT tbltasks.name as title, id, (CASE rel_type
        WHEN "contract" THEN (SELECT subject FROM tblcontracts WHERE tblcontracts.id = tbltasks.rel_id)
        WHEN "estimate" THEN (SELECT id FROM tblestimates WHERE tblestimates.id = tbltasks.rel_id)
        WHEN "proposal" THEN (SELECT id FROM tblproposals WHERE tblproposals.id = tbltasks.rel_id)
        WHEN "invoice" THEN (SELECT id FROM tblinvoices WHERE tblinvoices.id = tbltasks.rel_id)
        WHEN "ticket" THEN (SELECT CONCAT(CONCAT("#", tbltickets.ticketid), " - ", tbltickets.subject) FROM tbltickets WHERE tbltickets.ticketid=tbltasks.rel_id)
        WHEN "lead" THEN (SELECT CASE tblleads.email WHEN "" THEN tblleads.name ELSE CONCAT(tblleads.name, " - ", tblleads.email) END FROM tblleads WHERE tblleads.id=tbltasks.rel_id)
        WHEN "customer" THEN (SELECT CASE company WHEN "" THEN (SELECT CONCAT(firstname, " ", lastname) FROM tblcontacts WHERE userid = tblclients.userid and is_primary = 1) ELSE company END FROM tblclients WHERE tblclients.userid=tbltasks.rel_id)
        WHEN "project" THEN (SELECT CONCAT(CONCAT(CONCAT("#", tblprojects.id), " - ", tblprojects.name), " - ", (SELECT CASE company WHEN "" THEN (SELECT CONCAT(firstname, " ", lastname) FROM tblcontacts WHERE userid = tblclients.userid and is_primary = 1) ELSE company END FROM tblclients WHERE userid=tblprojects.clientid)) FROM tblprojects WHERE tblprojects.id=tbltasks.rel_id)
        WHEN "expense" THEN (SELECT CASE expense_name WHEN "" THEN tblexpenses_categories.name ELSE
         CONCAT(tblexpenses_categories.name, ' (', tblexpenses.expense_name, ')') END FROM tblexpenses JOIN tblexpenses_categories ON tblexpenses_categories.id = tblexpenses.category WHERE tblexpenses.id=tbltasks.rel_id)
        ELSE NULL
        END) as rel_name, rel_id, status, milestone, CASE WHEN duedate IS NULL THEN startdate ELSE duedate END as date, `id`
FROM `tbltasks`, `tbloptions`
WHERE `status` != 5
AND CASE WHEN duedate IS NULL THEN (startdate BETWEEN '2023-11-26' AND '2024-01-07') ELSE (duedate BETWEEN '2023-11-26' AND '2024-01-07') END
AND `name` = 'calendar_only_assigned_tasks'
ERROR - 2023-12-07 19:15:27 --> Query error: Column 'id' in field list is ambiguous - Invalid query: SELECT tbltasks.name as title, id, (CASE rel_type
        WHEN "contract" THEN (SELECT subject FROM tblcontracts WHERE tblcontracts.id = tbltasks.rel_id)
        WHEN "estimate" THEN (SELECT id FROM tblestimates WHERE tblestimates.id = tbltasks.rel_id)
        WHEN "proposal" THEN (SELECT id FROM tblproposals WHERE tblproposals.id = tbltasks.rel_id)
        WHEN "invoice" THEN (SELECT id FROM tblinvoices WHERE tblinvoices.id = tbltasks.rel_id)
        WHEN "ticket" THEN (SELECT CONCAT(CONCAT("#", tbltickets.ticketid), " - ", tbltickets.subject) FROM tbltickets WHERE tbltickets.ticketid=tbltasks.rel_id)
        WHEN "lead" THEN (SELECT CASE tblleads.email WHEN "" THEN tblleads.name ELSE CONCAT(tblleads.name, " - ", tblleads.email) END FROM tblleads WHERE tblleads.id=tbltasks.rel_id)
        WHEN "customer" THEN (SELECT CASE company WHEN "" THEN (SELECT CONCAT(firstname, " ", lastname) FROM tblcontacts WHERE userid = tblclients.userid and is_primary = 1) ELSE company END FROM tblclients WHERE tblclients.userid=tbltasks.rel_id)
        WHEN "project" THEN (SELECT CONCAT(CONCAT(CONCAT("#", tblprojects.id), " - ", tblprojects.name), " - ", (SELECT CASE company WHEN "" THEN (SELECT CONCAT(firstname, " ", lastname) FROM tblcontacts WHERE userid = tblclients.userid and is_primary = 1) ELSE company END FROM tblclients WHERE userid=tblprojects.clientid)) FROM tblprojects WHERE tblprojects.id=tbltasks.rel_id)
        WHEN "expense" THEN (SELECT CASE expense_name WHEN "" THEN tblexpenses_categories.name ELSE
         CONCAT(tblexpenses_categories.name, ' (', tblexpenses.expense_name, ')') END FROM tblexpenses JOIN tblexpenses_categories ON tblexpenses_categories.id = tblexpenses.category WHERE tblexpenses.id=tbltasks.rel_id)
        ELSE NULL
        END) as rel_name, rel_id, status, milestone, CASE WHEN duedate IS NULL THEN startdate ELSE duedate END as date, `id`
FROM `tbltasks`, `tbloptions`
WHERE `status` != 5
AND CASE WHEN duedate IS NULL THEN (startdate BETWEEN '2023-11-26' AND '2024-01-07') ELSE (duedate BETWEEN '2023-11-26' AND '2024-01-07') END
AND `name` = 'calendar_only_assigned_tasks'
