<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-12-30 16:08:33 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:08:33 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:08:34 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:08:34 --> Could not find the language line "View Dashboard"
ERROR - 2023-12-30 16:08:34 --> Could not find the language line "View Dashboard"
ERROR - 2023-12-30 16:08:34 --> Could not find the language line "View Dashboard"
ERROR - 2023-12-30 16:08:37 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:08:42 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:08:43 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:08:44 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:08:45 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:08:52 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:08:53 --> Query error: Column 'branch_id' in where clause is ambiguous - Invalid query: SELECT *
FROM `tblleads`, `tblleads_sources`
WHERE `branch_id` = '1' OR `branch_id` = '0'
ORDER BY `name` ASC
ERROR - 2023-12-30 16:09:04 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:09:05 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:09:08 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:09:22 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:09:22 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:09:25 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:09:25 --> Query error: Column 'branch_id' in where clause is ambiguous - Invalid query: SELECT *
FROM `tblleads`, `tblleads_sources`
WHERE `branch_id` = '1' OR `branch_id` = '0'
ORDER BY `name` ASC
ERROR - 2023-12-30 16:10:37 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:10:37 --> Query error: Column 'branch_id' in where clause is ambiguous - Invalid query: SELECT *
FROM `tblleads`, `tblleads_sources`
WHERE `branch_id` = '1' OR `branch_id` = '0'
ORDER BY `name` ASC
ERROR - 2023-12-30 16:26:50 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:26:51 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:26:54 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:26:59 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:27:20 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:27:23 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:27:23 --> Query error: Column 'branch_id' in where clause is ambiguous - Invalid query: SELECT *
FROM `tblleads`, `tblleads_sources`
WHERE `branch_id` = '1' OR `branch_id` = '0'
ORDER BY `name` ASC
ERROR - 2023-12-30 16:36:57 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:36:57 --> Query error: Column 'branch_id' in where clause is ambiguous - Invalid query: SELECT *
FROM `tblleads`, `tblleads_sources`
WHERE `branch_id` = '1' OR `branch_id` = '0'
ORDER BY `name` DESC
ERROR - 2023-12-30 16:38:19 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:38:19 --> Query error: Column 'branch_id' in where clause is ambiguous - Invalid query: SELECT *
FROM `tblleads`, `tbltags`
WHERE `branch_id` = '1'
ORDER BY `name` ASC
ERROR - 2023-12-30 16:38:25 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:38:27 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:38:31 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:38:31 --> Query error: Column 'branch_id' in where clause is ambiguous - Invalid query: SELECT *
FROM `tblleads`, `tbltags`
WHERE `branch_id` = '1'
ORDER BY `name` ASC
ERROR - 2023-12-30 16:40:08 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:40:08 --> Query error: Column 'branch_id' in where clause is ambiguous - Invalid query: SELECT *
FROM `tblleads`, `tbltags`
WHERE `branch_id` = '1'
ORDER BY `name` ASC
ERROR - 2023-12-30 16:40:10 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:40:10 --> Query error: No tables used - Invalid query: SELECT *
WHERE `branch_id` = '1' OR `branch_id` = '0'
ORDER BY `name` DESC
ERROR - 2023-12-30 16:41:23 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:41:28 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:41:28 --> Query error: Column 'branch_id' in where clause is ambiguous - Invalid query: SELECT *
FROM `tblleads`, `tbltags`
WHERE `branch_id` = '1'
ORDER BY `name` ASC
ERROR - 2023-12-30 16:41:32 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:41:32 --> Query error: Column 'branch_id' in where clause is ambiguous - Invalid query: SELECT *
FROM `tblleads`, `tbltags`
WHERE `branch_id` = '1'
ORDER BY `name` ASC
ERROR - 2023-12-30 16:41:50 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:41:50 --> Query error: Column 'branch_id' in where clause is ambiguous - Invalid query: SELECT *
FROM `tblleads`, `tblleads_sources`
WHERE `branch_id` = '1' OR `branch_id` = '0'
ORDER BY `name` DESC
ERROR - 2023-12-30 16:42:34 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:42:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '. 'leads_sources'.branch_id = '1' OR db_prefix() . 'leads_sources'.branch_id ...' at line 3 - Invalid query: SELECT *
FROM `tblleads`, `tblleads_sources`
WHERE db_prefix() . 'leads_sources'.branch_id = '1' OR db_prefix() . 'leads_sources'.branch_id = '0'
ORDER BY `name` ASC
ERROR - 2023-12-30 16:43:39 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:43:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '. leads_sources.branch_id = '0'
ORDER BY `name` ASC' at line 3 - Invalid query: SELECT *
FROM `tblleads`, `tblleads_sources`
WHERE `tblleads_sources`.`branch_id` = '1' OR db_prefix() . leads_sources.branch_id = '0'
ORDER BY `name` ASC
ERROR - 2023-12-30 16:44:39 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:44:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORtbl leads_sources.branch_id = '0'
ORDER BY `name` ASC' at line 3 - Invalid query: SELECT *
FROM `tblleads`, `tblleads_sources`
WHERE tblleads_sources.branch_id='1' ORtbl leads_sources.branch_id = '0'
ORDER BY `name` ASC
ERROR - 2023-12-30 16:44:51 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:44:51 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`leads_sources`.`branch_id` = '0'
ORDER BY `name` ASC' at line 3 - Invalid query: SELECT *
FROM `tblleads`, `tblleads_sources`
WHERE `tblleads_sources`.`branch_id` = '1' OR `tbl` `leads_sources`.`branch_id` = '0'
ORDER BY `name` ASC
ERROR - 2023-12-30 16:45:26 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:45:26 --> Query error: Column 'name' in order clause is ambiguous - Invalid query: SELECT *
FROM `tblleads`, `tblleads_sources`
WHERE `tblleads_sources`.`branch_id` = '1' OR `tblleads_sources`.`branch_id` = '0'
ORDER BY `name` ASC
ERROR - 2023-12-30 16:46:06 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:46:06 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:50:21 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:50:21 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:50:21 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:50:21 --> Could not find the language line "View Dashboard"
ERROR - 2023-12-30 16:50:21 --> Could not find the language line "View Dashboard"
ERROR - 2023-12-30 16:50:21 --> Could not find the language line "View Dashboard"
ERROR - 2023-12-30 16:50:23 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:50:24 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:50:25 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:50:25 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:51:13 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:51:13 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:51:18 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:51:18 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:51:20 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:51:21 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:51:22 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:51:22 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:51:25 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:51:26 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:53:08 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:53:08 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:53:08 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:53:08 --> Could not find the language line "View Dashboard"
ERROR - 2023-12-30 16:53:08 --> Could not find the language line "View Dashboard"
ERROR - 2023-12-30 16:53:08 --> Could not find the language line "View Dashboard"
ERROR - 2023-12-30 16:53:11 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:53:12 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:53:12 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:53:14 --> Could not find the language line "Branches"
ERROR - 2023-12-30 16:53:15 --> Could not find the language line "Branches"
ERROR - 2023-12-30 17:05:04 --> Could not find the language line "Branches"
ERROR - 2023-12-30 17:05:05 --> Could not find the language line "Branches"
ERROR - 2023-12-30 17:06:46 --> Could not find the language line "Branches"
ERROR - 2023-12-30 17:06:47 --> Could not find the language line "Branches"
