<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-11-23 04:48:11 --> Could not find the language line "branch"
ERROR - 2023-11-23 04:56:39 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp-new\htdocs\finishizer_erp3.0.5\system\database\DB_driver.php 1472
ERROR - 2023-11-23 05:37:25 --> Severity: Notice --> Undefined property: Dashboard::$admin_helper C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Dashboard.php 103
ERROR - 2023-11-23 05:37:25 --> Severity: error --> Exception: Call to a member function init_head() on null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Dashboard.php 103
ERROR - 2023-11-23 05:38:25 --> Severity: error --> Exception: Call to undefined method Dashboard::load() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Dashboard.php 103
ERROR - 2023-11-23 05:38:42 --> Severity: error --> Exception: Call to undefined method Dashboard::load() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Dashboard.php 103
ERROR - 2023-11-23 05:38:44 --> Severity: error --> Exception: Call to undefined method Dashboard::load() C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Dashboard.php 103
ERROR - 2023-11-23 05:39:42 --> Severity: error --> Exception: Call to a member function init_head() on null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Dashboard.php 103
ERROR - 2023-11-23 05:39:43 --> Severity: error --> Exception: Call to a member function init_head() on null C:\xampp-new\htdocs\finishizer_erp3.0.5\application\controllers\admin\Dashboard.php 103
