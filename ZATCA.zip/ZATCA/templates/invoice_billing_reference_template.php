<?php

/*
 *
 */

return <<<XML
<cac:BillingReference>
<cac:InvoiceDocumentReference>
   <cbc:ID>Invoice Number: SET_INVOICE_NUMBER</cbc:ID>
</cac:InvoiceDocumentReference>
</cac:BillingReference>
XML;

